<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
function show_menu($admin = false){
    $CI =& get_instance();
    if ($CI->session->userdata('userID') AND $CI->Permissions->has_any_admin_permission()){
        $menu = array(
            'Home' => '',
            'My Info' => 'user',
            'Management' => 'admin/groups_view',
            'Tags' => 'admin/tags',
//            'Users' => array(
//                'Add' => 'admin/user_add',
//                'View' => 'admin/users_view'
//            ),
//            'Groups' => array(
//                'Add' => 'admin/group_add',
//                'View' => 'admin/groups_view'
//            )
        );
        if ($CI->session->userdata('sys_admin')){
            $menu['Config'] = array(
                                'General' => 'admin/config',
                                'Punch Types' => 'admin/punch_types',
                                'Reports' => 'admin/reports');
//            $menu['Import'] = 'admin/import';
        }
    }
    else {
        $menu = array(
            'Home' => '',
            'My Info' => 'user'
        );
    }

        echo '<ul id="nav" class="dropdown dropdown-horizontal">';
            foreach ($menu as $index => $menu){
                if (is_array($menu)){
                    echo "<li class='dir'>$index";
                        echo '<ul>';
                            foreach ($menu as $index => $item){
                                echo '<li>';
                                    echo anchor($item, $index);
                                echo '</li>';
                            }
                        echo '</ul>';
                    echo '</li>';
                }
                else{
                    echo '<li>';
                        if ($index == 'My Info' AND ! $CI->session->userdata('userID')){
                            echo '<a id="inline2" href="#data2">My Info</a>';
                            echo '<div style="display:none"><div id="data2" style="padding:15px">';
                                echo form_open('login/do_login', 'name="loginForm2"');
                                    echo '<table>';
                                        form_text('Username', 'username');
                                        form_pass('Password', 'password');
                                        form_submit('Login');
                                    echo '</table>';
                                    form_hidden('forwardToURL', 'user');
                                echo form_close();
                            echo '</div></div>';
                            ?>
                                <script type="text/javascript">
                                    var frmvalidator = new Validator("loginForm2");
                                    frmvalidator.EnableMsgsTogether();

                                    frmvalidator.addValidation("username","req", "Username is required");
                                    frmvalidator.addValidation("password","req", "Password is required");
                               </script>
                            <?php
                        }
                        else {
                            echo anchor($menu, $index);
                        }
                    echo '</li>';
                }
            }
        echo '</ul>';

        echo '<div id="rightOfMenu"></div>';
}
?>