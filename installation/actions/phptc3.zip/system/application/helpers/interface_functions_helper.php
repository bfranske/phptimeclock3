<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */

/***********************************************************************
 ***                 Generic  interface functions                    ***
 ***********************************************************************/

/*
 * $d Default
 * $tr      Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *          Set to -1 to not output any table elements
 */
function form_select_timezones($d = -7, $tr = true){
    if ($tr == 1 OR $tr == 2) echo '<tr>';
    if ($tr !== -1 )echo '<td>Select Timezone </td>
    <td>';
    echo "
    <select name='tzOffset' size='1'>
    <option " . ($d == 0 ?   "selected='selected'" : '') . "value='0'>  Select Timezone</option>
    <option " . ($d == -11 ? "selected='selected'" : '') . "value='-11'>[GMT - 11] Niue Time, Samoa Standard Time</option>
    <option " . ($d == -10 ? "selected='selected'" : '') . "value='-10'>[GMT - 10] Hawaii - Aleutian Standard Time, Cook ...</option>
    <option " . ($d == -9 ?  "selected='selected'" : '') . "value='-9'> [GMT - 9] Alaska Standard Time, Gambier Island ...</option>
    <option " . ($d == -8 ?  "selected='selected'" : '') . "value='-8'> [GMT - 8] Pacific Standard Time</option>
    <option " . ($d == -7 ?  "selected='selected'" : '') . "value='-7'>[GMT - 7] Mountain Standard Time</option>
    <option " . ($d == -6 ?  "selected='selected'" : '') . "value='-6'> [GMT - 6] Central Standard Time</option>
    <option " . ($d == -5 ?  "selected='selected'" : '') . "value='-5'> [GMT - 5] Eastern Standard Time</option>
    </select>";
    if ($tr !== -1) echo '</td>';
    if ($tr == 1 OR $tr == 3) echo '</tr>';
}

/*
 * $varname Name of the variable
 * $d default
 * $id DB id of number updating
 *      If adding a number, pass as '', if ID is passed for adding it will break stuff
 * $tr  Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *      Set to -1 to not output any table elements
 */
function form_select_phone($varname, $d = 0, $id = '', $tr = true){
    if ($tr == 1 OR $tr == 2) echo '<tr>';
    if ($tr !== -1) echo '<td>Type </td>
    <td>';
    echo "
    <select name='$varname' size='1'>
    <option " . ($d == '' ? "selected='selected'" : '') . "value='0'>  Select Type</option>
    <option " . ($d == 'Home' ? "selected='selected'" : '') . "value='Home$id'>Home</option>
    <option " . ($d == 'Work' ? "selected='selected'" : '') . "value='Work$id'>Work</option>
    <option " . ($d == 'Cell' ? "selected='selected'" : '') . "value='Cell$id'>Cell</option>
    <option " . ($d == 'Fax'  ? "selected='selected'" : '') . "value='Fax$id'>Fax</option>
    </select>";
    if ($tr !== -1) echo '</td>';
    if ($tr == 1 OR $tr == 3) echo '</tr>';
}

/*
 *  Called when building forms
 *  $tr Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *      Set to -1 to not output any table elements
 */
function form_exp_date($d_m = 0, $d_y = 0, $tr = true){
    if ($tr == 1 OR $tr == 2) echo '<tr>';
    if ($tr !== -1) echo "<td>Expiration Date:*</td><td>";
    echo "<select name='CCExpMonth' size='1'>
    <option value='0' " . ($d_m == 0 ? "selected='selected'" : '') . ">Month</option>\n";
    for ($i = 1; $i < 13; $i++){
        echo "<option value='$i'" . ($d_m == $i ? "selected='selected'" : '') . ">" . ($i < 10 ? "0$i" : "$i") . "</option>\n";
    }
    echo '</select>';
    echo "
    <select name='CCExpYear' size='1'>
    <option value='0' " . ($d_y == $i ? "selected='selected'" : '') . ">Year</option>\n";
    for ($i = date('Y', time()); $i < (int)date('Y', time()) + 10; $i++){
        echo "<option value='$i' " . ($d_y == $i ? "selected='selected'" : '') . ">$i</option>\n";
    }
    echo '</select>';
    if ($tr !== -1) echo '</td>';
    if ($tr == 1 OR $tr == 3) echo '</tr>';
}
    
/*
 *  Called when building forms
 *  $tr Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *      Set to -1 to not output any table elements
 */

function form_cc_types($d = "", $tr = true){
    if ($tr == 1 OR $tr == 2) echo '<tr>';
    if ($tr !== -1) echo '<td>Card Type:*</td><td>';
    echo "<select name='CCType' size='1'>
    <option value='0'>Please Select</option>\n";

    echo "<option value='Visa' " .              ($d == "Visa" ? "selected='selected'" : '') .            ">Visa</option>\n";
    echo "<option value='MasterCard' " .        ($d == "MasterCard" ? "selected='selected'" : '') .      ">MasterCard</option>\n";
    echo "<option value='Discover' " .          ($d == "Discover" ? "selected='selected'" : '') .        ">Discover</option>\n";
    echo "<option value='American Express' " .  ($d == "American Express" ? "selected='selected'" : '') . ">American Express</option>\n";

    echo '</select>';
    if ($tr !== -1) echo '</td>';
    if ($tr == 1 OR $tr == 3) echo "</tr>\n";
}

/*
 * $d   Default
 * $tr  Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *      Set to -1 to not output any table elements
 */
function form_select_state($varname, $d = 0, $tr = true){
    if ($tr == 1 OR $tr == 2) echo '<tr>';
    if ($tr !== -1) echo "<td>State:*</td>
    <td>";
    echo "<select name='$varname' size='1'>
    <option " . ($d == 0    ? "selected='selected'" : '') . "value='0'></option>
    <option " . ($d == 'AL' ? "selected='selected'" : '') . "value='AL'>AL</option>
    <option " . ($d == 'AK' ? "selected='selected'" : '') . "value='AK'>AK</option>
    <option " . ($d == 'AS' ? "selected='selected'" : '') . "value='AS'>AS</option>
    <option " . ($d == 'AZ' ? "selected='selected'" : '') . "value='AZ'>AZ</option>
    <option " . ($d == 'AR' ? "selected='selected'" : '') . "value='AR'>AR</option>
    <option " . ($d == 'CA' ? "selected='selected'" : '') . "value='CA'>CA</option>
    <option " . ($d == 'CO' ? "selected='selected'" : '') . "value='CO'>CO</option>
    <option " . ($d == 'CT' ? "selected='selected'" : '') . "value='CT'>CT</option>
    <option " . ($d == 'DE' ? "selected='selected'" : '') . "value='DE'>DE</option>
    <option " . ($d == 'DC' ? "selected='selected'" : '') . "value='DC'>DC</option>
    <option " . ($d == 'FM' ? "selected='selected'" : '') . "value='FM'>FM</option>
    <option " . ($d == 'FL' ? "selected='selected'" : '') . "value='FL'>FL</option>
    <option " . ($d == 'GA' ? "selected='selected'" : '') . "value='GA'>GA</option>
    <option " . ($d == 'GU' ? "selected='selected'" : '') . "value='GU'>GU</option>
    <option " . ($d == 'HI' ? "selected='selected'" : '') . "value='HI'>HI</option>
    <option " . ($d == 'ID' ? "selected='selected'" : '') . "value='ID'>ID</option>
    <option " . ($d == 'IL' ? "selected='selected'" : '') . "value='IL'>IL</option>
    <option " . ($d == 'IN' ? "selected='selected'" : '') . "value='IN'>IN</option>
    <option " . ($d == 'IA' ? "selected='selected'" : '') . "value='IA'>IA</option>
    <option " . ($d == 'KS' ? "selected='selected'" : '') . "value='KS'>KS</option>
    <option " . ($d == 'KY' ? "selected='selected'" : '') . "value='KY'>KY</option>
    <option " . ($d == 'LA' ? "selected='selected'" : '') . "value='LA'>LA</option>
    <option " . ($d == 'ME' ? "selected='selected'" : '') . "value='ME'>ME</option>
    <option " . ($d == 'MH' ? "selected='selected'" : '') . "value='MH'>MH</option>
    <option " . ($d == 'MD' ? "selected='selected'" : '') . "value='MD'>MD</option>
    <option " . ($d == 'MA' ? "selected='selected'" : '') . "value='MA'>MA</option>
    <option " . ($d == 'MI' ? "selected='selected'" : '') . "value='MI'>MI</option>
    <option " . ($d == 'MS' ? "selected='selected'" : '') . "value='MS'>MS</option>
    <option " . ($d == 'MO' ? "selected='selected'" : '') . "value='MO'>MO</option>
    <option " . ($d == 'MT' ? "selected='selected'" : '') . "value='MT'>MT</option>
    <option " . ($d == 'NE' ? "selected='selected'" : '') . "value='NE'>NE</option>
    <option " . ($d == 'NV' ? "selected='selected'" : '') . "value='NV'>NV</option>
    <option " . ($d == 'NH' ? "selected='selected'" : '') . "value='NH'>NH</option>
    <option " . ($d == 'NJ' ? "selected='selected'" : '') . "value='NJ'>NJ</option>
    <option " . ($d == 'NM' ? "selected='selected'" : '') . "value='NM'>NM</option>
    <option " . ($d == 'NY' ? "selected='selected'" : '') . "value='NY'>NY</option>
    <option " . ($d == 'NC' ? "selected='selected'" : '') . "value='NC'>NC</option>
    <option " . ($d == 'ND' ? "selected='selected'" : '') . "value='ND'>ND</option>
    <option " . ($d == 'MP' ? "selected='selected'" : '') . "value='MP'>MP</option>
    <option " . ($d == 'OH' ? "selected='selected'" : '') . "value='OH'>OH</option>
    <option " . ($d == 'OK' ? "selected='selected'" : '') . "value='OK'>OK</option>
    <option " . ($d == 'OR' ? "selected='selected'" : '') . "value='OR'>OR</option>
    <option " . ($d == 'PW' ? "selected='selected'" : '') . "value='PW'>PW</option>
    <option " . ($d == 'PA' ? "selected='selected'" : '') . "value='PA'>PA</option>
    <option " . ($d == 'PR' ? "selected='selected'" : '') . "value='PR'>PR</option>
    <option " . ($d == 'RI' ? "selected='selected'" : '') . "value='RI'>RI</option>
    <option " . ($d == 'SC' ? "selected='selected'" : '') . "value='SC'>SC</option>
    <option " . ($d == 'TN' ? "selected='selected'" : '') . "value='TN'>TN</option>
    <option " . ($d == 'TX' ? "selected='selected'" : '') . "value='TX'>TX</option>
    <option " . ($d == 'UT' ? "selected='selected'" : '') . "value='UT'>UT</option>
    <option " . ($d == 'VT' ? "selected='selected'" : '') . "value='VT'>VT</option>
    <option " . ($d == 'VI' ? "selected='selected'" : '') . "value='VI'>VI</option>
    <option " . ($d == 'VA' ? "selected='selected'" : '') . "value='VA'>VA</option>
    <option " . ($d == 'WA' ? "selected='selected'" : '') . "value='WA'>WA</option>
    <option " . ($d == 'WV' ? "selected='selected'" : '') . "value='WV'>WV</option>
    <option " . ($d == 'WI' ? "selected='selected'" : '') . "value='WI'>WI</option>
    <option " . ($d == 'WY' ? "selected='selected'" : '') . "value='WY'>WY</option>
    </select>";
    if ($tr !== -1) echo '</td>';
    if ($tr == 1 OR $tr == 3) echo '</tr>';
}
/*
 * $colspan: if set, will set the colspan
 * $tr: Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *      Set to -1 to not output any table elements
 */
function form_label($label, $colspan = 10, $tr = true, $css_type = '', $class_id = 'label') {
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '') .
        "<td colspan='$colspan'" . ($css_type != '' ? " $css_type='$class_id'" : "") . "><label>$label</label></td>" .
        (($tr == 1 OR $tr == 3) ? '</tr>' : '');
}

/*
 * Outputs list for the category to view
 * $d default
 * $category is the category to list subcategories of, 0 or omit for top level
 * $tr      Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *          Set to -1 to not output any table elements
 * $label   Set to the text you want, if you want a label
 */
function form_select_category($d = 0, $category = 0, $tr = true, $label = false, $var = 'categoryID', $noShowCategory = 0){
    $categories = get_categories($category, '', 'name', false, 0, 500);

    if ($tr == 1 OR $tr == 2) echo '<tr>';
    if ($label !== false AND $tr !== -1)
        echo "<td><label>$label</label></td>";
    if ($tr !== -1) echo '<td>';
    echo "<select name='$var' size='1'>";
    echo "<option " . ($d == 0  ? "selected='selected'" : '') . "value='0'>None</option>";
    foreach ($categories as $category){
        if ($category['id'] != $noShowCategory){
            $categoryName = get_category_name($category['id']);
            if (strlen($categoryName) > 40) $categoryName = substr($categoryName, 0, 40) . '...';
            echo "<option " . ($d == $category['id']  ? "selected='selected'" : '') . "value='{$category['id']}'>$categoryName</option>";
        }
    }
    echo '</select>';
    if ($tr !== -1) echo '</td>';
    if ($tr == 1 OR $tr == 3) echo '</tr>';
}


function form_text($label, $name, $value = '', $tr = true, $size = false, $extra = '', $trExtra = '', $tdExtra = ''){
    $value = remove_slashes($value);
    $editedLabel = trim($label, ':*');
    echo (($tr == 1 OR $tr == 2) ? "<tr $trExtra>" : '');
    if ($label != '' AND $tr !== -1){
        echo "<td $tdExtra>$label</td>";
    }
    if ($tr !== -1) echo "<td $tdExtra>";
    echo "<input type='text' name='$name' " . ($size ? "size='$size' " : '') .
            ($value != '' ? " value='$value'" : "") /*. "onclick=\"if (this.value=='$editedLabel') { this.value='' }\""*/ . " $extra/>";
            if ($tr !== -1) echo '</td>';
    echo (($tr == 1 OR $tr == 3) ? "</tr>" : "");
}
/*
 * $label   Self explanitory
 * $name    Name of the form element
 * $tr      Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *          Set to -1 to not output any table elements
 * $value   Default text
 * $css_type Set to either class or id
 * $class_id the class or id you want to assign
 */
function form_textarea($label, $name, $rows, $cols, $value = '', $tr = true, $extra = ''){
    $value = remove_slashes($value);
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '');
    if ($tr !== -1) echo "<td><label>$label</label></td>
          <td>";
    echo "<textarea name='$name' rows='$rows' cols='$cols'" .
             ($_SESSION['jsClear'] == true ? "onclick=\"if (this.value=='$name') { this.value='' }\"" : '') . " $extra>$value</textarea>";
    if ($tr !== -1) echo '</td>';
    echo (($tr == 1 OR $tr == 3) ? "</tr>\n" : "\n");
}

/*
 * Identical to form_text, but is a pasword field
 */
function form_pass($label, $name, $value = '', $tr = true, $extra = '', $tdExtra = ''){
    $value = remove_slashes($value);
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '');
    if ($tr !== -1) echo "<td><label>$label</label></td><td $tdExtra>";
    echo "<input type='password' name='$name' " .
            ($value != '' ? "value='$value'" : "") . " $extra/>";
    if ($tr !== -1) echo '</td>';
    echo (($tr == 1 OR $tr == 3) ? "</tr>" : "");
}


function form_select($label, $value, $extra = '', $d = false){
    echo "<option value='$value' " . ($d == true ? "selected='selected'" : '') . " $extra>$label</option>";
}
/*
 * $label Self expalnitory
 * $tr    Set to false to not output table row, or 2 to only close the </tr>
 *        Set to -1 to not output any table elements
 * $td    Set to false to not output the first <td></td>, a number to ouput x amount
 */
function form_submit($label = 'Submit', $show_name = false, $tr = true, $td = true, $image = false, $colspan = 1, $extra = ''){
    $name = str_replace(' ', '', $label);
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '');
    $i = $td;
    while ($i AND $tr !== -1){
        echo '<td></td>';
        $i -= 1;
    }
    if ($tr !== -1 AND $td !== -1) echo "<td colspan='$colspan' " . ">";
    echo "<input type='" . ($image == false ? "submit'" : "image'") . ($show_name  == true ? " name='$name'" : '') . ($image != '' ? "src='$image'" : '') . " value='$label' $extra/>";
    if ($tr !== -1 AND $td !== -1) echo '</td>';
    echo (($tr == 1 OR $tr == 3)) ? "</tr>\n" : "\n";
}
/*
 * $label Self expalnitory
 * $tr    Set to false to not output table row, or 2 to only close the </tr>
 *        Set to -1 to not output any table elements
 * $td    Set to false to not output the first <td></td>
 */
function form_cancel($label, $tr = true,  $td = true, $onclick="javascript:show_confirm()"){
    $name = str_replace(' ', '', $label);
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '');
    echo $td AND $tr !== -1 ? "<td></td>" : '';
    if ($tr !== -1) echo '<td>';
    echo "<a href=\"$onclick\"><img src='images/cancel.png' $onclick /></a>";
    if ($tr !== -1) '</td>';
    echo (($tr == 1 OR $tr == 3) ? "</tr>\n" : "\n");
}
/* This can be a bit tricky, if changing colspan or reversing order (with $td and $colspan)
 * $label   Self explanitory
 * $name    Name of the form element
 * $value   Checkbox value
 * $checked Set to true to have the box checked
 * $tr      Set to false to not output table row, or 2 to only open the </tr>, 3 to only close <tr>
 *          Set to -1 to not output any table elements
 * $td      Set to false to not output a preceding <td> $label </td>, set to 2 to switch checkbox and label
 * $colspan Sets the colspan, if passed not as 1, will be one <td> rather than 2, if not changed, the first cell will be right aligned
 * $hover   Set to true to use CSS :hover effect
 */
function form_checkbox($label, $name, $value, $checked = false, $tr = true, $td = true, $colspan = 1, $hover = false, $extra = ''){

    echo (($tr == 1 OR $tr == 2) ? (($hover == true) ? '<tr class="hover">' : '<tr>') : '');
    if ($td == 0 OR $td == 1){
        echo  ($tr !== -1 ? '<td class=\'centerAlign\'>' : '') . "<input type='checkbox' name='$name' "  .
              ($checked == true ? 'checked="checked"' : '') . " value='$value' $extra/>" . ($tr !== -1 ? '</td>' : '') .
              ($td == true ? "<td><label>$label</label></td>" : '');
    }
    else{
        if ($tr !== -1) echo "<td colspan=$colspan " . ($colspan == 1 ? "align=right" : '') . "class='centerAlign' >";
        echo "<input type='checkbox' name='$name' "  .
              ($checked == true ? 'checked="checked"' : '') . " value='$value' $extra/>" . ($colspan == 1 AND $tr !== -1 ? "</td><td>" : '') .
              $label . ($tr !== -1 ? '</td>' : '');

    }
    echo (($tr == 1 OR $tr == 3) ? "</tr>" : "");
}

/* This can be a bit tricky, if changing colspan or reversing order (with $td and $colspan)
 * $label   Self explanitory
 * $name    Name of the form element
 * $value   Checkbox value
 * $checked Set to true to have the box checked
 * $tr      Set to false to not output table row, or 2 to only close the </tr>, 3 to only open <tr>
 *          Set to -1 to not output any table elements
 * $td      Set to false to not output a preceding <td> $label </td>, set to 2 to switch checkbox and label
 * $colspan Sets the colspan, if passed not as 1, will be one <td> rather than 2, if not changed, the first cell will be right aligned
 */
function form_radio($label, $name, $value, $checked = false, $tr = true, $td = true, $colspan = 1, $extra = ''){
    if ($checked === ' checked="checked"'){
        $checked = true;
    }
    $extra = str_replace('"', "\"", $extra);
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '');
    if ($td == 0 OR $td == true){
        echo (($td == 1 AND $tr !== -1) ? "<td><label>$label</label></td>" : '') .
              ($tr !== -1 ? '<td>' : '' ) . "<input type='radio' name='$name' "  .
              ($checked == true ? 'checked="checked"' : '') . " value='$value' $extra/>" . ($tr !== -1 ? '</td>' : '');
    }
    else{
        if ($tr !== -1 ) echo "<td colspan=$colspan " . ($colspan == 1 ? "align=right" : '') . ">";
        else die();
        echo "<input type='radio' name='$name' "  .
              ($checked == true ? 'checked="checked"' : '') . " value='$value' $extra/>" . ($colspan == 1 AND $tr !== -1 ? "</td><td>" : '') .
              $label . ($tr !== -1 ? '</td>' : '');

    }
    echo (($tr == 1 OR $tr == 3) ? "</tr>\n" : "\n");
}

function form_hidden($name, $value = ''){
    echo "<input type='hidden' name='$name'  value='$value' />";
}

/*
 * @Param label   Self explanitory
 * @Param name    Name of the form element
 * @Param tr      Set to false to not output a table row, or 2 to only close the </tr>, 3 to only open <tr>
 *                Set to -1 to not output any table elements
 * @Param size    Pass this to hav custom size (Characters, and effects aesthetically)
 * @Param value   Default text
 * @Param css_type Set to either class or id
 * @Param class_id the class or id you want to assign
 */
function form_file($label, $name, $tr = true, $size = false, $extra = ''){
    echo (($tr == 1 OR $tr == 2) ? '<tr>' : '');
    if ($tr !== -1) echo "<td><label>$label</label></td>
          <td>";
    echo "<input name='$name' type='file' " . ($size ? "size=$size" : '') . " $extra/>";
    if ($tr !== -1) '</td>';
    echo (($tr == 1 OR $tr == 3) ? "</tr>\n" : "\n");
}

/*
 * outputs 2 table cells, one  label, and a $data
 * $tr pass false to not make a table row, or 2 to only close the table row, 3 to only open <tr>
 */
function table_data($label, $data, $tr = 1, $td = true, $extra = ''){
    echo (($tr == 1 OR $tr == 2) ? "<tr>\n" : "\n");
    if ($label)
        echo "<td><strong>$label</strong></td>";
    echo "<td>$data</td>\n\n";
    echo (($tr == 1 OR $tr == 3) ? "</tr>\n" : "\n");
}
/*
 * outputs <td>$val</td> for each value in array $data
 * $tr pass false to not make a table row, or 2 to only close the table row, 3 to only open <tr>
 */
function table_datas($data, $tr = 1){
    echo (($tr == 1 OR $tr == 2) ? "<tr class='hover'>\n" : "\n");
    foreach($data as $key => $dat)
        echo "<td>$dat</td>\n\n";
    echo (($tr == 1 OR $tr == 3) ? "</tr>\n" : "\n");
}
function table_open($extra = ''){
    echo "<table $extra>";
}
function table_close(){
    echo "</table>";
}

function query($query){
    echo "<span style='color:#68532a'>$query</span><br />";
}

function form_select_permissions($userID = false, $groupID = false, $tr = false, $echo = false){
    if (!$userID){
        die('UserID not passed to form_select_permissions()!');
    }
//    if (! is_array($selected))
//        $selected = array();

    if ($userID AND $groupID){
        $CI =& get_instance();
    }

    $CI->Permissions->load_permissions($userID);
    $permissions = array('Punch' => 'punch', 'Edit Time' => 'editTime', 'Run Reports' => 'runReports');
    $string = $tr ? '<tr>' : '';
        foreach ($permissions as $permName => $permission){
            if (isset($CI)){
                if (isset($CI->Permissions->groups[$groupID])){
                    if (in_array("not_$permission", $CI->Permissions->groups[$groupID]['permissions'])){
                        $selected = 'No';
                    }
                    else if (in_array($permission, $CI->Permissions->groups[$groupID]['permissions'])){
                        $selected = 'Yes';
                    }
                    else {
                        $selected = $groupID == 1 ? 'No' : 'Inherit';
                    }
                }
                else {
                    $selected = $groupID == 1 ? 'No' : 'Inherit';
                }
            }
            else {
                $selected = $groupID == 1 ? 'No' : 'Inherit';
            }
            $selectedString =
            $string .= "<td><select name='permissions_$userID".'['.$permission.']'."'>";
                $string .= "<option value='1' " . ($selected == 'Yes' ? 'selected' : '') . ">Yes</option>";
                $string .= "<option value='0' " . ($selected == 'No' ? 'selected' : '') . ">No</option>";
                if ($groupID != 1)
                    $string .= "<option value='-1' " . ($selected == 'Inherit' ? 'selected' : '') . ">Inherit</option>";
            $string .= "</select></td>";
        }
    if ($tr)
        $string .= '</tr>';

    if ($echo)
        echo "$string";
    else
        return $string;
}

function render_tree_list_group($array, $linkPrefix = false, $showButtons = true){
    $CI =& get_instance();
    global $groupTreeIDs;
    if (! $CI->Group->is_enabled($array['info']['id']) AND !$CI->session->userdata('showDisabledGroups')){
//        dump($CI->session->userdata('showDisabled'));
//        dump($CI->Group->is_enabled($array['info']['id']));
        return false;
    }
//    dump($array);
    $groupTreeIDs[] = $array['info']['id'];
    $id = $array['info']['id'];
    $level = $array['info']['level'];
    $name = $array['info']['name'];

    $hasUsers = false;
    if (isset($array['users'])){
        foreach ($array['users'] as $user){
            if ($user->enabled == (! $CI->session->userdata('showDisabled'))){
                $hasUsers = true;
                break;
            }
        }
    }

    echo "\n<tr id='row$id'>";
//    echo '<td>'.$array['info']['id'].' '.$CI->Group->is_enabled($array['info']['id']).'</td>';
    echo '<td>';
        for($i = 1; $i <= $level; $i++){
            echo '<img src="' . $CI->config->item('base_url') .'css/images/list_spacer.png" alt="" />';
        }
        if ($linkPrefix)
            echo anchor($linkPrefix . '?id=' . $id, $array['info']['name']);
        else
            echo $array['info']['name'];
     echo '</td>';

     if ($showButtons){
         echo '<td>';
            if (($CI->Permissions->has_permission($array['info']['id'], 'runReports') OR $CI->Permissions->has_permission($array['info']['id'], 'editTime')) AND $hasUsers){
                echo "<input type='button' value='Reports' onclick='AddRunReports($id, $level)'  class='actionButton' />";
            }
         echo '</td>';

        if (($CI->session->userdata('sys_admin') == 1)){
            echo'<td>';
                if ($hasUsers){
                   echo "<input type='button' value='Users' onclick='AddShowUsers($id, $level)'  class='actionButton' />";
                }
            echo '</td>';

            echo "<td><input type='button' value='Add User' onclick='AddUser($id, $level)'  class='actionButton' /></td>";
            echo "<td><input type='button' value='Add Subgroup' onclick='AddSubGroup($id, $level)'  class='actionButton' /></td>";

            echo '<td>';
                if ($array['info']['id'] != 1){
                    echo "<input type='button' value='Move Group' onclick='AddMoveGroup($id, $level)'  class='actionButton' />";
                }
            echo '</td>';

            echo '<td>';
                if ($array['info']['id'] != 1){
                    echo "<input type='button' value='Rename Group' onclick='AddRenameGroup($id, $level, \"$name\")'  class='actionButton' />";
                }
            echo '</td>';

            echo '<td>';
                $hasPunches = $CI->db->get_where('punches', array('group_id' => $array['info']['id']));

                if ($id != 1 AND (isset($array['children']) OR isset($array['users']) OR $hasUsers OR count($hasPunches->result()))){
                    echo '<form method="post" action="'.BASE_URL.'index.php/admin/groups_view">';
                        if ($CI->Group->is_enabled($id)){
                            echo "<input type='submit' value='Disable Group' class='actionButton' />";
                            form_hidden('newStatus', 0);
                        }
                        else {
                            echo "<input type='submit' value='Enable Group' class='actionButton' />";
                            form_hidden('newStatus', 1);
                        }
                        form_hidden('groupID', $id);
                        form_hidden('action', 'toggleGroupEnabled');
                    echo '</form>';
                }
                else if ($array['info']['id'] != 1) {
                    echo "<input type='button' value='Delete Group' onclick='AddDeleteGroupConfirm($id, $level)'  class='actionButton' />";
                }
            echo '</td>';
        }
     }

        echo '</tr>';
        if (isset($array['children'])){
            foreach ($array['children'] as $child){
                render_tree_list_group($child, $linkPrefix, $showButtons);
            }
        }
}

function render_tree_select_group($array, $return = false, $level = 0, $showRootGroup = true, $groupList = false){
    static $output = '';

    if (isset($array['info']) AND $showRootGroup){
        if (! is_array($groupList) OR isset($groupList[$array['info']['id']])){
            $output .= "<option value=\"{$array['info']['id']}\" " . set_select('groupID', $array['info']['id']) . ">";
                for($i = 1; $i <= $array['info']['level']; $i++){
                    $output .= '---';
                }
                $output .= $array['info']['name'];
            $output .= '</option>';
        }
    }

    if (isset($array['children'])){
        foreach ($array['children'] as $child){
            render_tree_select_group($child, $return, $level + 1,true, $groupList);
        }
    }

    if ($return){
        return $output;
    }
    else if (! $level) {
        echo $output;
    }

}

function render_select_user($array, $varName = 'userID', $showSelect = true, $noShowUsers = array()){
    echo "<select name='$varName'>";
        echo "<option value='0'>Select User</option>";
        foreach ($array->result() as $user) {
            if ((! is_array($noShowUsers)) OR (! in_array($user->id, $noShowUsers))){
                echo "<option value='$user->id'>$user->username</option>";
            }
        }
    echo '</select>';
}

function duration_to_time($duration){
    $hours = floor($duration);
    $hoursText = $hours ? "$hours hr, " : '';
    $minutes = round(($duration - $hours) * 60);
    return "$hoursText $minutes min";
}

function show_notices(){
    $CI =& get_instance();
    if (is_array($CI->notices->notices)){
        foreach ($CI->notices->notices as $notice){
            if (is_array($notice)){
                dump($notice);
            }
            else {
                echo "<br />$notice";
            }
        }
        echo '<br />';
    }

    if (is_array($CI->notices->notices_alert)){
        echo '<script type="text/javascript">';
        foreach ($CI->notices->notices_alert as $notice){
            echo "alert('$notice')";
        }
        echo '</script>';
    }

    if (is_array($CI->notices->notices_fade)){
        echo '<span id="fadeSpan">';
            foreach ($CI->notices->notices_fade as $notice){
                echo "<br />$notice";
            }
        echo '</span>';
        echo '<br />';
        ?>
<script type="text/javascript">
    $('#fadeSpan').delay(50000).fadeOut(10000);
</script>
        <?php
    }
}
?>