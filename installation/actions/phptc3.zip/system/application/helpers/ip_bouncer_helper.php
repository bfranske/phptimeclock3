<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Checks an ip address (and whether the server is dev or staging on a MediaTemple (dv) subdomain),
 * prints a message, and ends page execution if the IP isn't allowed.
 *
 * Use it in the instantiation block of any controller to restrict the page, or in any method
 * you want restricted.
 *
 * @author         Sean Gates
 * @link         http://seangates.com
 * @license        GNU Public License (GPL)
 *
 * @access         public
 * @param         string [$ip] valid IP address
 *
 * USAGE:
 *
 *         class Home extends Controller {
 *
 *             function Home()
 *             {
 *                 parent::Controller();
 *
 *                 // bounce the person if they don't have the right IP address
 *                 ip_bouncer($this->input->ip_address());
 *             }
 *
 *             ...
 *         }
 *
 */
if (! function_exists('ip_bouncer'))
{
    function ip_bouncer($ip)
    {
        // restrict to these IP addresses
        $CI =& get_instance();

        if (strpos($CI->Config->item('restrictIPAddresses'), 'Yes') !== false){
            $ip_addresses = explode(',', str_replace(' ', '', str_replace('Yes ', '', $CI->Config->item('restrictIPAddresses'))));
    //        dump($ip_addresses);
    //        die();

            // check if the ip is allowed, and whether we're on the dev or staging servers
            if( !in_array($ip, $ip_addresses)/* && strstr(getcwd(),'/subdomains/') */)
            {
                echo 'This is a restricted area. Move along ...';
                exit();
            }
        }
    }
}
?>