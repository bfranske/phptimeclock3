<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class MenuTree {
//    protected $idKey = 'id';
//    protected $parentIDKey = 'parent_id';

    /**
     *
     * Override CategoryTree::renderToList()
     *
     * @staticvar <int> $level : Keeps track of nesting level during recursion.
     * @param <array> $array : Multidimensional array to render as list.
     * @param <string> $htmlID : HTML id to assign to top-level list
     * @param <string> $htmlClass : List of HTML class names to assign to the top-level list.
     * @param <bool> $linkParents : Whether to generate links for parent menu items
     * @param <string> $type : HTML list type to use (ul / ol)
     */
    public function renderToList($array = false, $htmlID = "", $htmlClass="dropdown dropdown-horizontal", $linkParents = false) {
//        if (! is_array($array)){
//            die('No array passed to MenuTree::renderToList!!!!!');
//        }

        static $level = 0;

        if ($level++ == 0){
            $id = "id='$htmlID'";
            $class="class='$htmlClass'";
        }
        else $id = $class = '';
        
        if ($level == 0) echo "<ul id='$id' class='$class'>";
        
//            foreach ()
        echo "<ul $id $class>";
            foreach ($array as $index => $value){
                $dir = is_array($value) ? 'class="dir"' : '';
                echo "<li $dir>";
                    
                echo '</li>';
            }
        echo '</ul>';
    }
}
?>