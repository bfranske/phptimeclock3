<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * ExiteCMS Date Helpers
 *
 * @package		ExiteCMS
 * @author		WanWizard
 * @copyright	Copyright (c) 2009, ExiteCMS.org
 * @license		http://www.exitecms.org/license.php
 * @link		http://www.exitecms.org
 * @since		Version 8.0
 */

// ------------------------------------------------------------------------

/**
 * include the timezone helper to support pre PHP 5.2.0 environments
 *
 * @access	public
 * @return	array
 */
if ( is_php('5.2.0') == FALSE )
{
	// make sure there's enough memory to support this function
	$mem = (int) ini_get('memory_limit');
	if ( $mem < 64 )
	{
		ini_set('memory_limit', '64M');
	}

	require('exitecms/helpers/timezone_helper.php');
}

// ------------------------------------------------------------------------

/**
 * Converts GMT time to a localized value
 * Our version defaults to the defined timezone, we ignore the DST flag
 * but return the true local time timezone functions
 *
 * Takes a Unix timestamp (in GMT) as input, and returns
 * at the local value based on the timezone and DST setting
 * submitted
 *
 * @access	public
 * @param	integer Unix timestamp
 * @param	string	timezone
 * @param	bool	whether DST is active
 * @return	integer
 */
if ( ! function_exists('gmt_to_local'))
{
	function gmt_to_local($time = '', $timezone = '', $dst = NULL)
	{
		// catch DST usage, we don't use that anymore
		if ( ! is_null($dst) )
		{
			show_error('The ExiteCMS version of the "gmt_to_local" function does not support the DST parameter, but always returns the correct local time');
		}

		// if no time is given, use the current time in GMT
		if ($time == '')
		{
			$time = now();
		}

		// if no timezone is given, fetch the current user/site default
		if ($timezone == '')
		{
			$CI =& get_instance();
			$timezone = $CI->config->item('timezone');
		}

		// if the timezone is not known, default to UTC
		if ( ! $timezone = new_timezones($timezone) )
		{
			$timezone = 'UTC';
		}

		// convert to local time
		if ( is_php('5.2.0') )
		{
			$tz = new DateTimeZone($timezone);
			$tzarray = $tz->getTransitions();

			// did we find timezone offsets
			if ( is_array($tzarray) )
			{
				$tzfound = FALSE;
				foreach ( $tzarray as $tzentry )
				{
					if ( $tzentry['ts'] > $time )
					{
						break;
					}
					$tzfound = $tzentry;
				}
				if ( $tzfound )
				{
					$time += $tzfound['offset'];
				}
			}
		}
		else
		{
			// use the timezone helper for pre PHP 5.2 environments
			$time = timezone_get_gmt_offset($timezone, $time);
		}

		return $time;
	}
}

// ------------------------------------------------------------------------

/**
 * Converts a local Unix timestamp to GMT
 *
 * @access	public
 * @param	integer Unix timestamp
 * @return	integer
 */
if ( ! function_exists('local_to_gmt'))
{
	function local_to_gmt($time = '', $timezone = '')
	{
		if ($time == '')
		{
			return now();
		}

		if ($timezone == '')
		{
			$CI =& get_instance();
			$timezone = $CI->config->item('timezone');
		}

		if ( ! $timezone = new_timezones($timezone) )
		{
			$timezone = 'UTC';
		}

		// convert to local time
		if ( is_php('5.2.0') )
		{
			$tz = new DateTimeZone($timezone);
			$tzarray = $tz->getTransitions();

			// did we find timezone offsets
			if ( is_array($tzarray) )
			{
				$tzfound = FALSE;
				foreach ( $tzarray as $tzentry )
				{
					if ( $tzentry['ts'] > $time )
					{
						break;
					}
					$tzfound = $tzentry;
				}
				if ( $tzfound )
				{
					$time -= $tzfound['offset'];
				}
			}
		}
		else
		{
			// use the timezone helper for pre PHP 5.2 environments
			$time = timezone_get_gmt_offset($timezone, $time, TRUE);
		}

		return $time;
	}
}

// ------------------------------------------------------------------------

/**
 * formdate_to_unix
 *
 * convert the output of {select_html_date} and/or {select_html_time}. Time defaults to 00:00:00
 *
 * @access	public
 * @param	array	input from the array created by the smarty functions
 *					{select_html_date} and/or {select_html_time}, using the field_array option
 * @param	string	field prefix used on the smarty functions (must be the same for date & time!)
 * @param	boolean	allow zero values
 * @return	integer, unix timestamp
 */
if ( ! function_exists('formdate_to_unix'))
{
	function formdate_to_unix($time_array = array(), $prefix = '', $allow_zero = FALSE)
	{
		if ( empty($prefix) )
		{
			$dateprefix = 'Date_';
			$timeprefix = 'Time_';
		}
		else
		{
			$dateprefix = $timeprefix = $prefix;
		}
		// validate and convert the values
		if ( isset($time_array[$dateprefix.'Year']) && is_numeric($time_array[$dateprefix.'Year']) && $time_array[$dateprefix.'Year'] >= 0 && $time_array[$dateprefix.'Year'] < 2038)
		{
			$year = (integer) $time_array[$dateprefix.'Year'];
		}
		else
		{
			if ( $allow_zero && empty($time_array[$dateprefix.'Year']) )
			{
				$year = 0;
			}
			else
			{
				return FALSE;
			}
		}

		if ( isset($time_array[$dateprefix.'Month']) && is_numeric($time_array[$dateprefix.'Month']) && $time_array[$dateprefix.'Month'] > 0 && $time_array[$dateprefix.'Month'] < 13)
		{
			$month = (integer) $time_array[$dateprefix.'Month'];
		}
		else
		{
			if ( $allow_zero && empty($time_array[$dateprefix.'Month']) )
			{
				$month = 0;
			}
			else
			{
				return FALSE;
			}
		}

		if ( isset($time_array[$dateprefix.'Day']) && is_numeric($time_array[$dateprefix.'Day']) && $time_array[$dateprefix.'Day'] > 0 && $time_array[$dateprefix.'Day'] < 32)
		{
			$day = (integer) $time_array[$dateprefix.'Day'];
		}
		else
		{
			if ( $allow_zero && empty($time_array[$dateprefix.'Day']) )
			{
				$day = 0;
			}
			else
			{
				return FALSE;
			}
		}

		if ( isset($time_array[$prefix.'Time_Hour']) && is_numeric($time_array[$prefix.'Time_Hour']) && $time_array[$prefix.'Time_Hour'] >= 0 && $time_array[$prefix.'Time_Hour'] < 24)
		{
			$hour = (integer) $time_array[$prefix.'Time_Hour'];
		}
		else
		{
			$hour = 0;
		}

		if ( isset($time_array[$prefix.'Time_Minute']) && is_numeric($time_array[$prefix.'Time_Minute']) && $time_array[$prefix.'Time_Minute'] >= 0 && $time_array[$prefix.'Time_Minute'] < 60)
		{
			$minute = (integer) $time_array[$prefix.'Time_Minute'];
		}
		else
		{
			$minute = 0;
		}

		if ( isset($time_array[$prefix.'Time_Second']) && is_numeric($time_array[$prefix.'Time_Second']) && $time_array[$prefix.'Time_Second'] >= 0 && $time_array[$prefix.'Time_Second'] < 60)
		{
			$second = (integer) $time_array[$prefix.'Time_Second'];
		}
		else
		{
			$second = 0;
		}

		// convert the values to a timestamp
		if ( $allow_zero && ( $year + $month + $day + $hour + $minute + $second) == 0 )
		{
			return 0;
		}
		else
		{
			// check if the date is valid
			if ( checkdate($month, $day, $year) )
			{
				// catch pre PHP 5.1.0 return value of -1 instead of FALSE
				$time = mktime($hour, $minute, $second, $month, $day, $year);
				return ( $time === -1 OR $time === FALSE ) ? FALSE : $time;
			}
			else
			{
				return FALSE;
			}
		}
	}
}

/**
 * formdate_to_human
 *
 * convert the output of {select_html_date} and/or {select_html_time}. Time defaults to 00:00:00
 *
 * @access	public
 * @param	array	input from the array created by the smarty functions
 *					{select_html_date} and/or {select_html_time}, using the field_array option
 * @return	string, Y-m-d H:i:s
 */
if ( ! function_exists('formdate_to_human'))
{
	function formdate_to_human($time_array = array(), $prefix = '' )
	{
		$time = formdate_to_unix($time_array, $prefix);
		if ( $time )
		{
			// convert the values to a time string
			return date('Y-m-d H:i:s', $time);
		}
		else
		{
			return FALSE;
		}
	}
}

// ------------------------------------------------------------------------

///**
// * Timezone Menu
// *
// * Generates a drop-down menu of timezones.
// *
// * @access	public
// * @param	string	timezone
// * @param	string	classname
// * @param	string	menu name
// * @return	string
// */
//if ( ! function_exists('timezone_menu'))
//{
//	function timezone_menu($default = 'T405', $class = "", $name = 'timezones', $id = 'timezones', $style = "")
//	{
//		$CI =& get_instance();
//		$CI->lang->load('date');
//
//		if ( ! new_timezones($default) )
//			$default = 'T405';
//
//		$menu = '<select name="'.$name.'" id="'.$id.'"';
//
//		if ($class != '')
//		{
//			$menu .= ' class="'.$class.'"';
//		}
//
//		if ($style != '')
//		{
//			$menu .= ' style="'.$style.'"';
//		}
//
//		$menu .= ">\n";
//
//		$opt = FALSE;
//		$continent = '';
//		foreach (new_timezones() as $key => $val)
//		{
//			$selected = ($default == $key) ? " selected='selected'" : '';
//			$line = $CI->lang->line($key);
//			$line = ( $line == $key ? $val : $line );
//
//			if ( preg_match( '/^(Africa|America|Antartica|Arctic|Antarctica|Australia|Asia|Atlantic|Europe|Indian|Pacific)\//', $val ) )
//			{
//				$ex = explode( "/", $val );	//obtain continent,city
//				if ( $continent != $ex[0] )
//				{
//					if ( $continent != "") {
//						$menu .= '</optgroup>'."\n";
//						$opt = FALSE;
//					}
//					if ( isset($ex[1]) )
//					{
//						$menu .= '<optgroup label="'.$ex[0].'">'."\n";
//						$opt = TRUE;
//					}
//				}
//				$continent = $ex[0];
//				$val = implode(' &raquo; ', array_slice($ex, 1));
//			}
//			else
//			{
//				if ( $opt ) {
//					$menu .= '</optgroup>'."\n";
//					$opt = FALSE;
//				}
//			}
//			$menu .= "\t".'<option value="'.$key.'"'.$selected.'>&raquo; '.str_replace('_', ' ', $val).'</option>'."\n";
//		}
//
//		if ( $opt ) {
//			$menu .= '</optgroup>'."\n";
//		}
//
//		$menu .= "</select>";
//
//		return $menu;
//	}
//}

// ------------------------------------------------------------------------

/**
 * ExiteCMS version of CI's timezones helper
 *
 * Returns an array of timezones.  This is a helper function
 * for various other ones in this library
 *
 * @access	public
 * @param	string	timezone
 * @return	string
 */
if ( ! function_exists('new_timezones'))
{
	function new_timezones($tz = '')
	{
		// CI zone code conversion table
		static $oldzones = array(
//				'UM12'		=> '?',
				'UM11'		=> 'T389',
				'UM10'		=> 'T399',
				'UM95'		=> 'T386',
				'UM9'		=> 'T052',
				'UM8'		=> 'T128',
				'UM7'		=> 'T093',
				'UM6'		=> 'T085',
				'UM5'		=> 'T146',
				'UM45'		=> 'T082',
				'UM4'		=> 'T109',
				'UM35'		=> 'T175',
				'UM3'		=> 'T166',
				'UM2'		=> 'T286',
				'UM1'		=> 'T279',
				'GMT'		=> 'T405',
				'UTC'		=> 'T405',
				'UP1'		=> 'T307',
				'UP2'		=> 'T304',
				'UP3'		=> 'T330',
				'UP35'		=> 'T269',
				'UP4'		=> 'T212',
				'UP45'		=> 'T234',
				'UP5'		=> 'T236',
				'UP55'		=> 'T219',
				'UP575'		=> 'T238',
				'UP6'		=> 'T221',
				'UP65'		=> 'T259',
				'UP7'		=> 'T213',
				'UP8'		=> 'T264',
				'UP875'		=> 'T299',
				'UP9'		=> 'T271',
				'UP95'		=> 'T289',
				'UP10'		=> 'T300',
				'UP105'		=> 'T297',
				'UP11'		=> 'T245',
				'UP115'		=> 'T390',
				'UP12'		=> 'T368',
				'UP1275'	=> 'T369',
				'UP13'		=> 'T401',
				'UP14'		=> 'T382'
			);

		static $zones = array (
			'T128' => 'UTC',
			'T000' => 'Africa/Abidjan',
			'T001' => 'Africa/Accra',
			'T002' => 'Africa/Addis_Ababa',
			'T003' => 'Africa/Algiers',
			'T004' => 'Africa/Asmara',
			'T005' => 'Africa/Bamako',
			'T006' => 'Africa/Bangui',
			'T007' => 'Africa/Banjul',
			'T008' => 'Africa/Bissau',
			'T009' => 'Africa/Blantyre',
			'T010' => 'Africa/Brazzaville',
			'T011' => 'Africa/Bujumbura',
			'T012' => 'Africa/Cairo',
			'T013' => 'Africa/Casablanca',
			'T014' => 'Africa/Ceuta',
			'T015' => 'Africa/Conakry',
			'T016' => 'Africa/Dakar',
			'T017' => 'Africa/Dar_es_Salaam',
			'T018' => 'Africa/Djibouti',
			'T019' => 'Africa/Douala',
			'T020' => 'Africa/El_Aaiun',
			'T021' => 'Africa/Freetown',
			'T022' => 'Africa/Gaborone',
			'T023' => 'Africa/Harare',
			'T024' => 'Africa/Johannesburg',
			'T025' => 'Africa/Kampala',
			'T026' => 'Africa/Khartoum',
			'T027' => 'Africa/Kigali',
			'T028' => 'Africa/Kinshasa',
			'T029' => 'Africa/Lagos',
			'T030' => 'Africa/Libreville',
			'T031' => 'Africa/Lome',
			'T032' => 'Africa/Luanda',
			'T033' => 'Africa/Lubumbashi',
			'T034' => 'Africa/Lusaka',
			'T035' => 'Africa/Malabo',
			'T036' => 'Africa/Maputo',
			'T037' => 'Africa/Maseru',
			'T038' => 'Africa/Mbabane',
			'T039' => 'Africa/Mogadishu',
			'T040' => 'Africa/Monrovia',
			'T041' => 'Africa/Nairobi',
			'T042' => 'Africa/Ndjamena',
			'T043' => 'Africa/Niamey',
			'T044' => 'Africa/Nouakchott',
			'T045' => 'Africa/Ouagadougou',
			'T046' => 'Africa/Porto-Novo',
			'T047' => 'Africa/Sao_Tome',
			'T048' => 'Africa/Tripoli',
			'T049' => 'Africa/Tunis',
			'T050' => 'Africa/Windhoek',
			'T051' => 'America/Adak',
			'T052' => 'America/Anchorage',
			'T053' => 'America/Anguilla',
			'T054' => 'America/Antigua',
			'T055' => 'America/Araguaina',
			'T056' => 'America/Argentina/Buenos_Aires',
			'T057' => 'America/Argentina/Catamarca',
			'T058' => 'America/Argentina/Cordoba',
			'T059' => 'America/Argentina/Jujuy',
			'T060' => 'America/Argentina/La_Rioja',
			'T061' => 'America/Argentina/Mendoza',
			'T062' => 'America/Argentina/Rio_Gallegos',
			'T063' => 'America/Argentina/Salta',
			'T064' => 'America/Argentina/San_Juan',
			'T065' => 'America/Argentina/San_Luis',
			'T066' => 'America/Argentina/Tucuman',
			'T067' => 'America/Argentina/Ushuaia',
			'T068' => 'America/Aruba',
			'T069' => 'America/Asuncion',
			'T070' => 'America/Atikokan',
			'T071' => 'America/Bahia',
			'T072' => 'America/Barbados',
			'T073' => 'America/Belem',
			'T074' => 'America/Belize',
			'T075' => 'America/Blanc-Sablon',
			'T076' => 'America/Boa_Vista',
			'T077' => 'America/Bogota',
			'T078' => 'America/Boise',
			'T079' => 'America/Cambridge_Bay',
			'T080' => 'America/Campo_Grande',
			'T081' => 'America/Cancun',
			'T082' => 'America/Caracas',
			'T083' => 'America/Cayenne',
			'T084' => 'America/Cayman',
			'T085' => 'America/Chicago',
			'T086' => 'America/Chihuahua',
			'T087' => 'America/Costa_Rica',
			'T088' => 'America/Cuiaba',
			'T089' => 'America/Curacao',
			'T090' => 'America/Danmarkshavn',
			'T091' => 'America/Dawson',
			'T092' => 'America/Dawson_Creek',
			'T093' => 'America/Denver',
			'T094' => 'America/Detroit',
			'T095' => 'America/Dominica',
			'T096' => 'America/Edmonton',
			'T097' => 'America/Eirunepe',
			'T098' => 'America/El_Salvador',
			'T099' => 'America/Fortaleza',
			'T100' => 'America/Glace_Bay',
			'T101' => 'America/Godthab',
			'T102' => 'America/Goose_Bay',
			'T103' => 'America/Grand_Turk',
			'T104' => 'America/Grenada',
			'T105' => 'America/Guadeloupe',
			'T106' => 'America/Guatemala',
			'T107' => 'America/Guayaquil',
			'T108' => 'America/Guyana',
			'T109' => 'America/Halifax',
			'T110' => 'America/Havana',
			'T111' => 'America/Hermosillo',
			'T112' => 'America/Indiana/Indianapolis',
			'T113' => 'America/Indiana/Knox',
			'T114' => 'America/Indiana/Marengo',
			'T115' => 'America/Indiana/Petersburg',
			'T116' => 'America/Indiana/Tell_City',
			'T117' => 'America/Indiana/Vevay',
			'T118' => 'America/Indiana/Vincennes',
			'T119' => 'America/Indiana/Winamac',
			'T120' => 'America/Inuvik',
			'T121' => 'America/Iqaluit',
			'T122' => 'America/Jamaica',
			'T123' => 'America/Juneau',
			'T124' => 'America/Kentucky/Louisville',
			'T125' => 'America/Kentucky/Monticello',
			'T126' => 'America/La_Paz',
			'T127' => 'America/Lima',
			'T128' => 'America/Los_Angeles',
			'T129' => 'America/Maceio',
			'T130' => 'America/Managua',
			'T131' => 'America/Manaus',
			'T132' => 'America/Marigot',
			'T133' => 'America/Martinique',
			'T134' => 'America/Matamoros',
			'T135' => 'America/Mazatlan',
			'T136' => 'America/Menominee',
			'T137' => 'America/Merida',
			'T138' => 'America/Mexico_City',
			'T139' => 'America/Miquelon',
			'T140' => 'America/Moncton',
			'T141' => 'America/Monterrey',
			'T142' => 'America/Montevideo',
			'T143' => 'America/Montreal',
			'T144' => 'America/Montserrat',
			'T145' => 'America/Nassau',
			'T146' => 'America/New_York',
			'T147' => 'America/Nipigon',
			'T148' => 'America/Nome',
			'T149' => 'America/Noronha',
			'T150' => 'America/North_Dakota/Center',
			'T151' => 'America/North_Dakota/New_Salem',
			'T152' => 'America/Ojinaga',
			'T153' => 'America/Panama',
			'T154' => 'America/Pangnirtung',
			'T155' => 'America/Paramaribo',
			'T156' => 'America/Phoenix',
			'T157' => 'America/Port-au-Prince',
			'T158' => 'America/Port_of_Spain',
			'T159' => 'America/Porto_Velho',
			'T160' => 'America/Puerto_Rico',
			'T161' => 'America/Rainy_River',
			'T162' => 'America/Rankin_Inlet',
			'T163' => 'America/Recife',
			'T164' => 'America/Regina',
			'T165' => 'America/Resolute',
			'T166' => 'America/Rio_Branco',
			'T167' => 'America/Santa_Isabel',
			'T168' => 'America/Santarem',
			'T169' => 'America/Santiago',
			'T170' => 'America/Santo_Domingo',
			'T171' => 'America/Sao_Paulo',
			'T172' => 'America/Scoresbysund',
			'T173' => 'America/Shiprock',
			'T174' => 'America/St_Barthelemy',
			'T175' => 'America/St_Johns',
			'T176' => 'America/St_Kitts',
			'T177' => 'America/St_Lucia',
			'T178' => 'America/St_Thomas',
			'T179' => 'America/St_Vincent',
			'T180' => 'America/Swift_Current',
			'T181' => 'America/Tegucigalpa',
			'T182' => 'America/Thule',
			'T183' => 'America/Thunder_Bay',
			'T184' => 'America/Tijuana',
			'T185' => 'America/Toronto',
			'T186' => 'America/Tortola',
			'T187' => 'America/Vancouver',
			'T188' => 'America/Whitehorse',
			'T189' => 'America/Winnipeg',
			'T190' => 'America/Yakutat',
			'T191' => 'America/Yellowknife',
			'T192' => 'Antarctica/Casey',
			'T193' => 'Antarctica/Davis',
			'T194' => 'Antarctica/DumontDUrville',
			'T195' => 'Antarctica/Mawson',
			'T196' => 'Antarctica/McMurdo',
			'T197' => 'Antarctica/Palmer',
			'T198' => 'Antarctica/Rothera',
			'T199' => 'Antarctica/South_Pole',
			'T200' => 'Antarctica/Syowa',
			'T201' => 'Antarctica/Vostok',
			'T202' => 'Arctic/Longyearbyen',
			'T203' => 'Asia/Aden',
			'T204' => 'Asia/Almaty',
			'T205' => 'Asia/Amman',
			'T206' => 'Asia/Anadyr',
			'T207' => 'Asia/Aqtau',
			'T208' => 'Asia/Aqtobe',
			'T209' => 'Asia/Ashgabat',
			'T210' => 'Asia/Baghdad',
			'T211' => 'Asia/Bahrain',
			'T212' => 'Asia/Baku',
			'T213' => 'Asia/Bangkok',
			'T214' => 'Asia/Beirut',
			'T215' => 'Asia/Bishkek',
			'T216' => 'Asia/Brunei',
			'T217' => 'Asia/Choibalsan',
			'T218' => 'Asia/Chongqing',
			'T219' => 'Asia/Colombo',
			'T220' => 'Asia/Damascus',
			'T221' => 'Asia/Dhaka',
			'T222' => 'Asia/Dili',
			'T223' => 'Asia/Dubai',
			'T224' => 'Asia/Dushanbe',
			'T225' => 'Asia/Gaza',
			'T226' => 'Asia/Harbin',
			'T227' => 'Asia/Ho_Chi_Minh',
			'T228' => 'Asia/Hong_Kong',
			'T229' => 'Asia/Hovd',
			'T230' => 'Asia/Irkutsk',
			'T231' => 'Asia/Jakarta',
			'T232' => 'Asia/Jayapura',
			'T233' => 'Asia/Jerusalem',
			'T234' => 'Asia/Kabul',
			'T235' => 'Asia/Kamchatka',
			'T236' => 'Asia/Karachi',
			'T237' => 'Asia/Kashgar',
			'T238' => 'Asia/Kathmandu',
			'T239' => 'Asia/Kolkata',
			'T240' => 'Asia/Krasnoyarsk',
			'T241' => 'Asia/Kuala_Lumpur',
			'T242' => 'Asia/Kuching',
			'T243' => 'Asia/Kuwait',
			'T244' => 'Asia/Macau',
			'T245' => 'Asia/Magadan',
			'T246' => 'Asia/Makassar',
			'T247' => 'Asia/Manila',
			'T248' => 'Asia/Muscat',
			'T249' => 'Asia/Nicosia',
			'T250' => 'Asia/Novokuznetsk',
			'T251' => 'Asia/Novosibirsk',
			'T252' => 'Asia/Omsk',
			'T253' => 'Asia/Oral',
			'T254' => 'Asia/Phnom_Penh',
			'T255' => 'Asia/Pontianak',
			'T256' => 'Asia/Pyongyang',
			'T257' => 'Asia/Qatar',
			'T258' => 'Asia/Qyzylorda',
			'T259' => 'Asia/Rangoon',
			'T260' => 'Asia/Riyadh',
			'T261' => 'Asia/Sakhalin',
			'T262' => 'Asia/Samarkand',
			'T263' => 'Asia/Seoul',
			'T264' => 'Asia/Shanghai',
			'T265' => 'Asia/Singapore',
			'T266' => 'Asia/Taipei',
			'T267' => 'Asia/Tashkent',
			'T268' => 'Asia/Tbilisi',
			'T269' => 'Asia/Tehran',
			'T270' => 'Asia/Thimphu',
			'T271' => 'Asia/Tokyo',
			'T272' => 'Asia/Ulaanbaatar',
			'T273' => 'Asia/Urumqi',
			'T274' => 'Asia/Vientiane',
			'T275' => 'Asia/Vladivostok',
			'T276' => 'Asia/Yakutsk',
			'T277' => 'Asia/Yekaterinburg',
			'T278' => 'Asia/Yerevan',
			'T279' => 'Atlantic/Azores',
			'T280' => 'Atlantic/Bermuda',
			'T281' => 'Atlantic/Canary',
			'T282' => 'Atlantic/Cape_Verde',
			'T283' => 'Atlantic/Faroe',
			'T284' => 'Atlantic/Madeira',
			'T285' => 'Atlantic/Reykjavik',
			'T286' => 'Atlantic/South_Georgia',
			'T287' => 'Atlantic/St_Helena',
			'T288' => 'Atlantic/Stanley',
			'T289' => 'Australia/Adelaide',
			'T290' => 'Australia/Brisbane',
			'T291' => 'Australia/Broken_Hill',
			'T292' => 'Australia/Currie',
			'T293' => 'Australia/Darwin',
			'T294' => 'Australia/Eucla',
			'T295' => 'Australia/Hobart',
			'T296' => 'Australia/Lindeman',
			'T297' => 'Australia/Lord_Howe',
			'T298' => 'Australia/Melbourne',
			'T299' => 'Australia/Perth',
			'T300' => 'Australia/Sydney',
			'T301' => 'Europe/Amsterdam',
			'T302' => 'Europe/Andorra',
			'T303' => 'Europe/Athens',
			'T304' => 'Europe/Belgrade',
			'T305' => 'Europe/Berlin',
			'T306' => 'Europe/Bratislava',
			'T307' => 'Europe/Brussels',
			'T308' => 'Europe/Bucharest',
			'T309' => 'Europe/Budapest',
			'T310' => 'Europe/Chisinau',
			'T311' => 'Europe/Copenhagen',
			'T312' => 'Europe/Dublin',
			'T313' => 'Europe/Gibraltar',
			'T314' => 'Europe/Guernsey',
			'T315' => 'Europe/Helsinki',
			'T316' => 'Europe/Isle_of_Man',
			'T317' => 'Europe/Istanbul',
			'T318' => 'Europe/Jersey',
			'T319' => 'Europe/Kaliningrad',
			'T320' => 'Europe/Kiev',
			'T321' => 'Europe/Lisbon',
			'T322' => 'Europe/Ljubljana',
			'T323' => 'Europe/London',
			'T324' => 'Europe/Luxembourg',
			'T325' => 'Europe/Madrid',
			'T326' => 'Europe/Malta',
			'T327' => 'Europe/Mariehamn',
			'T328' => 'Europe/Minsk',
			'T329' => 'Europe/Monaco',
			'T330' => 'Europe/Moscow',
			'T331' => 'Europe/Oslo',
			'T332' => 'Europe/Paris',
			'T333' => 'Europe/Podgorica',
			'T334' => 'Europe/Prague',
			'T335' => 'Europe/Riga',
			'T336' => 'Europe/Rome',
			'T337' => 'Europe/Samara',
			'T338' => 'Europe/San_Marino',
			'T339' => 'Europe/Sarajevo',
			'T340' => 'Europe/Simferopol',
			'T341' => 'Europe/Skopje',
			'T342' => 'Europe/Sofia',
			'T343' => 'Europe/Stockholm',
			'T344' => 'Europe/Tallinn',
			'T345' => 'Europe/Tirane',
			'T346' => 'Europe/Uzhgorod',
			'T347' => 'Europe/Vaduz',
			'T348' => 'Europe/Vatican',
			'T349' => 'Europe/Vienna',
			'T350' => 'Europe/Vilnius',
			'T351' => 'Europe/Volgograd',
			'T352' => 'Europe/Warsaw',
			'T353' => 'Europe/Zagreb',
			'T354' => 'Europe/Zaporozhye',
			'T355' => 'Europe/Zurich',
			'T356' => 'Indian/Antananarivo',
			'T357' => 'Indian/Chagos',
			'T358' => 'Indian/Christmas',
			'T359' => 'Indian/Cocos',
			'T360' => 'Indian/Comoro',
			'T361' => 'Indian/Kerguelen',
			'T362' => 'Indian/Mahe',
			'T363' => 'Indian/Maldives',
			'T364' => 'Indian/Mauritius',
			'T365' => 'Indian/Mayotte',
			'T366' => 'Indian/Reunion',
			'T367' => 'Pacific/Apia',
			'T368' => 'Pacific/Auckland',
			'T369' => 'Pacific/Chatham',
			'T370' => 'Pacific/Easter',
			'T371' => 'Pacific/Efate',
			'T372' => 'Pacific/Enderbury',
			'T373' => 'Pacific/Fakaofo',
			'T374' => 'Pacific/Fiji',
			'T375' => 'Pacific/Funafuti',
			'T376' => 'Pacific/Galapagos',
			'T377' => 'Pacific/Gambier',
			'T378' => 'Pacific/Guadalcanal',
			'T379' => 'Pacific/Guam',
			'T380' => 'Pacific/Honolulu',
			'T381' => 'Pacific/Johnston',
			'T382' => 'Pacific/Kiritimati',
			'T383' => 'Pacific/Kosrae',
			'T384' => 'Pacific/Kwajalein',
			'T385' => 'Pacific/Majuro',
			'T386' => 'Pacific/Marquesas',
			'T387' => 'Pacific/Midway',
			'T388' => 'Pacific/Nauru',
			'T389' => 'Pacific/Niue',
			'T390' => 'Pacific/Norfolk',
			'T391' => 'Pacific/Noumea',
			'T392' => 'Pacific/Pago_Pago',
			'T393' => 'Pacific/Palau',
			'T394' => 'Pacific/Pitcairn',
			'T395' => 'Pacific/Ponape',
			'T396' => 'Pacific/Port_Moresby',
			'T397' => 'Pacific/Rarotonga',
			'T398' => 'Pacific/Saipan',
			'T399' => 'Pacific/Tahiti',
			'T400' => 'Pacific/Tarawa',
			'T401' => 'Pacific/Tongatapu',
			'T402' => 'Pacific/Truk',
			'T403' => 'Pacific/Wake',
			'T404' => 'Pacific/Wallis'
		);

		if ($tz == '')
		{
			return $zones;
		}

		if ( isset($oldzones[$tz]) )
		{
			$tz = $oldzones[$tz];
		}

		return ( ! isset($zones[$tz])) ? 0 : $zones[$tz];
	}
}

// ------------------------------------------------------------------------

/**
 * add to date
 *
 * When passed an array with date and/or time offset values, these values will be added to the
 * date passed. If no date is passed, now() is used.
 * This is typically used with the output of the Smarty functions {html_select_date} and {html_select_time}
 *
 * @access	public
 * @param	array	date and time values
 * @param	string	classname
 * @param	string	menu name
 * @return	string
 */
if ( ! function_exists('add_to_date'))
{
	function add_to_date($time_array = array(), $prefix = '', $time = NULL )
	{
		if ( is_null($time) )
		{
			$time = now();
		}
		if ( is_array($time_array) )
		{
			if ( empty($prefix) )
			{
				$dateprefix = 'Date_';
				$timeprefix = 'Time_';
			}
			else
			{
				$dateprefix = $timeprefix = $prefix;
			}
			// validate and convert the values
			if ( isset($time_array[$dateprefix.'Year']) && is_numeric($time_array[$dateprefix.'Year']) && $time_array[$dateprefix.'Year'] >= 0 && $time_array[$dateprefix.'Year'] < 2038)
			{
				$year = (integer) $time_array[$dateprefix.'Year'];
			}
			else
			{
				$year = 0;
			}

			if ( isset($time_array[$dateprefix.'Month']) && is_numeric($time_array[$dateprefix.'Month']) && $time_array[$dateprefix.'Month'] > 0 && $time_array[$dateprefix.'Month'] < 13)
			{
				$month = (integer) $time_array[$dateprefix.'Month'];
			}
			else
			{
				$month = 0;
			}

			if ( isset($time_array[$dateprefix.'Day']) && is_numeric($time_array[$dateprefix.'Day']) && $time_array[$dateprefix.'Day'] > 0 && $time_array[$dateprefix.'Day'] < 32)
			{
				$day = (integer) $time_array[$dateprefix.'Day'];
			}
			else
			{
				$day = 0;
			}

			if ( isset($time_array[$prefix.'Time_Hour']) && is_numeric($time_array[$prefix.'Time_Hour']) && $time_array[$prefix.'Time_Hour'] >= 0 && $time_array[$prefix.'Time_Hour'] < 24)
			{
				$hour = (integer) $time_array[$prefix.'Time_Hour'];
			}
			else
			{
				$hour = 0;
			}

			if ( isset($time_array[$prefix.'Time_Minute']) && is_numeric($time_array[$prefix.'Time_Minute']) && $time_array[$prefix.'Time_Minute'] >= 0 && $time_array[$prefix.'Time_Minute'] < 60)
			{
				$minute = (integer) $time_array[$prefix.'Time_Minute'];
			}
			else
			{
				$minute = 0;
			}

			if ( isset($time_array[$prefix.'Time_Second']) && is_numeric($time_array[$prefix.'Time_Second']) && $time_array[$prefix.'Time_Second'] >= 0 && $time_array[$prefix.'Time_Second'] < 60)
			{
				$second = (integer) $time_array[$prefix.'Time_Second'];
			}
			else
			{
				$second = 0;
			}
			// was a start time given?
			if ( $time == 0 )
			{
				return $second + $minute * 60 + $hour * 3600 + $day * 86400;
			}
			else
			{
				return mktime( date('H',$time)+$hour, date('i',$time)+$minute, date('s',$time)+$second, date('n',$time)+$month, date('j',$time)+$day, date('Y',$time)+$year );
			}
		}
		// parameter not an array
		return $time;
	}
}

/**
 * Timezone Menu
 *
 * Generates a drop-down menu of timezones.
 *
 * @access	public
 * @param	string	timezone
 * @param	string	classname
 * @param	string	menu name
 * @return	string
 */
if ( ! function_exists('timezone_menu'))
{
	function timezone_menu($default = 'T405')
	{
		$menu = '
<select name="timezone" id="timezones">
	<option value="T405">&raquo; UTC</option>
<optgroup label="United States">
        <option value="T052">&raquo; Alaska</option>
        <option value="T380">&raquo; Hawaii</option>
        <option value="T128">&raquo; Pacific Time</option>
        <option value="T078">&raquo; Mountain Time</option>
        <option value="T156">&raquo; Mountain Time &raquo; Phoenix</option>
        <option value="T150">&raquo; Central Time</option>
        <option value="T146">&raquo; Eastern Time</option>
</optgroup>
<optgroup label="Africa">
	<option value="T000">&raquo; Abidjan</option>
	<option value="T001">&raquo; Accra</option>
	<option value="T002">&raquo; Addis Ababa</option>
	<option value="T003">&raquo; Algiers</option>
	<option value="T004">&raquo; Asmara</option>
	<option value="T005">&raquo; Bamako</option>
	<option value="T006">&raquo; Bangui</option>
	<option value="T007">&raquo; Banjul</option>
	<option value="T008">&raquo; Bissau</option>
	<option value="T009">&raquo; Blantyre</option>
	<option value="T010">&raquo; Brazzaville</option>
	<option value="T011">&raquo; Bujumbura</option>
	<option value="T012">&raquo; Cairo</option>
	<option value="T013">&raquo; Casablanca</option>
	<option value="T014">&raquo; Ceuta</option>
	<option value="T015">&raquo; Conakry</option>
	<option value="T016">&raquo; Dakar</option>
	<option value="T017">&raquo; Dar es Salaam</option>
	<option value="T018">&raquo; Djibouti</option>
	<option value="T019">&raquo; Douala</option>
	<option value="T020">&raquo; El Aaiun</option>
	<option value="T021">&raquo; Freetown</option>
	<option value="T022">&raquo; Gaborone</option>
	<option value="T023">&raquo; Harare</option>
	<option value="T024">&raquo; Johannesburg</option>
	<option value="T025">&raquo; Kampala</option>
	<option value="T026">&raquo; Khartoum</option>
	<option value="T027">&raquo; Kigali</option>
	<option value="T028">&raquo; Kinshasa</option>
	<option value="T029">&raquo; Lagos</option>
	<option value="T030">&raquo; Libreville</option>
	<option value="T031">&raquo; Lome</option>
	<option value="T032">&raquo; Luanda</option>
	<option value="T033">&raquo; Lubumbashi</option>
	<option value="T034">&raquo; Lusaka</option>
	<option value="T035">&raquo; Malabo</option>
	<option value="T036">&raquo; Maputo</option>
	<option value="T037">&raquo; Maseru</option>
	<option value="T038">&raquo; Mbabane</option>
	<option value="T039">&raquo; Mogadishu</option>
	<option value="T040">&raquo; Monrovia</option>
	<option value="T041">&raquo; Nairobi</option>
	<option value="T042">&raquo; Ndjamena</option>
	<option value="T043">&raquo; Niamey</option>
	<option value="T044">&raquo; Nouakchott</option>
	<option value="T045">&raquo; Ouagadougou</option>
	<option value="T046">&raquo; Porto-Novo</option>
	<option value="T047">&raquo; Sao Tome</option>
	<option value="T048">&raquo; Tripoli</option>
	<option value="T049">&raquo; Tunis</option>
	<option value="T050">&raquo; Windhoek</option>
</optgroup>
<optgroup label="America">
	<option value="T051">&raquo; Adak</option>
	<option value="T052">&raquo; Anchorage</option>
	<option value="T053">&raquo; Anguilla</option>
	<option value="T054">&raquo; Antigua</option>
	<option value="T055">&raquo; Araguaina</option>
	<option value="T056">&raquo; Argentina &raquo; Buenos Aires</option>
	<option value="T057">&raquo; Argentina &raquo; Catamarca</option>
	<option value="T058">&raquo; Argentina &raquo; Cordoba</option>
	<option value="T059">&raquo; Argentina &raquo; Jujuy</option>
	<option value="T060">&raquo; Argentina &raquo; La Rioja</option>
	<option value="T061">&raquo; Argentina &raquo; Mendoza</option>
	<option value="T062">&raquo; Argentina &raquo; Rio Gallegos</option>
	<option value="T063">&raquo; Argentina &raquo; Salta</option>
	<option value="T064">&raquo; Argentina &raquo; San Juan</option>
	<option value="T065">&raquo; Argentina &raquo; San Luis</option>
	<option value="T066">&raquo; Argentina &raquo; Tucuman</option>
	<option value="T067">&raquo; Argentina &raquo; Ushuaia</option>
	<option value="T068">&raquo; Aruba</option>
	<option value="T069">&raquo; Asuncion</option>
	<option value="T070">&raquo; Atikokan</option>
	<option value="T071">&raquo; Bahia</option>
	<option value="T072">&raquo; Barbados</option>
	<option value="T073">&raquo; Belem</option>
	<option value="T074">&raquo; Belize</option>
	<option value="T075">&raquo; Blanc-Sablon</option>
	<option value="T076">&raquo; Boa Vista</option>
	<option value="T077">&raquo; Bogota</option>
	<option value="T078">&raquo; Boise</option>
	<option value="T079">&raquo; Cambridge Bay</option>
	<option value="T080">&raquo; Campo Grande</option>
	<option value="T081">&raquo; Cancun</option>
	<option value="T082">&raquo; Caracas</option>
	<option value="T083">&raquo; Cayenne</option>
	<option value="T084">&raquo; Cayman</option>
	<option value="T085">&raquo; Chicago</option>
	<option value="T086">&raquo; Chihuahua</option>
	<option value="T087">&raquo; Costa Rica</option>
	<option value="T088">&raquo; Cuiaba</option>
	<option value="T089">&raquo; Curacao</option>
	<option value="T090">&raquo; Danmarkshavn</option>
	<option value="T091">&raquo; Dawson</option>
	<option value="T092">&raquo; Dawson Creek</option>
	<option value="T093">&raquo; Denver</option>
	<option value="T094">&raquo; Detroit</option>
	<option value="T095">&raquo; Dominica</option>
	<option value="T096">&raquo; Edmonton</option>
	<option value="T097">&raquo; Eirunepe</option>
	<option value="T098">&raquo; El Salvador</option>
	<option value="T099">&raquo; Fortaleza</option>
	<option value="T100">&raquo; Glace Bay</option>
	<option value="T101">&raquo; Godthab</option>
	<option value="T102">&raquo; Goose Bay</option>
	<option value="T103">&raquo; Grand Turk</option>
	<option value="T104">&raquo; Grenada</option>
	<option value="T105">&raquo; Guadeloupe</option>
	<option value="T106">&raquo; Guatemala</option>
	<option value="T107">&raquo; Guayaquil</option>
	<option value="T108">&raquo; Guyana</option>
	<option value="T109">&raquo; Halifax</option>
	<option value="T110">&raquo; Havana</option>
	<option value="T111">&raquo; Hermosillo</option>
	<option value="T112">&raquo; Indiana &raquo; Indianapolis</option>
	<option value="T113">&raquo; Indiana &raquo; Knox</option>
	<option value="T114">&raquo; Indiana &raquo; Marengo</option>
	<option value="T115">&raquo; Indiana &raquo; Petersburg</option>
	<option value="T116">&raquo; Indiana &raquo; Tell City</option>
	<option value="T117">&raquo; Indiana &raquo; Vevay</option>
	<option value="T118">&raquo; Indiana &raquo; Vincennes</option>
	<option value="T119">&raquo; Indiana &raquo; Winamac</option>
	<option value="T120">&raquo; Inuvik</option>
	<option value="T121">&raquo; Iqaluit</option>
	<option value="T122">&raquo; Jamaica</option>
	<option value="T123">&raquo; Juneau</option>
	<option value="T124">&raquo; Kentucky &raquo; Louisville</option>
	<option value="T125">&raquo; Kentucky &raquo; Monticello</option>
	<option value="T126">&raquo; La Paz</option>
	<option value="T127">&raquo; Lima</option>
	<option value="T128">&raquo; Los Angeles</option>
	<option value="T129">&raquo; Maceio</option>
	<option value="T130">&raquo; Managua</option>
	<option value="T131">&raquo; Manaus</option>
	<option value="T132">&raquo; Marigot</option>
	<option value="T133">&raquo; Martinique</option>
	<option value="T134">&raquo; Matamoros</option>
	<option value="T135">&raquo; Mazatlan</option>
	<option value="T136">&raquo; Menominee</option>
	<option value="T137">&raquo; Merida</option>
	<option value="T138">&raquo; Mexico City</option>
	<option value="T139">&raquo; Miquelon</option>
	<option value="T140">&raquo; Moncton</option>
	<option value="T141">&raquo; Monterrey</option>
	<option value="T142">&raquo; Montevideo</option>
	<option value="T143">&raquo; Montreal</option>
	<option value="T144">&raquo; Montserrat</option>
	<option value="T145">&raquo; Nassau</option>
	<option value="T146">&raquo; New York</option>
	<option value="T147">&raquo; Nipigon</option>
	<option value="T148">&raquo; Nome</option>
	<option value="T149">&raquo; Noronha</option>
	<option value="T150">&raquo; North Dakota &raquo; Center</option>
	<option value="T151">&raquo; North Dakota &raquo; New Salem</option>
	<option value="T152">&raquo; Ojinaga</option>
	<option value="T153">&raquo; Panama</option>
	<option value="T154">&raquo; Pangnirtung</option>
	<option value="T155">&raquo; Paramaribo</option>
	<option value="T156">&raquo; Phoenix</option>
	<option value="T157">&raquo; Port-au-Prince</option>
	<option value="T158">&raquo; Port of Spain</option>
	<option value="T159">&raquo; Porto Velho</option>
	<option value="T160">&raquo; Puerto Rico</option>
	<option value="T161">&raquo; Rainy River</option>
	<option value="T162">&raquo; Rankin Inlet</option>
	<option value="T163">&raquo; Recife</option>
	<option value="T164">&raquo; Regina</option>
	<option value="T165">&raquo; Resolute</option>
	<option value="T166">&raquo; Rio Branco</option>
	<option value="T167">&raquo; Santa Isabel</option>
	<option value="T168">&raquo; Santarem</option>
	<option value="T169">&raquo; Santiago</option>
	<option value="T170">&raquo; Santo Domingo</option>
	<option value="T171">&raquo; Sao Paulo</option>
	<option value="T172">&raquo; Scoresbysund</option>
	<option value="T173">&raquo; Shiprock</option>
	<option value="T174">&raquo; St Barthelemy</option>
	<option value="T175">&raquo; St Johns</option>
	<option value="T176">&raquo; St Kitts</option>
	<option value="T177">&raquo; St Lucia</option>
	<option value="T178">&raquo; St Thomas</option>
	<option value="T179">&raquo; St Vincent</option>
	<option value="T180">&raquo; Swift Current</option>
	<option value="T181">&raquo; Tegucigalpa</option>
	<option value="T182">&raquo; Thule</option>
	<option value="T183">&raquo; Thunder Bay</option>
	<option value="T184">&raquo; Tijuana</option>
	<option value="T185">&raquo; Toronto</option>
	<option value="T186">&raquo; Tortola</option>
	<option value="T187">&raquo; Vancouver</option>
	<option value="T188">&raquo; Whitehorse</option>
	<option value="T189">&raquo; Winnipeg</option>
	<option value="T190">&raquo; Yakutat</option>
	<option value="T191">&raquo; Yellowknife</option>
</optgroup>
<optgroup label="Antarctica">
	<option value="T192">&raquo; Casey</option>
	<option value="T193">&raquo; Davis</option>
	<option value="T194">&raquo; DumontDUrville</option>
	<option value="T195">&raquo; Mawson</option>
	<option value="T196">&raquo; McMurdo</option>
	<option value="T197">&raquo; Palmer</option>
	<option value="T198">&raquo; Rothera</option>
	<option value="T199">&raquo; South Pole</option>
	<option value="T200">&raquo; Syowa</option>
	<option value="T201">&raquo; Vostok</option>
</optgroup>
<optgroup label="Arctic">
	<option value="T202">&raquo; Longyearbyen</option>
</optgroup>
<optgroup label="Asia">
	<option value="T203">&raquo; Aden</option>
	<option value="T204">&raquo; Almaty</option>
	<option value="T205">&raquo; Amman</option>
	<option value="T206">&raquo; Anadyr</option>
	<option value="T207">&raquo; Aqtau</option>
	<option value="T208">&raquo; Aqtobe</option>
	<option value="T209">&raquo; Ashgabat</option>
	<option value="T210">&raquo; Baghdad</option>
	<option value="T211">&raquo; Bahrain</option>
	<option value="T212">&raquo; Baku</option>
	<option value="T213">&raquo; Bangkok</option>
	<option value="T214">&raquo; Beirut</option>
	<option value="T215">&raquo; Bishkek</option>
	<option value="T216">&raquo; Brunei</option>
	<option value="T217">&raquo; Choibalsan</option>
	<option value="T218">&raquo; Chongqing</option>
	<option value="T219">&raquo; Colombo</option>
	<option value="T220">&raquo; Damascus</option>
	<option value="T221">&raquo; Dhaka</option>
	<option value="T222">&raquo; Dili</option>
	<option value="T223">&raquo; Dubai</option>
	<option value="T224">&raquo; Dushanbe</option>
	<option value="T225">&raquo; Gaza</option>
	<option value="T226">&raquo; Harbin</option>
	<option value="T227">&raquo; Ho Chi Minh</option>
	<option value="T228">&raquo; Hong Kong</option>
	<option value="T229">&raquo; Hovd</option>
	<option value="T230">&raquo; Irkutsk</option>
	<option value="T231">&raquo; Jakarta</option>
	<option value="T232">&raquo; Jayapura</option>
	<option value="T233">&raquo; Jerusalem</option>
	<option value="T234">&raquo; Kabul</option>
	<option value="T235">&raquo; Kamchatka</option>
	<option value="T236">&raquo; Karachi</option>
	<option value="T237">&raquo; Kashgar</option>
	<option value="T238">&raquo; Kathmandu</option>
	<option value="T239">&raquo; Kolkata</option>
	<option value="T240">&raquo; Krasnoyarsk</option>
	<option value="T241">&raquo; Kuala Lumpur</option>
	<option value="T242">&raquo; Kuching</option>
	<option value="T243">&raquo; Kuwait</option>
	<option value="T244">&raquo; Macau</option>
	<option value="T245">&raquo; Magadan</option>
	<option value="T246">&raquo; Makassar</option>
	<option value="T247">&raquo; Manila</option>
	<option value="T248">&raquo; Muscat</option>
	<option value="T249">&raquo; Nicosia</option>
	<option value="T250">&raquo; Novokuznetsk</option>
	<option value="T251">&raquo; Novosibirsk</option>
	<option value="T252">&raquo; Omsk</option>
	<option value="T253">&raquo; Oral</option>
	<option value="T254">&raquo; Phnom Penh</option>
	<option value="T255">&raquo; Pontianak</option>
	<option value="T256">&raquo; Pyongyang</option>
	<option value="T257">&raquo; Qatar</option>
	<option value="T258">&raquo; Qyzylorda</option>
	<option value="T259">&raquo; Rangoon</option>
	<option value="T260">&raquo; Riyadh</option>
	<option value="T261">&raquo; Sakhalin</option>
	<option value="T262">&raquo; Samarkand</option>
	<option value="T263">&raquo; Seoul</option>
	<option value="T264">&raquo; Shanghai</option>
	<option value="T265">&raquo; Singapore</option>
	<option value="T266">&raquo; Taipei</option>
	<option value="T267">&raquo; Tashkent</option>
	<option value="T268">&raquo; Tbilisi</option>
	<option value="T269">&raquo; Tehran</option>
	<option value="T270">&raquo; Thimphu</option>
	<option value="T271">&raquo; Tokyo</option>
	<option value="T272">&raquo; Ulaanbaatar</option>
	<option value="T273">&raquo; Urumqi</option>
	<option value="T274">&raquo; Vientiane</option>
	<option value="T275">&raquo; Vladivostok</option>
	<option value="T276">&raquo; Yakutsk</option>
	<option value="T277">&raquo; Yekaterinburg</option>
	<option value="T278">&raquo; Yerevan</option>
</optgroup>
<optgroup label="Atlantic">
	<option value="T279">&raquo; Azores</option>
	<option value="T280">&raquo; Bermuda</option>
	<option value="T281">&raquo; Canary</option>
	<option value="T282">&raquo; Cape Verde</option>
	<option value="T283">&raquo; Faroe</option>
	<option value="T284">&raquo; Madeira</option>
	<option value="T285">&raquo; Reykjavik</option>
	<option value="T286">&raquo; South Georgia</option>
	<option value="T287">&raquo; St Helena</option>
	<option value="T288">&raquo; Stanley</option>
</optgroup>
<optgroup label="Australia">
	<option value="T289">&raquo; Adelaide</option>
	<option value="T290">&raquo; Brisbane</option>
	<option value="T291">&raquo; Broken Hill</option>
	<option value="T292">&raquo; Currie</option>
	<option value="T293">&raquo; Darwin</option>
	<option value="T294">&raquo; Eucla</option>
	<option value="T295">&raquo; Hobart</option>
	<option value="T296">&raquo; Lindeman</option>
	<option value="T297">&raquo; Lord Howe</option>
	<option value="T298">&raquo; Melbourne</option>
	<option value="T299">&raquo; Perth</option>
	<option value="T300">&raquo; Sydney</option>
</optgroup>
<optgroup label="Europe">
	<option value="T301">&raquo; Amsterdam</option>
	<option value="T302">&raquo; Andorra</option>
	<option value="T303">&raquo; Athens</option>
	<option value="T304">&raquo; Belgrade</option>
	<option value="T305">&raquo; Berlin</option>
	<option value="T306">&raquo; Bratislava</option>
	<option value="T307">&raquo; Brussels</option>
	<option value="T308">&raquo; Bucharest</option>
	<option value="T309">&raquo; Budapest</option>
	<option value="T310">&raquo; Chisinau</option>
	<option value="T311">&raquo; Copenhagen</option>
	<option value="T312">&raquo; Dublin</option>
	<option value="T313">&raquo; Gibraltar</option>
	<option value="T314">&raquo; Guernsey</option>
	<option value="T315">&raquo; Helsinki</option>
	<option value="T316">&raquo; Isle of Man</option>
	<option value="T317">&raquo; Istanbul</option>
	<option value="T318">&raquo; Jersey</option>
	<option value="T319">&raquo; Kaliningrad</option>
	<option value="T320">&raquo; Kiev</option>
	<option value="T321">&raquo; Lisbon</option>
	<option value="T322">&raquo; Ljubljana</option>
	<option value="T323">&raquo; London</option>
	<option value="T324">&raquo; Luxembourg</option>
	<option value="T325">&raquo; Madrid</option>
	<option value="T326">&raquo; Malta</option>
	<option value="T327">&raquo; Mariehamn</option>
	<option value="T328">&raquo; Minsk</option>
	<option value="T329">&raquo; Monaco</option>
	<option value="T330">&raquo; Moscow</option>
	<option value="T331">&raquo; Oslo</option>
	<option value="T332">&raquo; Paris</option>
	<option value="T333">&raquo; Podgorica</option>
	<option value="T334">&raquo; Prague</option>
	<option value="T335">&raquo; Riga</option>
	<option value="T336">&raquo; Rome</option>
	<option value="T337">&raquo; Samara</option>
	<option value="T338">&raquo; San Marino</option>
	<option value="T339">&raquo; Sarajevo</option>
	<option value="T340">&raquo; Simferopol</option>
	<option value="T341">&raquo; Skopje</option>
	<option value="T342">&raquo; Sofia</option>
	<option value="T343">&raquo; Stockholm</option>
	<option value="T344">&raquo; Tallinn</option>
	<option value="T345">&raquo; Tirane</option>
	<option value="T346">&raquo; Uzhgorod</option>
	<option value="T347">&raquo; Vaduz</option>
	<option value="T348">&raquo; Vatican</option>
	<option value="T349">&raquo; Vienna</option>
	<option value="T350">&raquo; Vilnius</option>
	<option value="T351">&raquo; Volgograd</option>
	<option value="T352">&raquo; Warsaw</option>
	<option value="T353">&raquo; Zagreb</option>
	<option value="T354">&raquo; Zaporozhye</option>
	<option value="T355">&raquo; Zurich</option>
</optgroup>
<optgroup label="Indian">
	<option value="T356">&raquo; Antananarivo</option>
	<option value="T357">&raquo; Chagos</option>
	<option value="T358">&raquo; Christmas</option>
	<option value="T359">&raquo; Cocos</option>
	<option value="T360">&raquo; Comoro</option>
	<option value="T361">&raquo; Kerguelen</option>
	<option value="T362">&raquo; Mahe</option>
	<option value="T363">&raquo; Maldives</option>
	<option value="T364">&raquo; Mauritius</option>
	<option value="T365">&raquo; Mayotte</option>
	<option value="T366">&raquo; Reunion</option>
</optgroup>
<optgroup label="Pacific">
	<option value="T367">&raquo; Apia</option>
	<option value="T368">&raquo; Auckland</option>
	<option value="T369">&raquo; Chatham</option>
	<option value="T370">&raquo; Easter</option>
	<option value="T371">&raquo; Efate</option>
	<option value="T372">&raquo; Enderbury</option>
	<option value="T373">&raquo; Fakaofo</option>
	<option value="T374">&raquo; Fiji</option>
	<option value="T375">&raquo; Funafuti</option>
	<option value="T376">&raquo; Galapagos</option>
	<option value="T377">&raquo; Gambier</option>
	<option value="T378">&raquo; Guadalcanal</option>
	<option value="T379">&raquo; Guam</option>
	<option value="T380">&raquo; Honolulu</option>
	<option value="T381">&raquo; Johnston</option>
	<option value="T382">&raquo; Kiritimati</option>
	<option value="T383">&raquo; Kosrae</option>
	<option value="T384">&raquo; Kwajalein</option>
	<option value="T385">&raquo; Majuro</option>
	<option value="T386">&raquo; Marquesas</option>
	<option value="T387">&raquo; Midway</option>
	<option value="T388">&raquo; Nauru</option>
	<option value="T389">&raquo; Niue</option>
	<option value="T390">&raquo; Norfolk</option>
	<option value="T391">&raquo; Noumea</option>
	<option value="T392">&raquo; Pago Pago</option>
	<option value="T393">&raquo; Palau</option>
	<option value="T394">&raquo; Pitcairn</option>
	<option value="T395">&raquo; Ponape</option>
	<option value="T396">&raquo; Port Moresby</option>
	<option value="T397">&raquo; Rarotonga</option>
	<option value="T398">&raquo; Saipan</option>
	<option value="T399">&raquo; Tahiti</option>
	<option value="T400">&raquo; Tarawa</option>
	<option value="T401">&raquo; Tongatapu</option>
	<option value="T402">&raquo; Truk</option>
	<option value="T403">&raquo; Wake</option>
	<option value="T404">&raquo; Wallis</option>
</optgroup>
</select>';
            if ($default){
//                $menu = substr_replace($menu, "\"$default\" selected", strpos($menu, "\"$default\""), -(strlen($menu) - strpos($menu, "\"$default\"") + strlen($default) + 2));
                $menu = replace_first("\"$default\"", "\"$default\" selected=\"selected\"", $menu);
            }

            return $menu;
	}

        function replace_first($search, $replace, $data) {
            $res = strpos($data, $search);
            if($res === false) {
                return $data;
            } else {
                // There is data to be replaced
                $left_seg = substr($data, 0, strpos($data, $search));
                $right_seg = substr($data, (strpos($data, $search) + strlen($search)));
                return $left_seg . $replace . $right_seg;
            }
        }
}

// ------------------------------------------------------------------------
/* End of file time_helper.php */
/* Location: ./exitecms/helpers/time_helper.php */
?>