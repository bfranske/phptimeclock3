<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
    function ae_detect_ie(){
        if (isset($_SERVER['HTTP_USER_AGENT']) &&
        (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false))
            return true;
        else
            return false;
    }

//    if (ae_detect_ie() AND strpos(current_url(), 'no_ie_support') === false){
//        redirect('dashboard/no_ie_support');
//    }

    function set_base_url(){
        $CI =& get_instance();
    // Set Base URL
        if ($CI->Config->item('base_url'))
            $CI->config->set_item('base_url', $CI->Config->item('base_url'));
        else
            $CI->Config->update_item('base_url', str_replace(':443', '', $CI->config->item('base_url')));

        define('BASE_URL', $CI->config->item('base_url'));

    // SSL
        if ($CI->Config->item('useSSL') AND strpos(curPageURL(), 'https://') === false){
            redirect(str_replace('http://', 'https://', current_url()));
        }
        else if (!$CI->Config->item('useSSL') AND strpos(curPageURL(), 'http://') === false){
            redirect(str_replace('https://', 'http://', current_url()));
        }

    // Date/Time Formats
        define('DATE_FORMAT', $CI->Config->item('dateFormat'));
        define('TIME_FORMAT', $CI->Config->item('timeFormat') == '12Hr' ? 'h:i:s A' : 'H:i:s');
    }

// This is only for hosted users.  It could be used for non hosted, but config option must be manually set in database
    function check_installation_enabled(){
        $CI =& get_instance();
        if (strpos($CI->Config->item('base_url'), 'https://hosted.phptimeclock.com') !== false){
            if ($CI->Config->item('enabled') === '0'){
                echo '<h3 style="color:red">This installation has been disabled due to nonpayment, please contact an administrator</h3>';
                die();
            }
            if ($CI->Config->item('emailVerified') === '0'){
                echo '<h3 style="color:red">This installation is not activated yet, due to email not being verified.  Please check the email address you signed up with for verification link.</h3>';
                die();
            }
        }
    }
    check_installation_enabled();
?>