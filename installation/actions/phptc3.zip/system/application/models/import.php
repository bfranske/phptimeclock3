<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Import extends Model{

    function initialize_db(){
/*
 * Users
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'users`');
        $query = "CREATE TABLE `".TABLE_PREFIX."users` (
                  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                  `username` varchar(32) NOT NULL,
                  `password` varchar(56) NOT NULL,
                  `first_name` varchar(32) NOT NULL,
                  `last_name` varchar(32) NULL,
                  `email` varchar(128) DEFAULT NULL,
                  `sys_admin` tinyint(4) DEFAULT NULL,
                  `last_punch_id` mediumint(9) DEFAULT NULL,
                  `enabled` tinyint(4) NOT NULL DEFAULT '1',
                  `must_change_pass` tinyint(4) DEFAULT NULL,
                  `pin` bigint(20) unsigned NULL,
                  `custom_id` bigint(20) unsigned DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);

/*
 * Groups
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'groups`');
        $query = "CREATE TABLE `".TABLE_PREFIX."groups` (
                  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
                  `parent_id` smallint(5) unsigned NOT NULL,
                  `name` varchar(32) NOT NULL,
                  `camera_url` varchar(1024) DEFAULT NULL,
                  `enabled` tinyint(4) NOT NULL DEFAULT '1',
                  PRIMARY KEY (`id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);

/*
 * User Groups
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'user_groups`');
        $query = "CREATE TABLE `".TABLE_PREFIX."user_groups` (
                  `id` smallint(6) NOT NULL AUTO_INCREMENT,
                  `user_id` smallint(6) NOT NULL,
                  `group_id` smallint(6) unsigned NOT NULL DEFAULT '1',
                  `permissions` varchar(1024) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);

/*
 * Punch Types
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'punch_types`');
        $query = "CREATE TABLE `".TABLE_PREFIX."punch_types` (
                      `id` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
                      `status` tinyint(4) unsigned NOT NULL,
                      `name` varchar(32) NOT NULL,
                      `color` varchar(6) NOT NULL,
                      `order` smallint(5) unsigned NOT NULL,
                      `enabled` tinyint(4) unsigned NOT NULL DEFAULT '1',
                      PRIMARY KEY (`id`)
                    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);

/*
 * Punches
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'punches`');
        $query = "CREATE TABLE `".TABLE_PREFIX."punches` (
                  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                  `user_id` smallint(5) unsigned unsigned NOT NULL,
                  `group_id` smallint(6) unsigned NOT NULL,
                  `punch_type_id` tinyint(3) unsigned NOT NULL,
                  `next_punch_id` int(10) unsigned DEFAULT NULL,
                  `ip_address` varchar(32) NOT NULL,
                  `date_time` datetime NOT NULL,
                  `notes` varchar(1024) DEFAULT NULL,
                  `approved` tinyint(4) NOT NULL DEFAULT '0',
                  `approved_by` mediumint(8) unsigned NULL,
                  PRIMARY KEY (`id`),
                  KEY `user_id` (`user_id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);

/*
 * CodeIgniter Sessions
 */
        $query = "CREATE TABLE IF NOT EXISTS `".TABLE_PREFIX."ci_sessions` (
                  `session_id` varchar(32) NOT NULL DEFAULT '',
                  `user_agent` varchar(255) DEFAULT NULL,
                  `ip_address` varchar(20) DEFAULT NULL,
                  `last_activity` int(12) DEFAULT NULL,
                  `user_data` mediumtext,
                  PRIMARY KEY (`session_id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
        $this->db->query($query);

/*
 * Audit Table
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'audits`');
        $query = "CREATE TABLE `".TABLE_PREFIX."audits` (
                  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
                  `punch_id` int(11) NOT NULL,
                  `editing_user_id` smallint(6) NOT NULL,
                  `ip_address` char(15) NOT NULL,
                  `reason_for_editing` varchar(512) NOT NULL,
                  `edit_action` varchar(32) NOT NULL,
                  `when_changed` datetime NOT NULL,
                  `old_start` datetime DEFAULT NULL,
                  `old_end` datetime DEFAULT NULL,
                  `old_group_id` smallint(6) DEFAULT NULL,
                  `old_next_punch_id` int(10) unsigned DEFAULT NULL,
                  `old_punch_type_id` smallint(6) DEFAULT NULL,
                  `old_notes` varchar(512) DEFAULT NULL,
                  `old_tags` varchar(512) DEFAULT NULL,
                  `new_start` datetime DEFAULT NULL,
                  `new_end` datetime DEFAULT NULL,
                  `new_group_id` smallint(6) DEFAULT NULL,
                  `new_next_punch_id` int(10) unsigned DEFAULT NULL,
                  `new_punch_type_id` tinyint(3) unsigned DEFAULT NULL,
                  `new_notes` varchar(512) DEFAULT NULL,
                  `new_tags` varchar(512) DEFAULT NULL,
                  PRIMARY KEY (`id`),
                  KEY `punch_id` (`punch_id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;";
        $this->db->query($query);

///*
// * Config
// */
//        $query = "CREATE TABLE IF NOT EXISTS `".TABLE_PREFIX."config` (
//                  `id` smallint(6) NOT NULL AUTO_INCREMENT,
//                  `option` varchar(128) NOT NULL,
//                  `value` varchar(512) NOT NULL,
//                  PRIMARY KEY (`id`)
//                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
//        $this->db->query($query);
//
//        $query = "INSERT INTO `".TABLE_PREFIX."config` (`id`, `option`, `value`) VALUES
//                    (1, 'language', 'en_US'),
//                    (2, 'template', 'default'),
//                    (3, 'timezone', 'T078'),
//                    (4, 'db_version', '3'),
//                    (5, 'companyName', ''),
//                    (6, 'userIdentifier_punch', 'username'),
//                    (7, 'userIdentifier_board', 'username'),
//                    (8, 'punchBoardDays', '7'),
//                    (9, 'selectGroupDisplay', 'always'),
//                    (10, 'selectStatusStyle', 'dropdown'),
//                    (11, 'lastNameView', 'name'),
//                    (12, 'restrictIPAddresses', 'No'),
//                    (13, 'base_url', ''),
//                    (14, 'useSSL', '0'),
//                    (15, 'developerMode', '0'),
//                    (16, 'useTags', 'Yes'),
//                    (17, 'punchBoardGroup', 'Show'),
//                    (18, 'punchBoardNotes', 'Show'),
//                    (19, 'timeFormat', '12Hr'),
//                    (20, 'dateFormat', 'm/d/Y'),
//                    (21, 'minPasswordLength', '8'),
//                    (22, 'report_roundingDigits', '1'),
//                    (23, 'report_showGroup', '0'),
//                    (24, 'report_showTags', '0'),
//                    (25, 'report_showDuration', '0'),
//                    (26, 'report_enabledDurations', '1,2,3,4'),
//                    (27, 'report_enabledTotals', '1,2,3,4'),
//                    (28, 'DeveloperMode', '0')";
//        $this->db->query($query);

/*
 * Punch Tags
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'punch_tags`');
        $query = "CREATE TABLE `".TABLE_PREFIX."punch_tags` (
                  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
                  `punch_id` mediumint(9) NOT NULL,
                  `tag_id` smallint(6) NOT NULL,
                  PRIMARY KEY (`id`),
                  KEY `punch_id` (`punch_id`),
                  KEY `tag_id` (`tag_id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);

/*
 *  Tags
 */
        $this->db->query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'tags`');
        $query = "CREATE TABLE `".TABLE_PREFIX."tags` (
                  `id` smallint(6) NOT NULL AUTO_INCREMENT,
                  `name` varchar(64) NOT NULL,
                  `enabled` tinyint(4) NOT NULL DEFAULT '1',
                  PRIMARY KEY (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
        $this->db->query($query);


/*******************************************************************
 *****************             Views             *******************
 ******************************************************************/
    // Punch Log
        mysql_query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'punch_log`;') or die(mysql_error());

        $punch_log = '
        CREATE OR REPLACE
        VIEW  `'.TABLE_PREFIX.'punch_log` AS
        SELECT p1.id, p1.user_id, p1.group_id, `'.TABLE_PREFIX.'groups`.`name` AS group_name, p1.punch_type_id, p1.date_time,  p2.date_time AS end_time, TIME_TO_SEC( TIMEDIFF( p2.date_time, p1.date_time ) ) AS duration, pt.name AS status_name, pt.status, GROUP_CONCAT('.TABLE_PREFIX.'tags.name) AS tags, p1.notes, p1.approved, p1.approved_by
        FROM `'.TABLE_PREFIX.'punches` AS p1
        LEFT JOIN `'.TABLE_PREFIX.'punches` AS p2 ON p2.id = p1.next_punch_id
        LEFT JOIN `'.TABLE_PREFIX.'punch_types` AS pt ON p1.punch_type_id = pt.id
        LEFT JOIN `'.TABLE_PREFIX.'groups` ON p1.group_id = `'.TABLE_PREFIX.'groups`.`id`
        LEFT JOIN `'.TABLE_PREFIX.'punch_tags` ON p1.id = `'.TABLE_PREFIX.'punch_tags`.`punch_id`
        LEFT JOIN `'.TABLE_PREFIX.'tags` ON `'.TABLE_PREFIX.'punch_tags`.`tag_id` = `'.TABLE_PREFIX.'tags`.`id`
        GROUP BY p1.id';

        mysql_query($punch_log) or die(mysql_error());

    // Punch Board
        mysql_query('DROP TABLE IF EXISTS `'.TABLE_PREFIX.'punch_board`;') or die(mysql_error());

        $punch_board = '
        CREATE OR REPLACE
        VIEW  `'.TABLE_PREFIX.'punch_board` AS
        SELECT `'.TABLE_PREFIX.'punches`.`id`, username, user_id, group_id, `'.TABLE_PREFIX.'groups`.`name` AS group_name, `'.TABLE_PREFIX.'punch_types`.`name` AS punch_name, punch_type_id, date_time, pt.name AS status_name, pt.status,
        GROUP_CONCAT(`'.TABLE_PREFIX.'tags`.`name`) AS tags, notes, `'.TABLE_PREFIX.'punches`.`approved`, `'.TABLE_PREFIX.'punches`.`approved_by`
        FROM `'.TABLE_PREFIX.'punches`
        LEFT JOIN `'.TABLE_PREFIX.'punch_types` AS pt ON `'.TABLE_PREFIX.'punches`.`punch_type_id` = pt.id
	LEFT JOIN `'.TABLE_PREFIX.'users` ON `'.TABLE_PREFIX.'users`.`id` = user_id
        LEFT JOIN `'.TABLE_PREFIX.'groups` ON `'.TABLE_PREFIX.'punches`.`group_id` = `'.TABLE_PREFIX.'groups`.`id`
        LEFT JOIN `'.TABLE_PREFIX.'punch_tags` ON `'.TABLE_PREFIX.'punches`.`id` = `'.TABLE_PREFIX.'punch_tags`.`punch_id`
	LEFT JOIN `'.TABLE_PREFIX.'punch_types` ON `'.TABLE_PREFIX.'punch_types`.`id` = punch_type_id
        LEFT JOIN `'.TABLE_PREFIX.'tags` ON `'.TABLE_PREFIX.'punch_tags`.`tag_id` = `'.TABLE_PREFIX.'tags`.`id`
	WHERE next_punch_id IS NULL
        GROUP BY `'.TABLE_PREFIX.'punches`.`id`
        ORDER BY username';

        mysql_query($punch_board) or die(mysql_error());


/*******************************************************************
 *****************       Stored Proceedures      *******************
 ******************************************************************/

/*
 * Edit Time
 */
        mysql_query('DROP PROCEDURE IF EXISTS `'.TABLE_PREFIX.'edit_time`;');
        mysql_query("
        CREATE PROCEDURE `".TABLE_PREFIX."edit_time` (punchID INT, editingUserID INT, ipAddress VARCHAR(32), reasonForEditing VARCHAR(512), newStart DATETIME, newGroupID INT, newPunchTypeID INT, newNotes VARCHAR(1024), newTags VARCHAR(512), whenChanged DATETIME)
        BEGIN
            SELECT group_id, punch_type_id, next_punch_id, date_time, notes, GROUP_CONCAT(name) AS tags INTO @oldGroupID, @oldPunchTypeID, @nextPunchID, @oldStart, @oldNotes, @oldTags
            FROM `".TABLE_PREFIX."punches`
            LEFT JOIN `".TABLE_PREFIX."punch_tags` ON `".TABLE_PREFIX."punches`.`id` = punch_id
            LEFT JOIN `".TABLE_PREFIX."tags` on `".TABLE_PREFIX."punch_tags`.`tag_id` = `".TABLE_PREFIX."tags`.`id`
            WHERE `".TABLE_PREFIX."punches`.`id` = punchID
            GROUP BY `".TABLE_PREFIX."punches`.`id`;

            SELECT date_time INTO @oldEnd FROM `".TABLE_PREFIX."punches` WHERE id = @nextPunchID;

            UPDATE `".TABLE_PREFIX."punches` SET date_time = newStart, group_id = newGroupID, punch_type_id = newPunchTypeID, notes = newNotes
            WHERE `".TABLE_PREFIX."punches`.`id` = punchID;

            INSERT INTO `".TABLE_PREFIX."audits` (edit_action, punch_id, editing_user_id, ip_address, reason_for_editing, old_start, old_end, old_group_id, old_next_punch_id, old_punch_type_id, old_notes, old_tags,
                                new_start, new_group_id, new_next_punch_id, new_punch_type_id, new_notes, new_tags, when_changed)
                        VALUES ('edit', punchID, editingUserID, ipAddress, reasonForEditing, @oldStart, @oldEnd, @oldGroupID, @nextPunchID, @oldPunchTypeID, @oldNotes, @oldTags,
                                newStart, newGroupID, @nextPunchID, newPunchTypeID, newNotes, newTags, whenChanged);

            DELETE FROM `".TABLE_PREFIX."punch_tags` WHERE punch_id = punchID;

            CALL `".TABLE_PREFIX."ensure_tags_exist`(',', newTags);
            CALL `".TABLE_PREFIX."explode`(',', newTags);
            INSERT INTO `".TABLE_PREFIX."punch_tags` (punch_id, tag_id)
            SELECT punchID AS punch_id, `".TABLE_PREFIX."tags`.`id` AS tag_id FROM temp_explode
            LEFT JOIN `".TABLE_PREFIX."tags` on word = name;
        END
        ") OR die(mysql_error());

/*
 * Delete Time
 */
        mysql_query('DROP PROCEDURE IF EXISTS `'.TABLE_PREFIX.'delete_time`;');
        mysql_query("
        CREATE PROCEDURE `".TABLE_PREFIX."delete_time` (punchID INT, editingUserID INT, ipAddress VARCHAR(32), reasonForEditing VARCHAR(512), whenChanged DATETIME)
        BEGIN
            SELECT id INTO @previousPunchID FROM `".TABLE_PREFIX."punches` WHERE next_punch_id = punchID;

            SELECT user_id, group_id, punch_type_id, next_punch_id, date_time, notes, GROUP_CONCAT(name) AS tags INTO @userID, @oldGroupID, @oldPunchTypeID, @nextPunchID, @oldStart, @oldNotes, @oldTags
            FROM `".TABLE_PREFIX."punches`
            LEFT JOIN `".TABLE_PREFIX."punch_tags` ON `".TABLE_PREFIX."punches`.`id` = punch_id
            LEFT JOIN `".TABLE_PREFIX."tags` on `".TABLE_PREFIX."punch_tags`.`tag_id` = `".TABLE_PREFIX."tags`.`id`
            WHERE `".TABLE_PREFIX."punches`.`id` = punchID
            GROUP BY `".TABLE_PREFIX."punches`.`id`;

            UPDATE `".TABLE_PREFIX."punches` SET next_punch_id = @nextPunchID
            WHERE `".TABLE_PREFIX."punches`.`id` = @previousPunchID;

            DELETE FROM `".TABLE_PREFIX."punches`
            WHERE id = punchID;

            INSERT INTO `".TABLE_PREFIX."audits` (edit_action, punch_id, editing_user_id, ip_address, reason_for_editing, old_start, old_end, old_group_id, old_next_punch_id, old_punch_type_id, old_notes, old_tags,
                                new_start, new_end, new_group_id, new_next_punch_id, new_punch_type_id, new_notes, new_tags, when_changed)
                        VALUES ('delete', punchID, editingUserID, ipAddress, reasonForEditing, @oldStart, @oldEnd, @oldGroupID, @nextPunchID, @oldPunchTypeID, @oldNotes, @oldTags,
                                NULL, NULL, NULL, @nextPunchID, NULL, NULL, NULL, whenChanged);

            DELETE FROM `".TABLE_PREFIX."punch_tags` WHERE punch_id = punchID;
        END
        ") OR die(mysql_error());

/*
 * Add Time
 */
        mysql_query('DROP PROCEDURE IF EXISTS `'.TABLE_PREFIX.'add_time`;');
        mysql_query("
            CREATE PROCEDURE `".TABLE_PREFIX."add_time` (userID INT, previousPunchID INT, editingUserID INT, ipAddress VARCHAR(32), reasonForEditing VARCHAR(512), newStart DATETIME,  newGroupID INT, newPunchTypeID INT, newNotes VARCHAR(1024), newTags VARCHAR(512), passedNextPunchID INT, whenChanged DATETIME)
            BEGIN
                SELECT group_id, punch_type_id, next_punch_id, date_time, notes, GROUP_CONCAT(name) AS tags
                 INTO @oldGroupID, @oldPunchTypeID, @nextPunchID, @oldStart, @oldNotes, @oldTags
                FROM `".TABLE_PREFIX."punches`
                LEFT JOIN `".TABLE_PREFIX."punch_tags` ON `".TABLE_PREFIX."punches`.`id` = punch_id
                LEFT JOIN `".TABLE_PREFIX."tags` on `".TABLE_PREFIX."punch_tags`.`tag_id` = `".TABLE_PREFIX."tags`.`id`
                WHERE `".TABLE_PREFIX."punches`.`id` = previousPunchID
                GROUP BY `".TABLE_PREFIX."punches`.`id`;

                IF (@nextPunchID) THEN SET @nextPunchID = @nextPunchID;
                ELSE SET @nextPunchID = passedNextPunchID;
                END IF;

                INSERT INTO `".TABLE_PREFIX."punches` (user_id, group_id, date_time, next_punch_id, punch_type_id, notes)
                             VALUES (userID, newGroupID, newStart, @nextPunchID, newPunchTypeID, newNotes);
                SELECT LAST_INSERT_ID() INTO @newPunchID;

                UPDATE `".TABLE_PREFIX."punches` SET next_punch_id = @newPunchID
                WHERE id = previousPunchID;

                INSERT INTO `".TABLE_PREFIX."audits` (edit_action, punch_id, editing_user_id, ip_address, reason_for_editing, old_start, old_end, old_group_id, old_next_punch_id, old_punch_type_id, old_notes, old_tags,
                                    new_start, new_group_id, new_next_punch_id, new_punch_type_id, new_notes, new_tags, when_changed)
                            VALUES ('add', @newPunchID, editingUserID, ipAddress, reasonForEditing, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                                    newStart, newGroupID, @nextPunchID, newPunchTypeID, newPunchTypeID, newTags, whenChanged);

                CALL `".TABLE_PREFIX."ensure_tags_exist`(',', newTags);
                CALL `".TABLE_PREFIX."explode`(',', newTags);
                INSERT INTO `".TABLE_PREFIX."punch_tags` (punch_id, tag_id)
                SELECT @newPunchID AS punch_id, `".TABLE_PREFIX."tags`.`id` AS tag_id FROM temp_explode
                LEFT JOIN `".TABLE_PREFIX."tags` on word = name;
            END
        ") OR die(mysql_error());

/*
 * Ensure Tags Exist
 */
        mysql_query('DROP PROCEDURE IF EXISTS `'.TABLE_PREFIX.'ensure_tags_exist`;');
        mysql_query("
        CREATE PROCEDURE `".TABLE_PREFIX."ensure_tags_exist`( pDelim VARCHAR(32), pStr TEXT)
        BEGIN
          DECLARE n INT DEFAULT 0;
          DECLARE pos INT DEFAULT 1;
          DECLARE strRemain TEXT;
          DECLARE wrd text;
          DECLARE tagID INT;

          SET strRemain = pStr;
          SET pos = LOCATE( pDelim, strRemain );
          WHILE pos != 0 DO
            SET tagID = 0;
            SET n = n + 1;
            SET pos = LOCATE( pDelim, strRemain );

            IF pos=0 THEN SET wrd= strRemain;
            ELSE SET wrd= TRIM(REPLACE(SUBSTRING( strRemain, 1,pos ), pDelim, ''));
            END IF;

            SET strRemain = SUBSTRING( strRemain, pos+1 );

            IF CHAR_LENGTH(TRIM(wrd)) THEN
                SELECT id INTO tagID FROM `".TABLE_PREFIX."tags` WHERE name = wrd;
                IF tagID = 0 THEN
                    INSERT INTO `".TABLE_PREFIX."tags` (name, id) VALUES (wrd, tagID);
                END IF;
            END IF;
          END WHILE;
        END;") OR die(mysql_error());

/*
 * Explode
 */
        mysql_query('DROP PROCEDURE IF EXISTS `'.TABLE_PREFIX.'explode`;');
        mysql_query("
        CREATE PROCEDURE `".TABLE_PREFIX."explode`( pDelim VARCHAR(32), pStr TEXT)
        BEGIN
          DECLARE n INT DEFAULT 0;
          DECLARE pos INT DEFAULT 1;
          DECLARE strRemain TEXT;
          DECLARE wrd text;

          CREATE TEMPORARY TABLE IF NOT EXISTS temp_explode (id INT AUTO_INCREMENT PRIMARY KEY NOT NULL, word VARCHAR(40));
          DELETE FROM temp_explode;
          SET strRemain = pStr;
          SET pos = LOCATE( pDelim, strRemain );
          WHILE pos != 0 DO
            SET n = n + 1;
            SET pos = LOCATE( pDelim, strRemain );

            IF pos=0 THEN SET wrd= strRemain;
            ELSE SET wrd= TRIM(REPLACE(SUBSTRING( strRemain, 1,pos ), pDelim, ''));
            END IF;

            SET strRemain = SUBSTRING( strRemain, pos+1 );
            INSERT INTO temp_explode (word) VALUES (wrd);
          END WHILE;
        END;") OR die(mysql_error());

/*
 * Punch
 */
        mysql_query('DROP PROCEDURE IF EXISTS `'.TABLE_PREFIX.'punch`;');
        mysql_query("
        CREATE PROCEDURE ".TABLE_PREFIX."punch( userID INT, groupID INT, punchTypeID INT, ipAddress VARCHAR(32), dateTime VARCHAR(64), notes VARCHAR(1024), tags VARCHAR(1024))
        BEGIN
          SELECT id INTO @lastPunchID FROM `".TABLE_PREFIX."punches` WHERE next_punch_id IS NULL AND user_id = userID;

          INSERT INTO `".TABLE_PREFIX."punches` (user_id, group_id, punch_type_id, ip_address, date_time, notes)
                       VALUES (userID, groupID, punchTypeID, ipAddress, dateTime, notes);

          IF @lastPunchID IS NOT NULL THEN
            UPDATE `".TABLE_PREFIX."punches` SET next_punch_id = LAST_INSERT_ID() WHERE id = @lastPunchID;
          END IF;

          SELECT LAST_INSERT_ID() INTO @newPunchID;

          CALL `".TABLE_PREFIX."ensure_tags_exist`(',', tags);
          CALL `".TABLE_PREFIX."explode`(',', tags);
          INSERT INTO `".TABLE_PREFIX."punch_tags` (punch_id, tag_id)
          SELECT @newPunchID AS punch_id, `".TABLE_PREFIX."tags`.`id` AS tag_id FROM temp_explode
          LEFT JOIN `".TABLE_PREFIX."tags` on word = name;
        END;") OR die(mysql_error());
    }


/********************************
 ******* Version 1 Import *******
 ********************************/
    function import_from_v1($dbCredentials, $tablePrefix){
/*
 * Users
 */
        $nullPasswords = 0;
        $this->addedUsers = 0;
        $oldUsers = PDO_query('SELECT empfullname, employee_passwd, displayname, email, disabled FROM `'.$tablePrefix.'employees`', false, false, $dbCredentials);
        foreach ($oldUsers as $user){
            extract($user);
            $this->addedUsers++;
            $data = array();
            $data['username'] = $empfullname;
            if ($employee_passwd == NULL){
                $newPassword = generatePassword();
                $data['password'] = encrypt_password($newPassword);
                @$nullPasswords++;
                @$nullPasswordUsers[$empfullname] = $newPassword;
            }
            else {
                $newPassword = generatePassword();
                $data['password'] = encrypt_password($newPassword);
                @$weakPasswords++;
                @$weakPasswordUsers[$empfullname] = $newPassword;
            }

            


            if (strpos($empfullname, ' ')){
                $data['first_name'] = substr($empfullname, 0, strrpos($empfullname, ' '));
                $data['last_name'] = substr($empfullname, strrpos($empfullname, ' ') + 1);
            }
            else {
                $data['first_name'] = $empfullname;
                $data['last_name'] = '';
            }

            $data['email'] = $email;
            $data['enabled'] = ! $disabled;
            $this->db->insert('users', $data);
        }
        if ($nullPasswords){
            $this->data['output'] .= "<br /><strong>There were $nullPasswords empty passwords, they have been changed to thier usernames, the following users have had password reset. <br />";
            $this->data['output'] .= 'The following users were effected: </strong><br />';

            $rowsPerCol = ceil(count($nullPasswordUsers) / 5);
            $row = $col = 1;

         // @TODO Optomize import null/weak password name display
            foreach ($nullPasswordUsers as $username => $password){
                $result = $this->db->get_where('users', array('username' => $username));
                $result = $result->result();
                $usernames[$index] = $result[0]->username;
                $fullNames[$index] = $result[0]->first_name . ' ' . $result[0]->last_name;

                $links[$row][$col] =  "<strong>$username:</strong> $password";

                if ($row == $rowsPerCol){
                    $row = 1;
                }
                else {
                    $row++;
                }

                if ($col == 5){
                    $col = 1;
                }
                else {
                    $col++;
                }
            }

            $this->data['output'] .= '<table class="everythingTable">';
                foreach ($links as $row){
                    $this->data['output'] .= '<tr>';
                        foreach ($row as $col){
                            $this->data['output'] .= "<td valign='top'>$col</td>";
                        }
                    $this->data['output'] .= '</tr>';
                }
            $this->data['output'] .= '</table>';
        }
        $this->data['output'] .=  '<br />';

        if ($weakPasswords){
            $this->data['output'] .= "<br /><strong>There were $weakPasswords passwords that were using a weaker password hash from previous version, they have been reset. <br />";
            $this->data['output'] .= 'The following users were effected: </strong><br />';

            $rowsPerCol = ceil(count($weakPasswordUsers) / 5);
            $row = $col = 1;

            if (count($weakPasswordUsers) > 1){
                foreach ($weakPasswordUsers as $username => $password){
                    $result = $this->db->get_where('users', array('username' => $username));
                    $result = $result->result();
                    $usernames[$username] = $result[0]->username;
                    $fullNames[$username] = $result[0]->first_name . ' ' . $result[0]->last_name;


                    $links[$row][$col] =  "<strong>$username:</strong> $password";

                    if ($row == $rowsPerCol){
                        $row = 1;
                    }
                    else {
                        $row++;
                    }

                    if ($col == 5){
                        $col = 1;
                    }
                    else {
                        $col++;
                    }
                }

                $this->data['output'] .= '<table class="everythingTable">';
                    foreach ($links as $row){
                        $this->data['output'] .= '<tr>';
                            foreach ($row as $col){
                                $this->data['output'] .= "<td valign='top'>$col</td>";
                            }
                        $this->data['output'] .= '</tr>';
                    }
                $this->data['output'] .= '</table>';
            }
        }

/*
 * User IDs
 */
        $userIDs = array();
        $this->db->select('id, username');
        $userNames = $this->db->get('users');
        foreach ($userNames->result() as $userName){
            $userIDs[$userName->username] = $userName->id;
        }
/*
 * Groups
 */
        $this->db->insert('groups', array('id' => 1, 'parent_id' => 0, 'name' => 'All Users'));

    // Old Offices
        $this->addedGroups = 0;
        $oldOffices = PDO_query('SELECT officeid AS office_id, officename AS office_name FROM `'.$tablePrefix.'offices`', false, false, $dbCredentials);
        foreach ($oldOffices as $office){
            $this->addedGroups++;
            extract($office);
            $data = array();

            $data['id'] = $office_id > 1 ? $office_id : 32767;
            $data['parent_id'] = 1;
            $data['name'] = $office_name;
            $this->db->insert('groups', $data);
        }

    // Old Groups
        $oldGroups = PDO_query('SELECT groupname, groupid, officeid AS office_id FROM `'.$tablePrefix.'groups`', false, false, $dbCredentials);
        foreach ($oldGroups as $group){
            $this->addedGroups++;
            extract($group);
            $data = array();

            $data['id'] = $groupid > 1 ? ($groupid + 32767) : 32766;
            $data['parent_id'] = $office_id > 1 ? $office_id : 32767;
            $data['name'] = $groupname;
            $this->db->insert('groups', $data);
        }
// @TODO User Groups on V1 import
/*
 * User Groups
 */
    // Offices
        $query = 'SELECT empfullname, offices.officeid, groupid FROM `'.$tablePrefix.'employees`
                  LEFT JOIN offices ON offices.officename = employees.office
                  LEFT JOIN groups ON groups.groupname = employees.groups';
        $oldOffices = PDO_query($query, false, false, $dbCredentials);

        foreach ($oldOffices as $office){
            extract($office);
            $data = array();

            $data['user_id'] = $userIDs[$empfullname];
            $data['group_id'] = $officeid > 1 ? $officeid : 32767;
            $this->db->insert('user_groups', $data);

            $data['group_id'] = $groupid > 1 ? ($groupid + 32767) : 32766;
            $this->db->insert('user_groups', $data);
        }


/*
 * Add all users to "All Users" group with punch permission
 */
        $result = PDO_query('SELECT empfullname FROM `'.$tablePrefix.'employees`', false, false, $dbCredentials);
        foreach ($result as $row){
            extract($row);

            $this->db->insert('user_groups', array('user_id' => $userIDs[$empfullname], 'group_id' => 1, 'permissions' => 'punch'));
        }

/*
 * Punch Types
 */
        $oldPunchTypes = PDO_query('SELECT punchitems, in_or_out, color FROM `'.$tablePrefix.'punchlist`', false, false, $dbCredentials);
        foreach ($oldPunchTypes as $punchType){
            extract($punchType);
            $data = array();

            $data['status'] = $in_or_out;
            $data['name'] = $punchitems;
            $data['color'] = str_replace('#', '', $color);
            $data['enabled'] = 1;
            $this->db->insert('punch_types', $data);
        }
        $this->db->query('UPDATE `'.TABLE_PREFIX.'punch_types` set `order` = `id`');

/*
 * Punches
 */
        

        $statusIDs = array();
        $this->db->select('id, status, name');
        $statusTypes = $this->db->get('punch_types');
        foreach ($statusTypes->result() as $statusType){
            $statusTypeIDs[$statusType->name] = $statusType->id;
        }

        $users = PDO_query('SELECT empfullname FROM `'.$tablePrefix.'employees`', false, false, $dbCredentials);
        $this->addedPunches = 0;
        foreach ($users as $user){
            $numPunches = PDO_query('SELECT COUNT(*) FROM `'.$tablePrefix.'info` WHERE fullname = :empfullname', array('empfullname' => $user['empfullname']), false, $dbCredentials);
            $numPunches = $numPunches[0]['COUNT(*)'];
            $maxInserts = 100;
            $maxLimit = $maxInserts + 1;
            for ($i = 0; $i < $numPunches; $i += $maxInserts){
                $params = array();
                $params['empfullname'] = $user['empfullname'];
                $query = "SELECT fullName, `inout`, `timestamp`, notes, `ipaddress`
                            FROM `".$tablePrefix."info`
                            WHERE fullname = :empfullname
                            ORDER BY `timestamp` ASC
                            LIMIT $i, $maxLimit";
                $oldPunches = PDO_query($query, $params, false, $dbCredentials);
                // @TODO Finish V1 import here
                $query = 'INSERT INTO `'.TABLE_PREFIX.'punches` (`user_id`, `group_id`, `punch_type_id`, `ip_address`, `date_time`, `notes`, `approved`) VALUES
';
                $values = array();
                foreach ($oldPunches as $index => $punch){
                    if ($index != $maxInserts){
                        extract($punch);
                        $data = array();

                        $values[] = $user_id = $userIDs[$fullName];
                        $values[] = $group_id = 1;
                        $values[] = $punch_type_id = $statusTypeIDs[$inout];
//                      $values[] = $next_punch_id = isset($oldPunches[$index + 1]['punch_log_id']) ? $oldPunches[$index + 1]['punch_log_id'] : NULL;
                        $values[] = $ipaddress ? $ipaddress : '';
                        $values[] = date('Y-m-d H:i:s', $timestamp);
                        $values[] = $notes;
                        $values[] = 1;

                        $query .= "(?, ?, ?, ?, ?, ?, ?),";

                        $this->addedPunches++;
                    }
                }
                $query = trimString($query);
                
                $this->db->query($query, $values);
            }
        }

/*
 * Update next_punch_ids
 */
        $users = $this->db->get('users');
        foreach($users->result_array() as $index => $user){
            $this->db->order_by('date_time', 'ASC');
            $punches = $this->db->get_where('punches', array('user_id' => $user['id']));
            $punches = $punches->result();
            foreach($punches as $index => $punch){
                $nextPunchID = isset($punches[$index + 1]) ? $punches[$index + 1]->id : NULL;

                $this->db->where('id', $punches[$index]->id);
                $this->db->update('punches', array('next_punch_id' => $nextPunchID));
            }
        }

/*
 * Permissions
 */
    // Offices
        $query = 'SELECT empfullname, admin, reports, time_admin
                    FROM `'.$tablePrefix.'employees`';
        $userPermissions = PDO_query($query, false, false, $dbCredentials);
        foreach ($userPermissions as $permission){
            extract($permission);

            if ($admin){
                $this->db->where('id', $userIDs[$empfullname]);
                $this->db->update('users', array('sys_admin' => $admin));
            }
            if ($reports){
                $result = $this->db->get_where('user_groups', array('user_id' => $userIDs[$empfullname], 'group_id' => 1));
                foreach ($result->result() as $user){
                    $this->db->where('id', $user->id);
                    $this->db->update('user_groups', array('permissions' => $user->permissions ? "$user->permissions|runReports" : 'runReports'));
//                    dump("$user->permissions,runReports");
//                    die();
                }
            }
            if ($time_admin){
                $result = $this->db->get_where('user_groups', array('user_id' => $userIDs[$empfullname], 'group_id' => 1));
                foreach ($result->result() as $user){
                    $this->db->where('id', $user->id);
                    $this->db->update('user_groups', array('permissions' => $user->permissions ? "$user->permissions|editTime" : 'editTime'));
                }
            }
        }
    }


/********************************
 ******* Version 2 Import *******
 ********************************/
    function import_from_v2($dbCredentials, $tablePrefix){
/*
 * Users
 */
        $nullPasswords = $weakPasswords = 0;
        $nullPasswordUsers = $weakPasswordUsers = array();

        $this->addedUsers = 0;
        $oldUsers = PDO_query('SELECT user_id, user_name, full_name, email, user_password, enabled FROM `'.$tablePrefix.'users`', false, false, $dbCredentials);
        foreach ($oldUsers as $user){
            extract($user);
            $this->addedUsers++;
            $data = array();
            $data['id'] = $user_id;
            $data['username'] = $user_name;
            if ($user_password == NULL){
                $newPassword = generatePassword();
                $data['password'] = encrypt_password($newPassword);
                @$nullPasswords++;
                @$nullPasswordUsers[$user_name] = $newPassword;
            }
            else if (substr($user_password, 0, 2) == 'xy'){
                $newPassword = generatePassword();
                $data['password'] = encrypt_password($newPassword);
                @$weakPasswords++;
                @$weakPasswordUsers[$user_name] = $newPassword;
            }
            else {
                $data['password'] = $user_password;
            }

            if (strpos($full_name, ' ')){
                $data['first_name'] = substr($full_name, 0, strrpos($full_name, ' '));
                $data['last_name'] = substr($full_name, strrpos($full_name, ' ') + 1);
            }
            else {
                $data['first_name'] = $full_name;
                $data['last_name'] = '';
            }

            $data['email'] = $email;
            $data['enabled'] = $enabled;
            $this->db->insert('users', $data);
        }
        if ($nullPasswords){
            $this->data['output'] .= "<br /><strong>There were $nullPasswords empty passwords, passwords have been reset. <br />";
            $this->data['output'] .= 'The following users were effected: </strong><br />';

            $rowsPerCol = ceil(count($nullPasswordUsers) / 5);
            $row = $col = 1;

            if (count($nullPasswordUsers) > 1){
                foreach ($nullPasswordUsers as $username => $password){
                    $result = $this->db->get_where('users', array('username' => $username));
                    $result = $result->result();
                    $usernames[$username] = $result[0]->username;
                    $fullNames[$username] = $result[0]->first_name . ' ' . $result[0]->last_name;


                    $links[$row][$col] =  "<strong>$username:</strong> $password";

                    if ($row == $rowsPerCol){
                        $row = 1;
                    }
                    else {
                        $row++;
                    }

                    if ($col == 5){
                        $col = 1;
                    }
                    else {
                        $col++;
                    }
                }

                $this->data['output'] .= '<table class="everythingTable">';
                    foreach ($links as $row){
                        $this->data['output'] .= '<tr>';
                            foreach ($row as $col){
                                $this->data['output'] .= "<td valign='top'>$col</td>";
                            }
                        $this->data['output'] .= '</tr>';
                    }
                $this->data['output'] .= '</table>';
            }
        }
        $this->data['output'] .=  '<br />';

        if ($weakPasswords){
            $this->data['output'] .= "<br /><strong>There were $weakPasswords passwords that were using a weaker password hash from previous version, passwords have been reset. <br />";
            $this->data['output'] .= 'The following users were effected: </strong><br />';

            $rowsPerCol = ceil(count($weakPasswordUsers) / 5);
            $row = $col = 1;

            if (count($weakPasswordUsers) > 1){
                foreach ($weakPasswordUsers as $username => $password){
                    $result = $this->db->get_where('users', array('username' => $username));
                    $result = $result->result();
                    $usernames[$username] = $result[0]->username;
                    $fullNames[$username] = $result[0]->first_name . ' ' . $result[0]->last_name;


                    $links[$row][$col] =  "<strong>$username:</strong> $password";

                    if ($row == $rowsPerCol){
                        $row = 1;
                    }
                    else {
                        $row++;
                    }

                    if ($col == 5){
                        $col = 1;
                    }
                    else {
                        $col++;
                    }
                }

                $this->data['output'] .= '<table class="everythingTable">';
                    foreach ($links as $row){
                        $this->data['output'] .= '<tr>';
                            foreach ($row as $col){
                                $this->data['output'] .= "<td valign='top'>$col</td>";
                            }
                        $this->data['output'] .= '</tr>';
                    }
                $this->data['output'] .= '</table>';
            }
        }


/*
 * Groups
 */
        $this->db->insert('groups', array('id' => 1, 'parent_id' => 0, 'name' => 'All Users'));

    // Old Offices
        $this->addedGroups = 0;
        $oldOffices = PDO_query('SELECT office_id, office_name FROM `'.$tablePrefix.'offices`', false, false, $dbCredentials);
        foreach ($oldOffices as $office){
            $this->addedGroups++;
            extract($office);
            $data = array();

            $data['id'] = $office_id > 1 ? $office_id : 32767;
            $data['parent_id'] = 1;
            $data['name'] = $office_name;
            $this->db->insert('groups', $data);
        }

    // Old Departments
        $oldDepartments = PDO_query('SELECT department_id, office_id, department_name FROM `'.$tablePrefix.'departments`', false, false, $dbCredentials);
        foreach ($oldDepartments as $department){
            $this->addedGroups++;
            extract($department);
            $data = array();

            $data['id'] = (($department_id > 1) ? ($department_id + 32767) : 32766);
            $data['parent_id'] = $office_id > 1 ? $office_id : 32767;
            $data['name'] = $department_name;
            $this->db->insert('groups', $data);
        }

    // Update Auto Increment
        $maxID = PDO_query('SELECT MAX(office_id) AS maxID FROM `'.$tablePrefix.'offices`', false, false, $dbCredentials);
        $maxID = $maxID[0]['maxID'];
        mysql_query("ALTER TABLE `".TABLE_PREFIX."groups` AUTO_INCREMENT = $maxID") or die(mysql_error());

/*
 * User Groups
 */
    // Offices
        $oldOffices = PDO_query('SELECT user_id, office_id FROM `'.$tablePrefix.'user_offices`', false, false, $dbCredentials);
        foreach ($oldOffices as $office){
            extract($office);
            $data = array();

            $data['user_id'] = $user_id;
            $data['group_id'] = $office_id > 1 ? $office_id : 32767;
            $this->db->insert('user_groups', $data);
        }
    // Departments
        $oldDepartments = PDO_query('SELECT user_id, department_id FROM `'.$tablePrefix.'user_departments`', false, false, $dbCredentials);
        foreach ($oldDepartments as $department){
            extract($department);
            $data = array();

            $data['user_id'] = $user_id;
            $data['group_id'] = $department_id > 1 ? ($department_id + 32767) : 32766;
            $this->db->insert('user_groups', $data);
        }

/*
 * Add all users to "All Users" group with punch permission
 */
        $result = PDO_query('SELECT user_id FROM `'.$tablePrefix.'users`', false, false, $dbCredentials);
        foreach ($result as $row){
            extract($row);

            $this->db->insert('user_groups', array('user_id' => $user_id, 'group_id' => 1, 'permissions' => 'punch'));
        }

/*
 * Punch Types
 */
        $oldPunchTypes = PDO_query('SELECT punch_id, punch_status_name, status_in, colour, default_display, enabled FROM `'.$tablePrefix.'punch_statuses`', false, false, $dbCredentials);
        foreach ($oldPunchTypes as $punchType){
            extract($punchType);
            $data = array();

            $data['id'] = $punch_id;
            $data['status'] = $status_in;
            $data['name'] = $punch_status_name;
            $data['color'] = $colour;
            $data['enabled'] = $enabled;
            $this->db->insert('punch_types', $data);
        }
        $this->db->query('UPDATE `'.TABLE_PREFIX.'punch_types` set `order` = `id`');

/*
 * Punches
 */
        $users = PDO_query('SELECT user_id FROM `'.$tablePrefix.'users`', false, false, $dbCredentials);
        $this->addedPunches = 0;
        foreach ($users as $user){
            $numPunches = PDO_query('SELECT COUNT(*) FROM `'.$tablePrefix.'punch_log` WHERE user_id = :userID', array('userID' => $user['user_id']), false, $dbCredentials);
            $numPunches = $numPunches[0]['COUNT(*)'];
            for ($i = 0; $i < $numPunches; $i += 100){
                $params = array();
                $params['userID'] = $user['user_id'];
                $query = "SELECT punch_log_id, user_id, punch_id, punch_time, ip_address, user_notes, department_id, approved
                            FROM `".$tablePrefix."punch_log`
                            WHERE user_id = :userID
                            ORDER BY punch_time ASC
                            LIMIT $i, 101";
                $oldPunches = PDO_query($query, $params, false, $dbCredentials);
                $query = 'INSERT INTO `'.TABLE_PREFIX.'punches` (id, user_id, group_id, punch_type_id, next_punch_id, ip_address, date_time, notes, approved) VALUES ';
                $values = array();
                foreach ($oldPunches as $index => $punch){
                    if ($index != 100){
                        extract($punch);
                        $data = array();

                        $values[] = $id = $punch_log_id;
                        $values[] = $user_id = $user_id;
                        $values[] = $group_id = $department_id ? $department_id : 1;
                        $values[] = $punch_type_id = $punch_id;
                        $values[] = $next_punch_id = isset($oldPunches[$index + 1]['punch_log_id']) ? $oldPunches[$index + 1]['punch_log_id'] : NULL;
                        $values[] = $ip_address = $ip_address ? $ip_address : '';
                        $values[] = $date_time = $punch_time;
                        $values[] = $notes = $user_notes;
                        $values[] = $approved = $approved;

                        $query .= "(?, ?, ?, ?, ?, ?, ?, ?, ?),";

                        $this->addedPunches++;
                    }
                }
                $query = trimString($query);
                $this->db->query($query, $values);
            }
        }

/*
 * Permissions
 */
    // Offices
        $query = 'SELECT action_office_id, user_id, office_id, GROUP_CONCAT(DISTINCT allowed_action) AS allowed_actions
                    FROM `'.$tablePrefix.'action_offices`
                    LEFT JOIN `'.$tablePrefix.'actions` ON `'.$tablePrefix.'action_offices`.`action_id` = `'.$tablePrefix.'actions`.`action_id`
                    GROUP BY user_id';
        $officeActions = PDO_query($query, false, false, $dbCredentials);
        foreach ($officeActions as $action){
            extract($action);
            $actions = explode(',', $allowed_actions);

            if (in_array('admin application', $actions) OR in_array('admin user', $actions)){
                $this->db->where('id', $user_id);
                $this->db->update('users', array('sys_admin' => 1));
            }
            if (in_array('admin time', $actions) OR in_array('approve time', $actions)){
                $this->db->where('group_id', $office_id == 1 ? 32767 : $office_id);
                $this->db->update('user_groups', array('permissions' => 'editTime'));
            }
        }
    // Departments
        $query = 'SELECT action_department_id, user_id, department_id, GROUP_CONCAT(DISTINCT allowed_action) AS allowed_actions
                    FROM `'.$tablePrefix.'action_departments`
                    LEFT JOIN `'.$tablePrefix.'actions` ON `'.$tablePrefix.'action_departments`.`action_id` = `'.$tablePrefix.'actions`.`action_id`
                    GROUP BY user_id';
        $departmentActions = PDO_query($query, false, false, $dbCredentials);
        foreach ($departmentActions as $action){
            extract($action);
            $actions = explode(',', $allowed_actions);

            if (in_array('admin application', $actions) OR in_array('admin user', $actions)){
                $this->db->where('id', $user_id);
                $this->db->update('users', array('sys_admin' => 1));
            }
            if (in_array('admin time', $actions) OR in_array('approve time', $actions)){
                $this->db->where('group_id', $department_id + 32768);
                $this->db->update('user_groups', array('permissions' => 'editTime'));
            }
        }
    }

/********************************
 ********** Copy table **********
 ********************************/

    function copy_table($dbCredentials, $tableName, $tablePrefix){
        $addedRows = 0;
        $oldTable = PDO_query("SELECT * FROM `$tablePrefix"."$tableName`", false, false, $dbCredentials);

        foreach ($oldTable as $index => $tableRow){
            $data = array();
            foreach ($tableRow as $index => $value){
                $data[$index] = $value;
            }

            $this->db->insert($tableName, $data);

            $addedRows++;
        }
        return $addedRows;
    }

/********************************
 ******* Version 3 Import *******
 ********************************/
    function import_from_v3($dbCredentials, $tablePrefix){
/*
 * Users
 */
        $this->addedUsers = $this->copy_table($dbCredentials, 'users', $tablePrefix);
        
/*
 * Groups
 */
        $this->addedGroups = $this->copy_table($dbCredentials, 'groups', $tablePrefix);

/*
 * User Groups / Permissions
 */
        $this->copy_table($dbCredentials, 'user_groups', $tablePrefix);

/*
 * Punch Types
 */
        $this->copy_table($dbCredentials, 'punch_types', $tablePrefix);

/*
 * Punches
 */
        $users = PDO_query('SELECT id FROM `'.$tablePrefix.'users`', false, false, $dbCredentials);
        $this->addedPunches = 0;
        foreach ($users as $user){
            $numPunches = PDO_query('SELECT COUNT(*) FROM `'.$tablePrefix.'punches` WHERE user_id = :userID', array('userID' => $user['id']), false, $dbCredentials);
            $numPunches = $numPunches[0]['COUNT(*)'];
            for ($i = 0; $i < $numPunches; $i += 100){
                $params = array();
                $params['userID'] = $user['id'];
                $query = "SELECT id, user_id, group_id, punch_type_id, next_punch_id, ip_address, date_time, notes, approved, approved_by
                            FROM `".$tablePrefix."punches`
                            WHERE user_id = :userID
                            ORDER BY date_time ASC
                            LIMIT $i, 101";
                $oldPunches = PDO_query($query, $params, false, $dbCredentials);
                $query = 'INSERT INTO `'.TABLE_PREFIX.'punches` (id, user_id, group_id, punch_type_id, next_punch_id, ip_address, date_time, notes, approved, approved_by) VALUES ';
                $values = array();
                foreach ($oldPunches as $index => $punch){
                    if ($index != 100){
                        extract($punch);
                        $data = array();

                        $values[] = $id;
                        $values[] = $user_id ;
                        $values[] = $group_id;
                        $values[] = $punch_type_id;
                        $values[] = $next_punch_id;
                        $values[] = $ip_address;
                        $values[] = $date_time;
                        $values[] = $notes;
                        $values[] = $approved;
                        $values[] = $approved_by;

                        $query .= "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?),";

                        $this->addedPunches++;
                    }
                }
                $query = trimString($query);
                $this->db->query($query, $values);
            }
        }
/*
 * Tags
 */
        $this->copy_table($dbCredentials, 'tags', $tablePrefix);

/*
 * Audits
 */
        $this->copy_table($dbCredentials, 'audits', $tablePrefix);

/*
 * Config
 */
        $oldBaseURL = $this->Config->item('base_url');
        $oldUseSSL  = $this->Config->item('useSSL');

        $this->db->query('TRUNCATE `'.TABLE_PREFIX.'config`');
        $query = "INSERT INTO `".TABLE_PREFIX."config` (`id`, `option`, `value`) VALUES
                    (1, 'language', 'en_US'),
                    (2, 'template', 'default'),
                    (3, 'timezone', 'T078'),
                    (4, 'db_version', '3'),
                    (5, 'companyName', 'Nexus'),
                    (6, 'userIdentifier', 'username'),
                    (7, 'punchBoardDays', '7'),
                    (8, 'DeveloperMode', '0'),
                    (9, 'selectGroupDisplay', 'always'),
                    (10, 'selectStatusStyle', 'buttons'),
                    (11, 'lastNameView', 'name'),
                    (12, 'restrictIPAddresses', 'No'),
                    (13, 'base_url', ''),
                    (14, 'useSSL', '0'),
                    (15, 'developerMode', '0'),
                    (16, 'useTags', 'Yes'),
                    (17, 'timeFormat', '12Hr'),
                    (18, 'dateFormat', 'm/d/Y'),
                    (19, 'punchBoardGroup', 'Show'),
                    (20, 'punchBoardNotes', 'Show'),
                    (21, 'minPasswordLength', '8'),
                    (22, 'userIdentifier_punch', 'username'),
                    (23, 'userIdentifier_board', 'username'),
                    (24, 'report_roundingDigits', '4'),
                    (25, 'report_showGroup', '1'),
                    (26, 'report_showTags', '1'),
                    (27, 'report_showDuration', '1'),
                    (28, 'report_enabledDurations', '1,2,3,4'),
                    (29, 'report_enabledTotals', '1,2,3,4'),
                    (30, 'report_durationFormat', 'decimal'),
                    (31, 'report_showOvertime', '0'),
                    (32, 'report_OTperWeekHours', '40'),
                    (33, 'report_OTperDayHours', '8'),
                    (34, 'requireEditReason', '1'),
                    (35, 'APIKey', 'QOh8T7GCiSj6WG4mGHCm'),
                    (36, 'apiEnabled', '1')";
        $this->db->query($query);

        $oldTable = PDO_query('SELECT * FROM '.$tablePrefix.'config`', false, false, $dbCredentials);

        foreach ($oldTable as $index => $tableRow){
            $data = array();
            foreach ($tableRow as $index => $value){
                $data[$index] = $value;
            }
            $this->db->where('id', $id);
            $this->db->update('config', $data);
        }
        $this->db->where('option', 'base_url');
        $this->db->update('config', array('value' => $oldBaseURL));
        $this->db->where('option', 'useSSL');
        $this->db->update('config', array('value' => $oldUseSSL));
    }

    function import_from_db($dbCredentials, $tablePrefix){
        $timeStart = microtime(true);
        $this->data['output'] = '';

        $this->initialize_db();

        $result = PDO_query('SHOW TABLES', false, false, $dbCredentials);

        foreach ($result as $row){
            if (in_array('dbversion', $row)){
                $this->import_from_v1($dbCredentials,$tablePrefix);
                break;
            }
            else if (in_array('action_applications', $row)){
                $this->import_from_v2($dbCredentials,$tablePrefix);
                break;
            }
            else if (in_array('config', $row)){
                $this->import_from_v3($dbCredentials,$tablePrefix);
                break;
            }
        }

        $this->addedUsers = number_format($this->addedUsers, 0);
        $this->data['output'].= '<br />';
        $this->data['output'].= "<br />Added $this->addedUsers Users";
        $this->addedGroups = number_format($this->addedGroups, 0);
        $this->data['output'].= "<br />Added $this->addedGroups Groups";
        $this->addedPunches = number_format($this->addedPunches, 0);
        $this->data['output'].= "<br />Added $this->addedPunches Punches";
        $timeElapsed = number_format(microtime(true) - $timeStart, 4);
        $this->data['output'].= "<br />DB Import ran in $timeElapsed";




        $timeElapsed = number_format(microtime(true) - $timeStart, 4);
        $this->data['output'].= "<br /> Imported in $timeElapsed seconds";
    }


    function __construct(){
        parent::__construct();

        
    }
}
?>