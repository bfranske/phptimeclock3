<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Group extends Model{
    private $flatGroupList = array();

    function get_upline($groupID, $topLevel = true){
        global $upline;
        if ($topLevel){
            $upline = array();
        }
        $result = $this->db->get_where('groups', array('id' => $groupID));
        $result = $result->result();
        $upline[$result[0]->id] = $result[0]->name;

        if ($groupID != 1){
            $this->get_upline($result[0]->parent_id, false);
        }

        if ($topLevel){
            return $upline;
        }
    }

    function get_uplines($groups = false){
        if ($groups !== false AND !is_array($groups))
            $groups = array($groups);
        
        foreach ($groups as $group){
            $uplines[$group] = $this->get_upline($group);
        }
        return $uplines;
    }

    function is_enabled($groupID){
        $result = $this->db->get_where('groups', array('id' => $groupID));
        $info = $result->result();
        foreach ($info as $row){
            if ($row->enabled){
                return true;
            }
        }
        return false;
    }
    function update_enabled_status($id, $newStatus){
        $this->db->where('id', $id);
        $this->db->update('groups', array('enabled' => $newStatus));
    }

    function are_disabled_groups(){
        $result = $this->db->get_where('groups', array('enabled' => 0));
        if ($result->num_rows){
            return true;
        }
        else {
            return false;
        }
    }
    function get_users($id = 0, $returnIDs = false){
        $this->db->from('users');
        $this->db->join('user_groups', 'users.id = user_groups.user_id');
        $this->db->join('groups', 'user_groups.group_id = groups.id');
        $this->db->where("groups.id = $id");
        $this->db->order_by('name', 'asc');
        $info = $this->db->get();
        if ($returnIDs){
            $ids = array();
            foreach ($info->result() as $user){
//                dump($user);
                $ids[] = $user->user_id;
            }
            return $ids;
        }
        else {
            return $info;
        }
    }

    function get_children($parentGroupID = 1, $addGroups = false, $array = false, $groupID = 1){
        static $groups = array();

        if ($array === false){
            $array = $this->tree();
        }
        if (isset($array['children'])) {
            foreach($array['children'] as $child){
                if ($addGroups OR $child['info']['id'] == $parentGroupID){
                    $this->get_children($parentGroupID, true, $child, $child['info']['id']);
                }
                else {
                    $this->get_children($parentGroupID, false, $child, $child['info']['id']);
                }
            }
        }
        if (isset($array['info'])){
            if ($addGroups){
                $groups[] = $array['info']['id'];
            }
        }
        else {
            $returnGroups = $groups;
            $groups = array();
            return $returnGroups;
        }
    }

    function tree($parent_id = 0, $level = 0, $getUsers = false, $punchUser = false){
        $return = array();

        $this->db->order_by('name', 'asc');
        $result = $this->db->get_where('groups', array('id' => $parent_id));
        if ($result->num_rows()){
            $results = $result->result();
            $return['info'] = array('id' => $results[0]->id, 'name' => $results[0]->name, 'level' => $level);

            if ($getUsers){
                $this->db->select('users.id, user_id, group_id, enabled');
                $this->db->join('users', 'user_id = users.id');
                $users = $this->db->get_where('user_groups', array('group_id' => $results[0]->id));
                if ($users->num_rows()){
                    $return['users'] = $users->result();
                }
            }
        }

        $this->db->order_by('name', 'asc');
        $children = $this->db->get_where('groups', array('parent_id' => $parent_id));

        if ($children->num_rows()){
            $childrenResults = $children->result();
            foreach ($childrenResults as $row){
                $return['children'][] =  $this->tree($row->id, $level + 1, $getUsers);
            }
        }
        return $return;
    }

    function get_user_group_list($userID = false){
        if (! $userID){
            $userID = $this->session->userdata('userID');
        }
        if ($this->flatGroupList === array()){
            $this->db->select('group_id');
            $groups = $this->db->get_where('user_groups', array('user_id' => $userID));
            foreach ($groups->result() as $group){
                $this->flatGroupList[] = $group->group_id;
            }
        }

        return $this->flatGroupList;
    }

    function get_camera_urls(){
        $result = $this->db->get('groups');
        $result = $result->result();
        foreach ($result as $row){
            $cameraURLs[$row->id] = $row->camera_url;
        }
        return @$cameraURLs;
    }

    function get_camera_url($groupID){
        $this->db->where('id', $groupID);
        $result = $this->db->get('groups');
        $result = $result->result();

        return @$result[0]->camera_url;
    }

    function __construct(){
        parent::__construct();
        
    }
}
?>
