<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Permissions extends Group{
    public $permissions = array();
    public $groups      = array();
    private $db_groups;

    public $tree;

    function get_permissions($userID){
        $this->db->where('permissions != ""');
        $this->db->where('user_id', $userID);
        $permissions = $this->db->get('user_groups');
        $result = array();
        foreach ($permissions->result() as $permission){
            $result[] = array('groupID' => $permission->group_id, 'permissions' => $permission->permissions);
        }
        return $result;
    }

    public function permissions($array, $level = 0){
        static $groups = array();
        static $output = array();
        
        if (isset($array['info'])){
            $groups [] = $array['info']['id'];

            if (isset($array['users'])){
                foreach ($array['users'] as $user){
                    if ($level == 0 AND $user->user_id == $this->session->userdata('userID')){
                        $groupPermissions = $user->permissions;
                    }
                }
            }

            if (isset($array['children'])){
                foreach ($array['children'] as $child){
                    $this->permissions($child, $level + 1);
                }
            }
        }

        if ($level == 0){
            $finalOutput = array();
            if (isset($groupPermissions)){
                $output['groups'] = $groups;
                $output['permissions'] = $groupPermissions;
            }
            $groups = array();
        }

        return $output;


    }

    function has_permission($groupID, $permission, $userID = false, $resetPermissions = false){
        static $currentLoadedPermissions = NULL;
        if ($userID !== false AND $currentLoadedPermissions != $userID){
            $groupCache = $this->groups;
            $this->load_permissions($userID);
            $currentLoadedPermissions = $userID;
        }

//        $permissions = $this->session->userdata('permissions');

        $hasPermission = NULL;
        $searchGroup = $groupID;
        $found = false;
        $i = 0;
        //OR ($permission == 'punch' AND $searchGroup == 1) /*OR $permission != 'punch' OR $searchGroup != 1)*/
        do {            
            if (isset($this->groups[$searchGroup])){
                if (in_array($permission, $this->groups[$searchGroup]['permissions']) ){
                    $hasPermission = true;
                    $found = true;
                }
                else if (in_array("not_$permission", $this->groups[$searchGroup]['permissions'])){
                    $hasPermission = false;
                    $found = true;
                }
                else {
                    $searchGroup = $this->db_groups[$searchGroup];
                }
            }
            else if ($permission == 'punch' AND $searchGroup == 1) {
                $hasPermission = true;
                $found = true;
            }
            else if ($searchGroup != 1){
                if (isset($searchGroup) AND $searchGroup){
                    if (! isset($this->db_groups[$searchGroup])){
//                        dump($this->db_groups);
//                        die();
                    }
                    $searchGroup = $this->db_groups[$searchGroup];
                }
                else
                    break;
            }
            else {
                break;
            }
        } while (! $found);

        if ($resetPermissions){
            if ($userID !== false){
                $this->groups = $groupCache;
                $this->load_permissions();
            }
        }
//dump($groupID);
        return $hasPermission;
    }

    function get_permission_groups($userID, $permission, $onlyEnabled = true){
        static $groups;
        if (! is_array($groups)){
            if ($onlyEnabled){
                $this->db->where('enabled', 1);
            }
            $groups = $this->db->get('groups');
        }

        $returnGroups = array();

        if ((int)$userID){
            $permissionGroups = array();

            foreach ($groups->result() as $group){
                if ($this->has_permission($group->id, $permission, $userID, false)){
//                    echo "($group->id, $permission, $userID) <br />";
                    $permissionGroups[] = $group->id;
                }
            }

        // Set permissions back to user (MUST be done)
            $this->load_permissions();
        //

            if (count($permissionGroups)){
                $groupsArray = array();
                foreach ($groups->result() as $group){
                    $groupsArray[$group->id] = $group->name;
                }
                foreach ($permissionGroups as $group){
                    $returnGroups[$group] = $groupsArray[$group];
                }
            }
        }
        return $returnGroups;
    }

    function has_any_admin_permission($userID = false){
        if (! $userID){
            $userID = $this->session->userdata('userID');
        }

        if ($this->session->userdata('sys_admin')){
            return true;
        }

        foreach ($this->Group->get_user_group_list() as $group){
            if ($this->has_permission($group, 'runReports') OR $this->has_permission($group, 'runReports')){
                return true;
            }
        }

        return false;
    }

    function has_any_punch_permission($userID = false){
        if (! $userID){
            $userID = $this->session->userdata('userID');
        }

        foreach ($this->Group->get_user_group_list() as $group){
            if ($this->has_permission($group, 'punch')){
                return true;
            }
        }

        return false;
    }

    function load_permissions($userID = false){
        if ($userID == false){
            $userID = $this->session->userdata('userID');
        }
        if ($userID){
            $this->groups = array();

        // All Groups
            $this->db->select('groups.id, parent_id, name');
            $groups = $this->db->get('groups');

            foreach ($groups->result() as $group){
                $this->db_groups[$group->id] = $group->parent_id;
            }
        // Users groups
            $this->db->select('groups.id, parent_id, name, group_id, permissions');
            $this->db->join('user_groups', 'groups.id = user_groups.group_id');
            $groups = $this->db->get_where('groups', 'user_id = ' . $userID);

            foreach ($groups->result() as $group){
                $permissions = explode('|', $group->permissions);
                $this->groups[$group->id] = array('parentID' => $group->parent_id, 'permissions' => $permissions);
            }
    //        dump($this->groups);

            $this->session->set_userdata('permissions', $this->permissions);
        }
    }

    function __construct(){
        parent::__construct();

        $this->load_permissions();
    }
}
?>