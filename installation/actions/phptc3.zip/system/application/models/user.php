<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class User extends Model{
    public $userID;
    public $username;
    public $password;
    public $firstName;
    public $lastName;

    function get_group_permissions($userID = false){
        $userGroups = array();
        $this->db->join('groups', 'groups.id = group_id');
        $result = $this->db->get_where('user_groups', array('user_id' => $userID));
        foreach ($result->result() as $group){
            $userGroups[$group->group_id] = array('name' => $group->name,
                                                  'permissions' => $group->permissions);
        }
        return $userGroups;
    }

    function get_info($userID = false, $whatToLoad = array('base')){
        if ($userID !== false)
            $this->userID = $userID;
        $userInfo = array();

        if (in_array('base', $whatToLoad)){
            $result = $this->db->get_where('users', array('id' => $userID));
            $userInfo['base'] = $result->result();
        }

        return $userInfo;
    }

    function add_user($info = false){
        if (is_array($info)){
            $this->db->insert('users', $info);

            $info = array();
            $info['user_id'] = $this->db->insert_id();
            $info['group_id'] = $this->input->post('groupID');
            $this->db->insert('user_groups', $info);

            redirect('admin/user_add');
        }
    }

    function username_exists($username){
        $result = $this->db->get_where('users', array('username' => $username));
        if ($result->num_rows()){
            return true;
        }
        else {
            return false;
        }
    }
//if ($row->password == encrypt_password($_POST['password'], $row->password)){
    function check_password($userID, $password){
        $result = $this->db->get_where('users', "id = $userID");
        $result = $result->result();
        if (encrypt_password($password, $result[0]->password) == $result[0]->password)
            return true;
        else
            return false;
    }

    function status_change_check($userID, $newStatus, $newGroupID, $newTags){
        if ($userID){
            if ((int)$newStatus){
                $newStatus = (int)$newStatus;
            }
            else {
                $this->db->select('id')->from('punch_types')->where('name', $newStatus);
                $newStatus = $this->db->get();
                $newStatus = $newStatus->result();
                $newStatus = $newStatus[0]->id;
            }

            $result = $this->db->get_where('punch_board', "user_id = $userID");
            $result = $result->result();

            $newTags = explode(',', $newTags);
            $oldTags = $this->db->get_where('punch_board', array('user_id' => $userID));
            $oldTags = $oldTags->result();
            $oldTags = explode(',', isset($oldTags[0]) ? $oldTags[0]->tags : '');
            foreach ($newTags as $index => $tag){
                $newTags[$index] = trim($tag);
            }
            
//            dump($oldTags);
//            dump($newTags);
//            dump(array_diff($oldTags, $newTags));
//            dump(array_diff($newTags, $oldTags));
//            die();
            
            if (count($result) AND $result[0]->punch_type_id == $newStatus AND $result[0]->group_id == $newGroupID AND
                    array_diff($oldTags, $newTags) === array_diff($newTags, $oldTags)){
                
                return false;
            }
            else{
                return true;
            }
        }
    }
    
    function __construct(){
        parent::__construct();

        
    }
}
?>
