<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Punches extends Model{
   
    function get_punches($userID, $groupID = 0, $groupsScope = 'all', $startDate = false, $endDate = false, $tags = false, $cachedGroups = false){
        if (! $userID){
            return array();
        }
        static $punchesGroups;

//        $CI =& get_instance();
        $startDate = local_to_gmt(strtotime($startDate), $this->Config->item('timezone'));
        $endDate   = local_to_gmt(strtotime($endDate) + (3600*24) - 1, $this->Config->item('timezone'));

        $startDate = date('Y-m-d H:i:s', $startDate ? $startDate : 0);
        $endDate = date('Y-m-d H:i:s', $endDate ? $endDate : local_to_gmt(time(), $this->Config->item('timezone')));

        if (is_array($userID)){
            foreach ($userID as $user){
                $userArray[] = $user;
            }
        }
        else {
            $userArray = array($userID);
        }

        if ($groupsScope !== 'userAll'){
            if (is_array($cachedGroups)){
                $groups = $cachedGroups;
            }
            else {
                if ($groupsScope == 'all'){
                    $groups = $this->Group->get_children();
                }
                else if ($groupsScope == 'children') {
                    if ($groupID){
                        $groups = $this->Group->get_children($groupID);
                        
                    }
                }
                else{
                    $groups = array($groupID);
                }
            }

            if (count($groups)){
                foreach ($groups as $index => $group){
                    if ($groupsScope == 'userAll' OR $this->Permissions->has_permission($group, 'runReports') OR $this->Permissions->has_permission($group, 'editTime')){
                        $groupsArray[] = $group;
                    }
                }
            }
        }

        $this->db->select('punch_log.id AS id, user_id, group_id, group_name, punch_type_id, date_time, end_time, duration, status_name, status, tags, notes, approved, approved_by, ip_address, GROUP_CONCAT(`'.TABLE_PREFIX.'audits`.`id`) AS audit_ids');
        $this->db->join('users', 'users.id = user_id', 'left');
        $this->db->join('audits', 'audits.punch_id = punch_log.id', 'left');
        $this->db->where("date_time BETWEEN '$startDate' AND '$endDate'");
        $this->db->where_in('user_id', $userArray);
        if (isset($groupsArray))
            $this->db->where_in('group_id', $groupsArray);
        if (is_array($tags)){
            $this->db->join('punch_tags', 'punch_log.id = punch_tags.punch_id', 'left');
            $this->db->where_in('tag_id', $tags);
        }
        $this->db->group_by('punch_log.id');
        $this->db->order_by('username, date_time ASC');

        $punches = $this->db->get('punch_log');
        return $punches->result_array();
    }

    function is_valid_audit_date($punchID, $newDateTime, $reportStartDate = false){
        if ($reportStartDate === false){
            $this->db->select('date_time');
            $result = $this->db->get_where('punches', array('next_punch_id' => $punchID));
            $result = $result->result();
            $previousPunchTime = isset($result[0]->date_time) ? $result[0]->date_time : '';
        }
        else {
            $previousPunchTime = $reportStartDate;
        }

        $this->db->select('next_punch_id');
        $result = $this->db->get_where('punches', array('id' => $punchID));
        $result = $result->result();
        $nextPunchID = isset($result[0]->next_punch_id) ? $result[0]->next_punch_id : '';

        if ($nextPunchID){
            $this->db->select('date_time');
            $result = $this->db->get_where('punches', array('id' => $nextPunchID));
            $result = $result->result();
            $nextPunchTime = isset($result[0]->date_time) ? $result[0]->date_time : '';
        }
        else {
            $nextPunchTime = date('Y-m-d H:i:s', NOW() + 1);
        }

        if (strtotime($newDateTime) AND strtotime($newDateTime) > strtotime($previousPunchTime) AND strtotime($newDateTime) < strtotime($nextPunchTime)){
            return true;
        }
//        else {
//        dump($_POST);
//        dump($previousPunchTime);
//        dump($newDateTime);
//        dump(date('Y-m-d H:i:s', strtotime($nextPunchTime)));
//
//        dump(number_format(strtotime($previousPunchTime)));
//        dump(number_format(strtotime($newDateTime)));
//        dump(number_format(strtotime($nextPunchTime)));
//        die();
//        }

        return false;
    }

    function sort_punches($punches){
        $output = array();
//        $b1Time = 0;
        foreach ($punches as $punch){
            extract($punch);

            $startTime = microtime(true);
            $time = gmt_to_local(strtotime($date_time), $this->Config->item('timezone'));
            $dateText = date(DATE_FORMAT, $time);
            $timeText = date(TIME_FORMAT, $time);
//            $b1Time += microtime(true) - $startTime;
            if ($duration !== NULL){
                $duration = $duration / 3600;
                $durationText = $duration;
            }
            else {
                $duration = (now() - strtotime($date_time)) / 3600;
                $durationText = $duration . ' (Now)';
            }

            $output[$user_id][$dateText][] =
            array('id' => $id,
//                      'userID' => $user_id,
                  'date' => $dateText,
                  'time' => $timeText,
                  'duration' => $duration,
                  'durationText' => $durationText,
                  'statusName' => $status_name,
                  'status' => trim($status),
                  'punchTypeID' => $punch_type_id,
                  'groupID' => $group_id,
                  'groupName' => $group_name,
                  'notes' => $notes,
                  'tags' => $tags,
                  'approved' => $approved,
                  'approved_by' => $approved_by,
                  'auditIDs' => $audit_ids,
                  'ip_address' => $ip_address);
        }
//        dump($b1Time);
//        die();
        return $output;
    }

    function process_punches($userPunches, $startDate){
//        dump($startDate);
//        dump($userPunches);
//        die();
        $enabledTotals = explode(',', $this->Config->item('report_enabledTotals'));

        $dayOTHours = $dayOTStatusHours = $weekOTHours = $weekOTStatusHours = array();

        foreach ($userPunches  as $userID => $userDates){
            $weekTime = $OTWeekTime = $dayTime = 0;
            
            $weekMinus =  7 - $this->Config->item('report_weekStartOffset');
            $startDOW = date('w', (strtotime($startDate)));
            $dayOffset = $this->Config->item('report_weekStartOffset');
            $weekOTStartDate = strtotime($startDate) + ($dayOffset - $startDOW)*24*3600;
            $weekOTStartDateText = date('m/d/y', $weekOTStartDate);
            if (strtotime($startDate) - $weekMinus*24*3600 < strtotime($startDate) - $startDOW*24*3600){
                $weekOTStartDate = strtotime($startDate) - 7*24*3600 + ($dayOffset - $startDOW)*24*3600;
            }
            $currentEnd = $weekOTStartDate + 6*24*3600;

            //            dump($punchTable);
            //            die();
            foreach ($userDates as $date => $datePunches){
                $startDOW = date('w', (strtotime($startDate)));
//                            $dayOffset = $CI->Config->item('report_weekStartOffset');
                if ($currentEnd < strtotime($date)){
                    $weekMinus =  7 - $this->Config->item('report_weekStartOffset');
                    $startDOW = date('w', (strtotime($date)));
//                                $dayOffset = $CI->Config->item('report_weekStartOffset');
                    $weekOTStartDate = strtotime($date) + ($dayOffset - $startDOW)*24*3600;
//                        $weekOTStartDate = strtotime($date) - (date('w', strtotime($date) + (7 - $CI->Config->item('report_weekStartOffset'))) * 24 * 3600) + $CI->Config->item('report_weekStartOffset') *3600*24;
                    $currentEnd = $weekOTStartDate + 6*24*3600;
                    $weekOTStartDateText = date('m/d/y', $weekOTStartDate);
                    if ($weekTime > $this->Config->item('report_OTperWeekHours')){
                        @$totalOvertime[$userID] += $weekTime - $this->Config->item('report_OTperWeekHours');
                    }
                    $weekTime = $OTWeekTime = 0;
                }

                $dayTime = $OTDayTime = 0;
                foreach ($datePunches as $userPunch){
                    extract($userPunch);

                    if (strtotime($startDate) <= strtotime($date)){
                        if (in_array($punchTypeID, $enabledTotals)){
                            @$statusHours[$userID][$statusName] += $duration;
                            @$dayStatusHours[$userID][$date][$statusName] += $duration;
                            @$weekStatusHours[$userID][$weekOTStartDateText][$statusName] += $duration;
                            @$groupStatusHours[$userID][$groupName][$statusName] += $duration;
                        }
                    }

                    if ($status){
                        $dayTime += $duration;
                        $weekTime += $duration;
                        
                        @$weekHours[$userID][$weekOTStartDateText] += $duration;
                        @$groupHours[$userID][$groupName] += $duration;

                        if ($this->Config->item('report_showOvertime') == 'week'){
                            $wasOnOvertime = false;
                            if ($OTWeekTime > $this->Config->item('report_OTperWeekHours')){
                                $wasOnOvertime = true;
                            }
                            $OTWeekTime += $duration;
                            if ($OTWeekTime > $this->Config->item('report_OTperWeekHours')){
                                $addedOT = $wasOnOvertime ? $duration : $OTWeekTime - $this->Config->item('report_OTperWeekHours');

                                @$overtimeStatusHours[$userID][$statusName] += $addedOT;
                                @$weekOTHours[$userID][$weekOTStartDateText] += $addedOT;
                                @$weekOTStatusHours[$userID][$weekOTStartDateText][$statusName] += $addedOT;
                                @$groupOTHours[$userID][$groupName] += $addedOT;
                                @$groupOTStatusHours[$userID][$groupName][$statusName] += $addedOT;
                            }
                        }
                        else if ($this->Config->item('report_showOvertime') == 'day'){
                            $wasOnOvertime = false;
                            if ($OTDayTime > $this->Config->item('report_OTperDayHours')){
                                $wasOnOvertime = true;
                            }
                            $OTDayTime += $duration;
                            if ($OTDayTime > $this->Config->item('report_OTperDayHours')){
                                $addedOT = $wasOnOvertime ? $duration : $OTDayTime - $this->Config->item('report_OTperDayHours');

                                @$overtimeStatusHours[$userID][$statusName] += $addedOT;
                                @$dayOTHours[$userID][$date] += $addedOT;
                                @$dayOTStatusHours[$userID][$date][$statusName] += $addedOT;
                                @$groupOTHours[$userID][$groupName] += $addedOT;
                                @$groupOTStatusHours[$userID][$groupName][$statusName] += $addedOT;
                            }
                        }
                    }
    //dump($punch);  if ($this->Config->item('report_showOvertime') == 'day'
                }

                if (strtotime($startDate) <= strtotime($date)){
                    @$totalHours[$userID] += $dayTime;
                }

                if ($this->Config->item('report_showOvertime') == 'day' AND $OTDayTime > $this->Config->item('report_OTperDayHours')){
                    @$totalOvertime[$userID] += $OTDayTime - $this->Config->item('report_OTperDayHours');
                }

                if ($dayTime){
                    @$dayHours[$userID][$date] += $dayTime;
                }
            }

            if ($this->Config->item('report_showOvertime') == 'week'){
                if ($OTWeekTime > $this->Config->item('report_OTperWeekHours')){
                    @$totalOvertime[$userID] += $OTWeekTime - $this->Config->item('report_OTperWeekHours');
                }
                $weekTime = $OTWeekTime = 0;
            }
         
        }
        return array(
            'totalHours' => $totalHours,
            'totalOvertime' => @$totalOvertime,

            'dayHours' => $dayHours,
            'weekHours' => $weekHours,
            'groupHours' => $groupHours,

            'statusHours' => $statusHours,
            'dayStatusHours' => $dayStatusHours,
            'weekStatusHours' => $weekStatusHours,
            'groupStatusHours' => $groupStatusHours,            
            'overtimeStatusHours' => @$overtimeStatusHours,
            'dayOTHours' => @$dayOTHours,
            'dayOTStatusHours' => @$dayOTStatusHours,
            'weekOTHours' => @$weekOTHours,
            'weekOTStatusHours' => @$weekOTStatusHours,
            'groupOTHours' => @$groupOTHours,
            'groupOTStatusHours' => @$groupOTStatusHours,
        );
    }

    function __construct(){
        
    }
}
?>
