<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Config extends Model{
    private $options;

    function item($item){
        if (isset($this->options[$item]))
            return $this->options[$item];
        else
            return false;
    }

    function update_item($item, $newValue){
        if (isset($this->options[$item])){
            $this->db->where('option', $item);
            $this->db->update('config', array('value' => $newValue));
        }
        else {
            $this->db->insert('config', array('option' => $item, 'value' => $newValue));
        }
        $this->options[$item] = $newValue;
    }

    function __construct(){
        parent::__construct();
        
        $result = $this->db->get('config');
        foreach ($result->result() as $row){
            $this->options[$row->option] = $row->value;
        }
    }
}
?>