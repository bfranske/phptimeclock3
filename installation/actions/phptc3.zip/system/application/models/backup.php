<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Backup extends Model{
    private $tables;
    private $tableColumns;

    function create_file(){
        $file = '';

        $timeStart = microtime(true);
        foreach ($this->tables as $table){
            $tableData = $this->db->get($table);
            $tableData = $tableData->result_array();
            if (count($tableData)){
                $totalTableInsertCount = 0;
                while ($totalTableInsertCount < (count($tableData))){
                    $query = "!*****START BATCH*****!|$table\n";
                    
                    $queryRowCount = 0;
                    $insertQuery = array();
                    while ($queryRowCount < 500 AND $queryRowCount < (count($tableData) - $totalTableInsertCount)){
                        $insertQuery[] = $tableData[$totalTableInsertCount + $queryRowCount ];
                        $queryRowCount++;
                    }
                    $totalTableInsertCount += $queryRowCount;

                    foreach ($insertQuery as $row){
                        $rowStr = '';
                        foreach ($row as $value){
                            $rowStr .= str_replace('|', '&csvPipe', $value) . '|';
                        }
                        $rowStr = trimString($rowStr);
                        $query .= "$rowStr\n";
                    }
                    $file .= "$query!*****END BATCH*****!\n";
                }
            }
        }

        $elapsed = number_format(microtime(true) - $timeStart, 5);

        $dateTime = date('m-d-y-H_i_s_A', gmt_to_local(now(), $this->Config->item('timezone')));
        $dir = sys_get_temp_dir();
        $companyname = str_replace(' ', '', $this->Config->item('companyName'));
        $fileName = "$dir/$companyname-backup_$dateTime.ptc3";
        write_file($fileName, $file);

        return $fileName;
    }
//
    function import_file($filename){
        $file = read_file($filename);
        $tables = array('audits', 'config', 'groups', 'punches', 'punch_tags', 'punch_types', 'tags', 'users', 'user_groups');
        if (($handle = fopen($filename, "r")) !== FALSE) {
            $this->tableColumns = array(
                'audits' => array('id', 'punch_id', 'editing_user_id', 'ip_address', 'reason_for_editing', 'edit_action', 
                                        'old_start', 'old_end', 'old_group_id', 'old_next_punch_id', 'old_punch_type_id', 'old_notes', 'old_tags',
                                        'new_start', 'new_end', 'new_group_id', 'new_next_punch_id', 'new_punch_type_id', 'new_notes', 'new_tags', 'when_changed'),
                'config' => array('id', 'option','value'),
                'groups' => array('id', 'parent_id', 'name'),
                'punches' => array('id', 'user_id', 'group_id', 'punch_type_id', 'next_punch_id', 'ip_address', 'date_time', 'notes', 'approved', 'approved_by'),
                'punch_tags' => array('id', 'punch_id', 'tag_id'),
                'punch_types' => array('id', 'status', 'name', 'color', 'order', 'enabled'),
                'tags' => array('id', 'name', 'enabled'),
                'users' => array('id', 'username', 'password', 'first_name', 'last_name', 'email', 'sys_admin', 'last_punch_id', 'enabled', 'must_change_pass', 'pin', 'custom_id'),
                'user_groups' => array('id', 'user_id', 'group_id', 'permissions')
            );

        // Insert Data
            foreach ($this->tables as $table){
                $this->db->query("TRUNCATE $table");
            }

            $fileOffset = 0;
            $query = '';
            while (($data = fgetcsv($handle, 10000, "|")) !== FALSE) {
//                dump($data);
//                continue;
                if ($data[0] == '!*****START BATCH*****!'){
                    $currentTable = $data[1];
                    $query = "INSERT INTO `$currentTable` (";
                    foreach ($this->tableColumns[$currentTable] as $column){
                        $query .= "`$column`,";
                    }
                    $query = trim($query, " ,\n").") VALUES \n";
                }
                else if ($data[0] == '!*****END BATCH*****!'){
                    $query = trim($query, " ,\n");
//                    dump($query);
                    $this->db->query($query);
                    $currentTable = false;
                    $query = '';
                    continue;
                }
                else if ($data[0]){
                    $query .= '(';
//                    dump($data);
                    foreach ($data as $value){
                        $value = $value === null ? 'NULL' : $this->db->escape($value);
                        $query .= "$value,";
                    }

                    $query = trimString($query)."),\n";
                }
            }
            return true;
        }
        else die('File error');
    }

    function get_columns($table){
        $result = $this->db->query("DESCRIBE $table");
        foreach ($result->result() as $tableCol){
            $columns[] = $tableCol->Field;
        }
        return $columns;
    }

/*
 * Depricated for security issues
 */
//    function get_tables(){
//        $result = $this->db->query('SHOW TABLES');
//        foreach ($result->result_array() as $index => $tableName){
//            foreach($tableName as $name){
//                if (substr($name, 0, strlen(TABLE_PREFIX)) == TABLE_PREFIX){
//                    $tables[] = $name;
//                }
//            }
//        }
////        remove_from_array($tables, TABLE_PREFIX.'punches');
//        remove_from_array($tables, TABLE_PREFIX.'ci_sessions');
//        remove_from_array($tables, TABLE_PREFIX.'punch_board');
//        remove_from_array($tables, TABLE_PREFIX.'punch_log');
//        return $tables;
//    }


    function __construct(){
        parent::__construct();

        $tables = array('audits', 'config', 'groups', 'punches', 'punch_tags', 'punch_types', 'tags', 'users', 'user_groups');
        foreach ($tables as $table){
            $this->tables[] = TABLE_PREFIX.$table;
        }

    }
}
?>