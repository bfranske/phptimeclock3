<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class user extends Controller{
    private $data;

    function index(){
        if (count($_POST)){
            $this->load->library('form_validation');

            $minPasswordLength = $this->Config->item('minPasswordLength');
            if ($this->input->post('newPass') OR $this->input->post('newPass2')){
              // @TODO set error message on password mismatch
                $this->form_validation->set_rules('newPass', 'Password', "required|matches[newPass2]|min_length[$minPasswordLength]");
                $this->form_validation->set_message('matches', "Password and Confirm do not match!");
            }
            $this->form_validation->set_rules('PIN', 'PIN', "numeric|callback_pin_check");

            if ($this->form_validation->run()){
                if ($this->input->post('newPass') OR $this->input->post('newPass2')){
                    $this->db->where('id', $this->session->userdata('userID'));
                    $this->db->update('users', array('password' => encrypt_password($this->input->post('newPass'))));
                }

                if ($this->input->post('PIN')){
                    $this->db->where('id', $this->session->userdata('userID'));
                    $this->db->update('users', array('pin' => encrypt_password($this->input->post('PIN'))));
                }

                $this->notices->add_notice('Information Updated');
            }
        }

        $punchTypes = $this->db->get('punch_types');
        foreach ($punchTypes->result() as $type){
            $this->data['punchColors'][$type->name] = $type->color;
        }

        $userID = $this->session->userdata('userID');

        $punches = $this->db->query("SELECT `".TABLE_PREFIX."punch_log`.`id` AS id, user_id, group_id, group_name, punch_type_id, date_time, end_time, duration, status_name, status, tags, notes, approved, approved_by
                                     FROM `".TABLE_PREFIX."punch_log` LEFT JOIN `".TABLE_PREFIX."users` on `".TABLE_PREFIX."users`.`id` = user_id WHERE user_id = $userID ORDER BY username, date_time DESC LIMIT 0, 5");

        $this->data['punches'] = array_reverse($punches->result_array(), true);

        $this->load->view('main/header', $this->data);
            $this->load->view('main/myinfo/index', $this->data);
        $this->load->view('main/footer');
    }

    function report(){
        $this->benchmark->mark('report_start');

        if (count($_POST)){
            $data['startDate'] = $this->input->post('startDate');
            $data['endDate'] = $this->input->post('endDate');

            $this->session->set_userdata('userReportsPostData', $data);
        }
        else {
            $data = $this->session->userdata('userReportsPostData');
        }
        
        $this->data['startDate'] = $data['startDate'];
        $this->data['endDate'] = $data['endDate'];

        $this->load->model('Punches');

        $punchTypes = $this->db->get('punch_types');
        foreach ($punchTypes->result() as $type){
            $this->data['punchColors'][$type->name] = $type->color;
        }

        if ($this->Config->item('report_showOvertime') == 'week'){
            $OTStartDate = date('m/d/y', (strtotime($data['startDate']) - (date('w', strtotime($data['startDate'])) * 24 * 3600)));
        }
        else {
            $OTStartDate = $data['startDate'];
        }

        $punches = $this->Punches->get_punches($this->session->userdata('userID'), 1, 'userAll', $OTStartDate, $data['endDate']);

        foreach ($punches as $punch){
            $this->data['punches'][] = $punch;
        }
        $this->data['totalPunches'] = count($punches);
//                dump($this->data['users']);
//                die();

        $this->data['statuses'] = $this->db->get('punch_types');

        $this->benchmark->mark('report_end');

        $this->load->view('main/header', $this->data);
            $this->load->view('main/myinfo/report', $this->data);
        $this->load->view('main/footer');

    }

    function pin_check($pin){
        if ($pin){
            if ($pin != $this->input->post('PIN2')){
                $this->form_validation->set_message('pin_check', "PIN and Confirm do not match!");
                return false;
            }
            if ($pin < 1000 OR $pin > 999999999999999){
                $this->form_validation->set_message('pin_check', "PIN must be 4-15 digits!");
                return false;
            }
            else return true;
        }
        else return true;
    }

    function __construct(){
        parent::__construct();

        ip_bouncer($this->input->ip_address());

        if ($this->Config->item('developerMode')){
            $this->output->enable_profiler(TRUE);
        }

        $this->load->helper('url');

        if (! $this->session->userdata('userID')){
            $this->session->set_userdata('forwardToURL', 'user');
            redirect('login');
        }
        
        $this->load->helper(array('interface_functions', 'form'));
    }
}
?>
