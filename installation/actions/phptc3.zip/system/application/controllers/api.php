<?php
/**
 * Description of api
 *
 * Version 0.1
 *
 * @author Jared
 *
 
 */
class api extends Controller{
    private $errors = array();
    private $statuses = array();
    private $requestResult = array();
    private $returnOutput;

    function get_statuses(){
        $statuses = $this->db->get_where('punch_types', array('enabled' => 1));
        foreach ($statuses->result() as $status){
            $this->requestResult[$status->id] = "$status->name>";
        }
        $this->output();
    }
    function get_users(){
        $users = $this->db->get_where('users', array('enabled' => 1, 'custom_id !=' => ''));
        foreach ($users->result() as $user){
            $this->requestResult[$user->custom_id] = array(
                'username'  => $user->username,
                'first_name'=> $user->first_name,
                'last_name' => $user->last_name,
                'email'     => $user->email,
                'sys_admin' => $user->sys_admin,
                'enabled'   => $user->enabled,
                'PINHash'   => $user->pin,
                'customID'  => $user->custom_id
            );
        }
        $this->output();
    }
    function get_punch_groups(){
        $customID = $this->input->post('customID');
        if ($customID){
            $user = $this->db->get_where('users', array('custom_id' => $customID));
            if ($user->num_rows){
                $userInfo = $user->result();
//                dump($this->Permissions->get_permission_groups($customID, 'punch'));
                $this->requestResult = $this->Permissions->get_permission_groups($userInfo[0]->id, 'punch');
            }
            else{
                $this->errors[] = 'customID not found.';
            }
        }
        else {
            $this->errors[] = 'No customID passed.';
        }
        $this->output();
    }
    function get_permissions(){
        $customID = $this->input->post('customID');

        if (! (int)$customID){
            $this->errors[] = 'No customID passed';
        }
        else {
            $user = $this->db->get_where('users', array('custom_id' => $customID));
            if ($user->num_rows){
                $userInfo = $user->result();
                $permissions = $this->Permissions->get_permissions($userInfo[0]->id);
                foreach ($permissions as $permission){
                    extract($permission);
                    $this->requestResult[$groupID] = "$permissions";
                }
            }
            else{
                $this->errors[] = 'customID not found.';
            }
        }
        $this->output();
    }
    function get_hash(){
        $customID = $this->input->post('customID');
        if ($customID){
            $userExists = $this->db->get_where('users', array('custom_id' => $customID));
            if (!$userExists->num_rows){
                $this->errors[] = 'customID not found';
            }
            else{
                $hash = $this->db->get_where('users', array('custom_id' => $customID));
                if ($hash->num_rows){
                    $hash = $hash->result();
                    $this->requestResult[] = $hash[0]->pin;
                }
                else {
                    $this->errors[] = 'customID not found.';
                }
            }
        }
        else {
            $this->errors[] = 'No customID passed';
        }
        $this->output();
    }
    function get_group_tree(){
        $groupID = $this->input->post('groupID');
        if ($groupID){
            $groupExists = $this->db->get_where('groups', array('id' => $groupID));
                if (!$groupExists->num_rows){
                    $this->errors[] = 'groupID not found.';
                }
        }
        else {
            $this->errors[] = 'No groupID passed';
        }

//        dump($this->Group->tree($groupID, 0, false));
        if (! count($this->errors)){
            $this->requestResult = $this->Group->tree($groupID, 0, false);
        }
        $this->output();
    }

    function get_punch_board(){
        $result = $this->db->get('punch_board');
        $punchBoard = $result->result_array();

        $this->requestResult = $punchBoard;

        $this->output();
    }

    function user_punch(){
        $this->load->model('User');

        $errors = array();

        $punchTypeID = $this->input->post('punchTypeID');
        $userID = 0;

        if ($this->input->post('customID')){
            $this->db->select('id, pin');
            $result = $this->db->get_where('users', array('custom_id' => $this->input->post('customID')));
            $result = $result->result();
            if (count($result)){
                if ($result[0]->pin == encrypt_password($this->input->post('PIN'), $result[0]->pin)){
                    $userID = $result[0]->id;
                }
                else {
                    $this->errors[] = 'PIN does not match.';
                    $this->output();
                    return;
                }
            }
            else {
                $this->errors[] = 'customID not found.';
                $this->output();
                return;
            }
        }
        else {
            $this->errors[] = 'No customID passed';
            $this->output();
            return;
        }
        if ($this->input->post('groupID')){
            if (! $this->Permissions->has_permission($this->input->post('groupID'), 'punch', $userID)){
                $this->errors[] = 'User does not have permission to punch into group.';
            }
            $groupID = $this->input->post('groupID');
        }
        else {
            $permissionGroups = $this->Permissions->get_permission_groups($userID, 'punch');
            if (count($permissionGroups > 1)){
                $this->errors[] = 'No group provided and user may punch into multiple groups';
            }
            else if (! count($permissionGroups)){
                $this->errors[] = 'User has no punch permissions.';
            }
            else {
                $groupID = $permissionGroups[0];
            }
        }
        if (! $punchTypeID){
            $this->errors[] = 'Status not provided.';
            $this->output();
            return;
        }
        $this->db->select('id, enabled')->from('punch_types')->where('id', $punchTypeID);
        $status = $this->db->get();
        if (! count($status->result())){
            $this->errors[] = 'Status does not exist.';
            $this->output();
            return;
        }
        $status = $status->result();
        if (! @$status[0]->enabled){
            $this->errors[] = 'Status is disabled.';
            $this->output();
            return;
        }
        if (! $this->User->status_change_check($userID, $this->input->post('statusID'), $this->input->post('groupID'), $this->input->post('tags'))){
            $this->errors[] = 'Status same as current status.';
            $this->output();
            return;
        }

        if (! count($this->errors)){
            $dateTime = $this->db->escape(date('Y-m-d H:i:s', now()));
            $ipAddress = $this->db->escape($this->input->ip_address());
            $notes = $this->db->escape(htmlspecialchars($this->input->post('notes')));
            $tags = $this->input->post('tags');

            $dbTags = array();
            foreach (explode(',', $tags) as $tag){
                $tag = trim($tag);
                if ($tag){
                    $dbTags[] = $tag;
                }
            }
            $dbTags = isset($dbTags) ? $this->db->escape(implode(',', $dbTags)) : $this->db->escape('');

            $this->db->query("CALL `".TABLE_PREFIX."punch` ($userID, $groupID, $punchTypeID, $ipAddress, $dateTime, $notes, $dbTags)");

            $this->statuses[] = 'Success';
        }

        $this->output();
    }

    function output(){
        $output = array();
        foreach ($this->errors as $error){
            $this->returnOutput['errors'][] = $error;
        }
        foreach ($this->statuses as $status){
            $this->returnOutput['statuses'][] = $status;
        }
        if ($this->requestResult){
            $this->returnOutput['result'] = $this->requestResult;
        }
        echo $this->xml->array_to_xml($this->returnOutput);
    }

    function form(){
        $this->load->view('main/header');
            $this->load->view('main/admin/api');
        $this->load->view('main/footer');
    }

    function __construct(){
        parent::__construct();

        if ($this->input->post('APIKey') != $this->Config->item('APIKey')){
            $this->errors[] =  'Invalid API Key';
            $this->output();
            return;
        }

        $this->load->helper(array('interface_functions', 'url', 'form', 'menu'));
        $this->load->library('XML');
    }
}
?>
