<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class login extends Controller {
    function index(){
//        $this->load->helper(array('interface_functions', 'url', 'form'));

        $data['loggedIn'] = $this->session->userdata('userID') ? true : false;
        if ($data['loggedIn'])
            $data['username'] = $this->session->userdata('username');
        
        $this->load->view('main/header', $data);
            $this->load->view('main/login_view', $data);
        $this->load->view('main/footer');
    }

    function do_login(){
        if ($this->input->post('userID')){
            $this->db->where('id', $this->input->post('userID'));
            $this->session->set_userdata('mobileLoginUsername', $this->input->post('userID'));
        }
        else {
            $this->db->where('username', $this->input->post('username'));
        }
        $results = $this->db->get('users');
//dump($_POST);
//die();
        if ($results->num_rows()){
            foreach ($results->result() as $row){
                if ($row->password == encrypt_password($_POST['password'], $row->password)){
                    if ($row->enabled){
                        $this->session->set_userdata('userID', $row->id);
                        $this->session->set_userdata('username', $row->username);
                        $this->session->set_userdata('firstName', $row->first_name);
                        $this->session->set_userdata('lastName', $row->last_name);
                        $this->session->set_userdata('sys_admin', $row->sys_admin);
                    }
                    else {
                        $this->notices->add_notice("User $row->username is disabled!!!", 'error', true);
                        $this->session->set_userdata('forwardToURL', 'login');
                        $userDisabled = true;
                    }
                }
                else {
                    $this->notices->add_notice('Invalid username or password', 'error', true);

                    if ($this->input->post('forwardToURL'))
                        redirect($this->input->post('forwardToURL'));
                    else
                        redirect('login');
                }
            }
        }
        else {
            $this->notices->add_notice('Username not found!', 'error', true);
        }

        if ($this->input->post('forwardToURL') AND ! isset($userDisabled)){
            $this->session->set_userdata('forwardToURL', $this->input->post('forwardToURL'));
        }

        if ($this->session->userdata('forwardToURL')){
            $forward = $this->session->userdata('forwardToURL');
            $this->session->set_userdata('forwardToURL', false);

         
            redirect($forward);
        }
        else 
            redirect();
    }

    function do_logout(){
        $forwardToURL = $this->session->userdata('forardToURL');

        $this->session->sess_destroy();

        redirect($forwardToURL);
    }


    function __construct(){
        parent::__construct();

        ip_bouncer($this->input->ip_address());

        if ($this->Config->item('developerMode')){
            $this->output->enable_profiler(TRUE);
        }

        $this->load->helper(array('interface_functions', 'url', 'form'));
    }
}
?>
