<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); 
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class admin extends Controller{
    function index(){
        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/index', $this->data);
        $this->load->view('main/footer');
    }

/*
 * Groups
 */
    function group_add(){
        if ($this->session->userdata('sys_admin')){
            $this->load->library('form_validation');

            $this->data['groups'] = $this->Group->tree();

            $this->form_validation->set_rules('parentID', 'Parent Group', 'trim|required');

            $this->load->view('main/header', $this->data);

                if ($this->session->userdata('sys_admin')){
                    if ($this->form_validation->run() != FALSE){
                        if (count($_POST)){
                            $data = array();
                            $data['parent_id'] = $this->input->post('parentID');
                            $data['name'] = $this->input->post('name');

                            $this->db->insert('groups', $data);
                            redirect('admin/group_add');
                        }
                    }
                }
                else
                    $this->notices->add_notice('You do not have permission to add groups!!!!!!!!!!!!', 'error');

                $this->load->view('main/admin/groups/add', $this->data);
            $this->load->view('main/footer');
        }
        else{
            $this->add_notice('You do not have permission to add groups', 'error', true);
            redirect();
        }
    }

    function groups_view(){
        if (ae_detect_ie()){
            $this->load->helper('browser_parser');
        }

        $this->load->library('form_validation');
        if ($this->input->post('action')){
            switch ($this->input->post('action')){
                case 'addGroup':
                    if ($this->session->userdata('sys_admin')){
                        $this->form_validation->set_rules('name', 'Name', 'required');
                        $this->form_validation->set_rules('parentID', 'Parent Group', 'required|is_natural');

                        if ($this->form_validation->run()){
                            $data['name'] = $this->input->post('name');
                            $data['parent_id'] = $this->input->post('parentID');

                            $this->db->insert('groups', $data);
                        }
                        redirect('admin/groups_view');
                    }
                    else
                        $this->notices->add_notice('You do not have permission to add groups!!!!!!!!!!!!', 'error');
                    break;
                case 'moveGroup':
                    if ($this->session->userdata('sys_admin')){
                        $this->form_validation->set_rules('parentID', 'Parent Group', 'required|is_natural');
                        $this->form_validation->set_rules('groupID', 'Group', 'required|is_natural|callback_is_everyone_check');

                        if ($this->form_validation->run()){
                            $data['id'] = $this->input->post('groupID');
                            $data['parent_id'] = $this->input->post('parentID');

                            $this->db->update('groups', array('parent_id' => $this->input->post('parentID')), "id = {$data['id']}");
                        }
                    }
                    else
                        $this->notices->add_notice('You do not have permission to move groups!!!!!!!!!!!!', 'error');
                    break;
                case 'addUser':
                    if ($this->session->userdata('sys_admin')){
                        if ($this->input->post('userID')){
                            $this->form_validation->set_rules('userID', 'User', 'required');
                            
                            if ($this->form_validation->run()){
                                $data['user_id'] = $this->input->post('userID');
                                $data['group_id'] = $this->input->post('groupID');

                                $this->db->insert('user_groups', $data);
                            }
                        }
                        else {
                            $minPasswordLength = $this->Config->item('minPasswordLength');
                            $this->form_validation->set_rules('username', 'Name', 'required|alpha_dash|callback_username_check');
                            $this->form_validation->set_rules('password', 'Password', "required|min_length[$minPasswordLength]|matches[password2]");
                            $this->form_validation->set_rules('firstName', 'First Name', 'required|alpha');
                            $this->form_validation->set_rules('lastName', 'Last Name', 'required|alpha');

                            if ($this->input->post('email')){
                                $this->form_validation->set_rules('email', 'Email', 'valid_email');
                                $this->form_validation->set_message('email', "Email address appears to be invalid (email address is not required, if not entering it, leave field blank).");
                            }
                            if ($this->input->post('customID')){
                                $this->form_validation->set_rules('customID', 'Custom ID', 'numeric|min_length[4]|max_length[15]|callback_custom_id_check');
                            }

                            $this->form_validation->set_message('matches', 'Password and confirm do not match!');

                            if ($this->form_validation->run()){
                                $data = array();
                                $username = strtolower($this->input->post('username'));
                                $data['username'] = $username;
                                $data['password'] = encrypt_password($this->input->post('password'));
                                $data['first_name'] = $this->input->post('firstName');
                                $data['last_name'] = $this->input->post('lastName');
                                $data['email'] = $this->input->post('email');
                                if ($this->input->post('sysAdmin'))
                                    $data['sys_admin'] = 1;
                                if ($this->input->post('customID')){
                                    $data['custom_id'] = $this->input->post('customID');
                                }
                                $this->db->insert('users', $data);

                                $data = array();
                                $data['user_id'] = $this->db->insert_id();
                                
                                if ($this->input->post('groupID') > 1){
                                    $data['group_id'] = $this->input->post('groupID');
                                    $this->db->insert('user_groups', $data);
                                }

                                $data['group_id'] = 1;
                                $data['permissions'] = 'punch';
                                $this->db->insert('user_groups', $data);

                                $this->notices->add_notice("The user `$username` has been added!");
                            }
                        }
                    }
                    else
                        $this->notices->add_notice('You do not have permission to add users!!!!!!!!!!!!', 'error');
                    break;
                case 'deleteGroup':
                    if ($this->session->userdata('sys_admin')){
                        $this->form_validation->set_rules('groupID', 'Group', 'callback_is_everyone_check|callback_group_has_subgroups_check|callback_group_has_users_check');
                        if ($this->form_validation->run()){
                            $this->db->delete('groups', array('id' => $this->input->post('groupID')));
                        }
                    }
                    else
                        $this->notices->add_notice('You do not have permission to delete groups!!!!!!!!!!!!', 'error');
                    break;
                case 'renameGroup':
                    if ($this->session->userdata('sys_admin')){
                        $this->form_validation->set_rules('groupID', 'Group', 'callback_is_everyone_check');
                        $this->form_validation->set_rules('newName', 'New Group Name', 'req');
                        if ($this->form_validation->run()){
                            $this->db->where('id', $this->input->post('groupID'));
                            $this->db->update('groups', array('name' => $this->input->post('newName')));
                        }
                    }
                    else
                        $this->notices->add_notice('You do not have permission to delete groups!!!!!!!!!!!!', 'error');
                    break;
                case 'toggleDisabled':
                    $this->session->set_userdata('showDisabled', $this->input->post('showDisabled'));
                    break;
                case 'toggleDisabledGroups':
                    $this->session->set_userdata('showDisabledGroups', $this->input->post('showDisabledGroups'));
                    break;
                case 'toggleGroupEnabled':
                    $this->Group->update_enabled_status($this->input->post('groupID'), $this->input->post('newStatus'));
                    break;
                default:
                    break;
            }
        }

        $this->data['tree'] = $this->Group->tree(0, -1, true);
        $this->data['groups'] = $this->db->get('groups');

        $this->db->where('enabled', ! $this->session->userdata('showDisabled'));
        $this->db->order_by('username', 'asc');
        $this->data['users'] = $this->db->get('users');

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/groups/view', $this->data);
        $this->load->view('main/footer');
    }

    function group_view(){
        if ($this->session->userdata('sys_admin')){
            $this->load->model('Group');

            $this->data['groupUsers'] = $this->Group->get_users($this->input->get('id'));

            $this->load->view('main/header', $this->data);
                $this->load->view('main/admin/groups/view_users', $this->data);
            $this->load->view('main/footer');
        }
        else{
            $this->add_notice('You do not have permission to view groups', 'error', true);
            redirect();
        }
    }


/*
 * Users
 */
    function user_add(){
        $this->load->library('form_validation');

        $this->load->model('Group');

        $this->data['users'] = $this->db->get('users');
        $this->data['tree'] = $this->Group->tree();

        $minPasswordLength = $this->Config->item('minPasswordLenth');
        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[4]|callback_username_check');
        $this->form_validation->set_rules('password', 'Password', "required|min_length[$minPasswordLength]|matches[password2]");
        $this->form_validation->set_rules('password2', 'Confirm Password', 'required|min_length[5]');
        $this->form_validation->set_rules('firstName', 'First Name', 'trim|required');
        $this->form_validation->set_rules('lastName', 'Last Name', 'trim|required|min_length[4]');
        $this->form_validation->set_rules('groupID', 'Group', 'trim|required|is_natural_no_zero');
        if ($this->input->post('email')){
            $this->form_validation->set_rules('email', 'Email', 'valid_email');
            $this->form_validation->set_message('email', "Email address appears to be invalid (email address is not required, if not entering it, leave field blank).");
        }

         $this->form_validation->set_message('matches', 'Password and confirm do not match!');

         $this->load->view('main/header', $this->data);

            if ($this->session->userdata('sys_admin')){
                if ($this->form_validation->run() != FALSE){
                    $this->data['status'] = 'Success';
                    if (count($_POST)){
                        $info = array();
                        $info['username'] = $this->input->post('username');
                        $info['password'] = $this->input->post('password');
                        $info['first_name'] = $this->input->post('firstName');
                        $info['last_name'] = $this->input->post('lastName');

                        $this->load->model('User');
                        $this->User->add_user($info);
                    }
                }
            }
            else
                $this->notices->add_notice('You do not have permission to add users!!!!!!!!!!!!', 'error');
            
            $this->load->view('main/admin/users/add', $this->data);
        $this->load->view('main/footer');
    }

    function users_view(){
        if ($this->session->userdata('sys_admin')){
            $this->data['users'] = $this->db->get('users');

            $this->load->view('main/header', $this->data);
                $this->load->view('main/admin/users/view', $this->data);
            $this->load->view('main/footer');
        }
        else{
            $this->add_notice('You do not have permission to view users', 'error', true);
            redirect();
        }
    }

    function user_view(){
        if ($this->session->userdata('sys_admin')){
            $this->load->model('User');

            if (count($_POST)){
                $this->load->library('form_validation');

                $this->form_validation->set_rules('username', 'Name', 'required|alpha_dash');
                $result = $this->db->get_where('users', array('id' => $this->input->post('userID')));
                $result = $result->result();
                if ($result[0]->username != $this->input->post('username')){
                    $this->form_validation->set_rules('username', 'Name', 'callback_username_check');
                }
                $this->form_validation->set_rules('firstName', 'First Name', 'trim|required');
                $this->form_validation->set_rules('lastName', 'Last Name', 'trim|required');

                if ($this->input->post('newPass') OR $this->input->post('newPass2')){
                    $minPasswordLength = $this->Config->item('minPasswordLenth');
                    $this->form_validation->set_rules('newPass', 'Password', "required|min_length[$minPasswordLength]|matches[newPass2]");

                    $this->form_validation->set_message('matches', "Password and Confirm Password do not match!!!!!");
                }
                $this->form_validation->set_rules('PIN', 'PIN', "numeric|callback_pin_check");

                if ($this->input->post('PIN')){
                    $this->db->where('id', $this->session->userdata('userID'));
                    $this->db->update('users', array('pin' => $this->input->post('PIN')));
                }

                if ($this->input->post('email')){
                    $this->form_validation->set_rules('email', 'Email', 'valid_email');
                }
                if ($this->input->post('customID')){
                    $this->form_validation->set_rules('customID', 'Custom ID', 'numeric|min_length[4]|max_length[15]|callback_custom_id_check');
                }
                if ($this->form_validation->run()){
                    $data['username'] = $this->input->post('username');
                    $data['first_name'] = $this->input->post('firstName');
                    if (trim($this->input->post('lastName'))){
                        $data['last_name'] = $this->input->post('lastName');
                    }
                    if ($this->input->post('newPass') AND $this->input->post('newPass2')){
                        $data['password'] = encrypt_password($this->input->post('newPass'));
                    }

                    if ($this->input->post('email')){
                        $data['email'] = $this->input->post('email');
                    }
                    if ($this->input->post('customID')){
                        $data['custom_id'] = $this->input->post('customID');
                    }
                    $data['enabled'] = $this->input->post('enabled') ? 1 : 0;

                    $this->db->where('id', $this->input->post('userID'));
                    $this->db->update('users', $data);

                    $this->notices->add_notice('User info updated!');
                }
            }

            $this->data['userInfo'] = $this->User->get_info($this->input->get('id'));

            $this->data['groups'] = $this->User->get_group_permissions($this->input->get('id'));

            $this->load->view('main/header', $this->data);
                $this->load->view('main/admin/users/view_details', $this->data);
            $this->load->view('main/footer');
        }
        else{
            $this->add_notice('You do not have permission to view users', 'error', true);
            redirect();
        }
    }

    function group_report(){
        
    }

    function run_audit_report(){
        extract($this->session->userdata('reportsPostData'));
        
        $startDate = date('Y-m-d', strtotime($startDate));
        $endDate = date('Y-m-d', strtotime($endDate));

        $groups = $this->Group->get_children($reportsGroupID);

        $this->db->select('audits.id, punch_id, editing_users.username AS editing_user, punching_users.username AS punching_user,
                           punches.ip_address AS punching_ip, audits.ip_address AS audit_ip, reason_for_editing, edit_action, when_changed,
                           old_start, old_groups.name AS old_group, old_punch_types.name AS old_punch_type, old_notes, old_tags,
                           new_start, new_groups.name AS new_group, new_punch_types.name AS new_punch_type, new_notes, new_tags');
        $this->db->order_by('audits.id', 'asc');
        $this->db->from('audits');
        $this->db->join('groups AS old_groups', 'audits.old_group_id = old_groups.id', 'left');
        $this->db->join('groups AS new_groups', 'audits.new_group_id = new_groups.id', 'left');
        $this->db->join('users AS editing_users', 'audits.editing_user_id = editing_users.id', 'left');
        $this->db->join('punch_types AS old_punch_types', 'old_punch_type_id = old_punch_types.id', 'left');
        $this->db->join('punch_types AS new_punch_types', 'new_punch_type_id = new_punch_types.id', 'left');
        $this->db->join('punches', 'punch_id = punches.id');
        $this->db->join('users AS punching_users', 'punches.user_id = punching_users.id');
//        $this->db->where_in('old_group_id', $groups);
        $this->db->where_in('new_group_id', $groups);
        $this->db->where_in('punching_users.id', $selectedUsers);
        $this->db->where_in('edit_action', $auditTypes);
        $this->db->where_in('edit_action', $auditTypes);
        $this->db->where("when_changed >= '$startDate'");
        $this->db->where("when_changed <= '$endDate'");
        $result = $this->db->get();
        $this->data['audits'] = $result->result();

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/reports/audit', $this->data);
        $this->load->view('main/footer', $this->data);
    }

    function run_reports(){
        if ($this->input->post('reportType') == 'Audit Report'){
            $data['selectedUsers'] = $this->input->post('selectedUsers');
            $data['reportsGroupID'] = $this->input->post('reportsGroupID');
            $data['reportType'] = $this->input->post('reportType');
            $data['startDate'] = $this->input->post('startDate');
            $data['endDate'] = $this->input->post('endDate');
            $data['groupScope'] = $this->input->post('groupScope');
            $data['tags'] = $this->input->post('selectedTags');
            $data['auditTypes'] = $this->input->post('auditTypes');
            $this->session->set_userdata('reportsPostData', $data);

            redirect('admin/run_audit_report');
        }

        $this->benchmark->mark('report_start');

        $data = array();
//dump($this->Group->get_upline(32768));
//die();
        if (count($_POST)){
            $data['selectedUsers'] = $this->input->post('selectedUsers');
            $data['reportsGroupID'] = $this->input->post('reportsGroupID');
            $data['reportType'] = $this->input->post('reportType');
            $data['startDate'] = $this->input->post('startDate');
            $data['endDate'] = $this->input->post('endDate');
            $data['groupScope'] = $this->input->post('groupScope');
            $data['tags'] = $this->input->post('selectedTags');
            $this->session->set_userdata('reportsPostData', $data);
        }
        else if (count($_GET)){
            $data['selectedUsers'] = (isset($_GET['selectedUsers']) ? sanitize($_GET['selectedUsers']) : '');
            $data['reportsGroupID'] = (isset($_GET['reportsGroupID']) ? sanitize($_GET['reportsGroupID']) : '');
            $data['reportType'] = (isset($_GET['reportType']) ? sanitize($_GET['reportType']) : '');
            $data['startDate'] = (isset($_GET['startDate']) ? sanitize($_GET['startDate']) : '');
            $data['endDate'] = (isset($_GET['endDate']) ? sanitize($_GET['endDate']) : '');
            $data['groupScope'] = (isset($_GET['groupScope']) ? sanitize($_GET['groupScope']) : '');
            $data['tags'] = (isset($_GET['tags']) ? sanitize($_GET['tags']) : '');

            $this->session->set_userdata('reportsPostData', $data);
        }
        else {
            $data = $this->session->userdata('reportsPostData');
        }

        if ($this->Permissions->has_permission($data['reportsGroupID'], 'runReports') OR $this->Permissions->has_permission($data['reportsGroupID'], 'editTime')){
            $this->data['groupScope'] = $data['groupScope'];
            $this->data['reportsGroupID'] = $data['reportsGroupID'];
            $this->data['startDate'] = $data['startDate'];
            $this->data['endDate'] = $data['endDate'];
            $this->data['tags'] = $data['tags'];

            $this->load->model('Punches');
            $this->load->model('User');

            $punchTypes = $this->db->get('punch_types');
            foreach ($punchTypes->result() as $type){
                $this->data['punchColors'][$type->name] = $type->color;
            }

            if ($data['groupScope'] == 'all'){
                $punchesGroups = $this->Group->get_children();
            }
            else if ($data['groupScope'] == 'children') {
                if ($data['reportsGroupID']){
                    $punchesGroups = $this->Group->get_children($data['reportsGroupID']);
                }
            }
            else{
                $punchesGroups = array($data['reportsGroupID']);
            }

            if ($data['reportType'] != 'Group Overview'){
                $this->data['statuses'] = $this->db->get('punch_types');
            }

            if ($data['reportType'] == 'Group Overview'){
                $this->load->model('group');

                $data['selectedUsers'] = array();
                $groups = $this->group->get_children($data['reportsGroupID']);

//                dump($groups);
                foreach ($groups as $group){
                    $result = $this->group->get_users($group);
                    foreach ($result->result() as $row){
                        $data['selectedUsers'][] = $row->user_id;
                    }
                }
                $data['selectedUsers'] = array_unique($data['selectedUsers']);
                sort($data['selectedUsers']);
                
                $statuses = $this->db->get('punch_types');
                foreach ($statuses->result() as $status){
                    $this->data['statuses'][$status->id] = array('id' => $status->id, 'name' => $status->name, 'color' => $status->color);
                }

                $users = array();
                foreach ($groups as $group){
                     $this->data['groupUsers'][$group] = $this->group->get_users($group, true);
                }

                $this->data['tree'] = $this->Group->tree($data['reportsGroupID'], 0, false);
                
            }
            else if (isset($data['selectedUsers']) AND is_array($data['selectedUsers'])){
                $this->load->model('group');

                $groups = $this->group->get_children($data['reportsGroupID']);
                foreach ($groups as $group){
                     $this->data['groupUsers'][$group] = $this->group->get_users($group, true);
                }
            }
            else{
                $this->notices->add_notice('No users selected!', 'error', true);
                redirect('admin/groups_view');
            }
            if (isset($data['selectedUsers'])){
                foreach ($data['selectedUsers'] as $user){
                    foreach ($punchesGroups as $index => $group){
                        if (! $this->Permissions->has_permission($group, 'runReports')){
                            $this->data['cantViewPunches'] = true;
                            break;
                        }
                    }
                }
            }

            if ($this->Config->item('report_showOvertime') == 'week'){
                $OTStartDate = date('m/d/y', (strtotime($data['startDate']) - (date('w', strtotime($data['startDate'])) * 24 * 3600)));
            }
            else {
                $OTStartDate = $data['startDate'];
            }
//dump($data['selectedUsers']);
//dump($data['reportsGroupID']);
//dump($data['groupScope']);
//dump($OTStartDate);
//dump($data['endDate']);
//dump($data['tags']);
//dump($punchesGroups);
            $this->data['punches'] = $this->Punches->get_punches($data['selectedUsers'], $data['reportsGroupID'], $data['groupScope'], $OTStartDate, $data['endDate'], $data['tags'], $punchesGroups);

            foreach ($this->data['punches'] as $punch){
                $this->data['users'][$punch['user_id']][] = $punch;
            }
            $this->data['totalPunches'] = count($this->data['punches']);

            $this->data['showEditButtons'] = $data['tags'] ? false : true;

            $result = $this->db->get_where('groups', 'id = ' . $data['reportsGroupID']);
            $result = $result->result();
            $this->data['groupName'] = $result[0]->name;
        }
        $this->data['groupScope'] = $data['groupScope'];

        $this->benchmark->mark('report_end');
       
        $reportsPostData = $this->session->userdata('reportsPostData');
        $sessionReportType = $reportsPostData['reportType'];
        $type = (isset($_POST['reportType']) ? $this->input->post('reportType') : $sessionReportType);
        $this->session->set_userdata('reportsType', $type);

        $result = $this->db->get('users');
        foreach ($result->result() as $user){
            $this->data['userInfo'][$user->id] =
                    array('username' => $user->username,
                          'fullname' => "$user->first_name $user->last_name");
        }

        if ($type == 'CSV Report' OR $type == 'Excel Report'){
            $this->load->library('SpreadsheetReport');
            $this->load->helper('download');

            if (count($this->data['punches'])){
                $this->spreadsheetreport->set_info($this->data);
                switch($type){
                    case 'CSV Report':
                        $this->spreadsheetreport->output_csv();
                        break;
                    case 'Excel Report':
                        $this->spreadsheetreport->output_excel();
                        break;
                    default:
                        break;
                }
    //
                die();
            }else {
                $this->notices->add_notice('No punches found for search criteria!', 'error', true);
                redirect('admin/groups_view');
            }
        }

        $this->load->view('main/header', $this->data);
            if ($type == 'Summary Report')
                $this->load->view('main/admin/reports/summary', $this->data);
            else if ($type == 'Detail Report')
                $this->load->view('main/admin/reports/regular', $this->data);
            else if ($type == 'Group Overview')
                $this->load->view('main/admin/reports/group', $this->data);
        $this->load->view('main/footer');
    }

    function approve_time_do(){
        if ($this->Permissions->has_permission($this->input->post('reportsGroupID'), 'editTime')){
            if (is_array(explode(',', $this->input->post('ids'))) AND is_array(explode(',', $this->input->post('groups')))){
                $groups = explode(',', $this->input->post('groups'));
                foreach (explode(',', $this->input->post('ids')) as $index => $id){
                    $punch = $this->db->get_where('punches', array('id' => $id));
                    foreach ($punch->result() as $punchInfo){
                        if ($this->Permissions->has_permission($groups[$index], 'editTime') AND ((!$punchInfo->approved_by) OR $punchInfo->approved_by == $this->session->userdata('userID'))){
                            $this->db->where('id', $id);
                            $this->db->update('punches', array('approved' => 1, 'approved_by' => $this->session->userdata('userID')));
                        }
                        else{
                            $notAllPermissions = true;
                        }
                    }
                }

                $notice = 'All punches on report approved.';
                if (isset($notAllPermissions) AND $notAllPermissions)
                    $notice .= ' You do not have permission to approve some punches, these have not been approved';
                $this->notices->add_notice($notice, 'notice', true);
            }

            redirect('admin/run_reports');
        }
        else {
            $this->notices->add_notice('You do not have permission to approve time for group selected for report!!', 'error', true);
            redirect('admin/run_reports');
        }
    }

    function import(){
        if ($this->session->userdata('sys_admin')){
            $this->data['error'] = '';
            $this->load->view('main/header', $this->data);
                $this->load->view('main/admin/import/index', $this->data);
            $this->load->view('main/footer');
        }
        else{
            $this->notices->add_notice('You do not have permission to import!', 'error');
            redirect();
        }
    }
    function import_from_db_do(){
        if ($this->session->userdata('sys_admin')){
            $failure = true;
            $errors = array();
            $dbCredentials['dbHost'] = $this->input->post('dbHost');
            $dbCredentials['dbName'] = $this->input->post('dbName');
            $dbCredentials['dbUser'] = $this->input->post('dbUser');
            $dbCredentials['dbPass'] = $this->input->post('dbPass');

            $this->data['dbCredentials'] = $dbCredentials;

            $tablePrefix = $this->input->post('tablePrefix');
            $result = PDO_query('SHOW TABLES', false, false, $dbCredentials);

            if (is_array($result)){
                foreach ($result as $row){
                    if (in_array($tablePrefix.'actions', $row) OR in_array($tablePrefix.'employees', $row) OR in_array($tablePrefix.'config', $row)){
                        $failure = false;
                    }
                }
            }

            if (! $failure){
                $this->load->model('Import');
                $this->Import->import_from_db($dbCredentials, $tablePrefix);
            }

            if ($failure) {
                $this->data['errors'][] = 'Connected to database, but it doesn\'t appear to be a valid PHPTimeclock database';
                $this->load->view('main/header', $this->data);
                    $this->load->view('main/admin/import/from_database', $this->data);
                $this->load->view('main/footer');
            }
            else {
                 unset($_SESSION['tablePrefix']);
                 $this->load->view('main/header', $this->data);
                    $this->load->view('main/admin/import/success', $this->data);
                $this->load->view('main/footer');
            }
        }
        else{
            $this->notices->add_notice('You do not have permission to import!', 'error');
            redirect();
        }
    }

    function import_from_file_do(){
        if ($this->session->userdata('sys_admin')){
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'zip|sql';
            $config['max_size']	= '2000';

            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload()) {
                $error = array('error' => $this->upload->display_errors());
                $this->load->view('main/header', $this->data);
                    $this->load->view('main/admin/menu');
                    $this->load->view('main/admin/import/index', $error);
                $this->load->view('main/footer');
            }
            else {
                $data = array('upload_data' => $this->upload->data());

                 $this->load->view('main/header', $this->data);
                    $this->load->view('main/admin/import/success', $data);
                $this->load->view('main/footer');
            }
        }
        else{
            $this->notices->add_notice('You do not have permission to import!', 'error');
            redirect();
        }
    }
//local_to_gmt(strtotime($startDate), $CI->Config->item('timezone'));
    function edit_time_do(){
        if ($this->Permissions->has_permission($this->input->post('groupID'), 'editTime')){
            $this->db->select('user_id');
            $result = $this->db->get_where('punches', array('id' => $this->input->post('punchID')));
            $result = $result->result();
            $userID = $result[0]->user_id;
            if (! $this->Permissions->has_permission($this->input->post('groupID'), 'editTime')){
                $this->notices->add_notice('You do not have permission edit time in that group!', 'alert', true);
            }
            else if (! $this->Permissions->has_permission($this->input->post('groupID'), 'punch', $userID)){
                $this->notices->add_notice('Punch may not be changed to that group because the user does not have punch permission for it!', 'alert', true);
            }
            else {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('date', 'Punch Date', 'trim|required');
                $this->form_validation->set_rules('time', 'Punch Time', 'trim|required');

                if ($this->Config->item('requireEditReason')){
                    $this->form_validation->set_rules('reasonForEditing', 'Reason For Deleting', 'trim|required');
                }

                if ($this->form_validation->run()){
                    $this->load->model('Punches');

                    $punchID = (int)$this->input->post('punchID');
                    $nextPunchID = (int)$this->input->post('nextPunchID');
                    $editingUserID = (int)$this->session->userdata('userID');
                    $ipAddress = $this->db->escape($this->input->ip_address());
                    $reasonForEditing = $this->db->escape($this->input->post('reasonForEditing'));
                    $date = $this->input->post('date') . ' ' . $this->input->post('time');
                    $newStart = date('Y-m-d H:i:s', local_to_gmt(strtotime($date), $this->Config->item('timezone')));
                    $newGroupID = (int)$this->input->post('groupID');
                    $newPunchTypeID = (int)$this->input->post('status');
                    $newNotes = $this->db->escape($this->input->post('notes'));
                    $newTags = $this->db->escape($this->input->post('tags'));

                    $whenChanged = $this->db->escape(date('Y-m-d H:i:s', now()));

                    if ($this->Punches->is_valid_audit_date($punchID, $newStart)){
                        $newStart = $this->db->escape($newStart);
                        $this->db->query("CALL `".TABLE_PREFIX."edit_time`($punchID, $editingUserID, $ipAddress, $reasonForEditing, $newStart, $newGroupID, $newPunchTypeID, $newNotes, $newTags, $whenChanged)");
                    }
                    else {
                        $this->notices->add_notice('New punch time must fall between previous time, and time of the next punch (may be invalid date/time...)!', 'alert', true);
                    }
                }
                else {
                    $this->notices->add_notice('Date, Time, and Reason for Editing are required!', 'alert', true);
                }
            }
            redirect('admin/run_reports#' . $this->input->post('anchorString'));
        }
        else
            $this->notices->add_notice('You do not have permission add time to that group!', 'alert', true);
    }

    function delete_time_do(){
        if ($this->Permissions->has_permission($this->input->post('groupID'), 'editTime')){
            $this->load->library('form_validation');

            $this->form_validation->set_rules('punchID', 'Punch ID', 'trim|required');

            if ($this->Config->item('requireEditReason')){
                $this->form_validation->set_rules('punchID', 'Reason For Deleting', 'trim|required');
                $this->form_validation->set_message('punchID', "Form Error!");
            }

            if ($this->form_validation->run()){
                if ($this->Permissions->has_permission($this->input->post('groupID'), 'editTime')){
                    $punchID = (int)$this->input->post('punchID');
                    $editingUserID = (int)$this->session->userdata('userID');
                    $ipAddress = $this->db->escape($this->input->ip_address());
                    $reasonForDeleting = $this->db->escape($this->input->post('reasonForDeleting'));

                    $whenChanged = $this->db->escape(date('Y-m-d H:i:s', now()));

                    $this->db->query("CALL `".TABLE_PREFIX."delete_time`($punchID, $editingUserID, $ipAddress, $reasonForDeleting, $whenChanged)");
                }
                else
                    $this->notices->add_notice('You do not have permission delete time from that group!', 'alert');
            }
            else {
                $this->notices->add_notice('There has been a form error!', 'alert', true);
            }

            redirect('admin/run_reports#' . $this->input->post('anchorString'));
        }
        else
            $this->notices->add_notice('You do not have permission delete time in that group!', 'alert', true);
    }

    function add_time_do(){
        if ($this->Permissions->has_permission($this->input->post('groupID'), 'editTime')){
            $this->load->model('Punches');

            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('date', 'Punch Date', 'trim|required');
            $this->form_validation->set_rules('time', 'Punch Time', 'trim|required');

            if ($this->Config->item('requireEditReason')){
                $this->form_validation->set_rules('reasonForAdding', 'Reason For Adding', 'trim|required');
                $this->form_validation->set_message('reasonForAdding', "Reason For Adding is required!");
            }

            if ($this->form_validation->run()){
              // Check if time is valid
                $punchID = (int)$this->input->post('punchID');
                $previousPunchID = (int)$this->input->post('previousPunchID');
                $date = $this->input->post('date') . ' ' . $this->input->post('time');
                $newStart = date('Y-m-d H:i:s', local_to_gmt(strtotime($date), $this->Config->item('timezone')));

                $reportStartDate = $this->input->post('reportStartDate') ? $this->input->post('reportStartDate') : false;
                $nextPunchTime = date('Y-m-d H:i:s', local_to_gmt(strtotime($this->input->post('nextPunchTime')), $this->Config->item('timezone')));
                $nextPunchID = (int)$this->input->post('nextPunchID');
                if (! $nextPunchID)
                    $nextPunchID = 'NULL';
//dump($nextPunchID);
//die();
                if ($this->Punches->is_valid_audit_date($punchID, $newStart, $reportStartDate)){
                    $userID = (int)$this->input->post('userID');
                    $editingUserID = (int)$this->session->userdata('userID');
                    $ipAddress = $this->db->escape($this->input->ip_address());
                    $reasonForAdding = $this->db->escape($this->input->post('reasonForAdding'));
                    
                    $newGroupID = (int)$this->input->post('groupID');
                    $newPunchTypeID = (int)$this->input->post('status');
                    
                    $newNotes = $this->db->escape($this->input->post('notes'));
                    $newTags = $this->db->escape($this->input->post('tags'));

                    $dbNewStart = $this->db->escape($newStart);

                    $whenChanged = $this->db->escape(date('Y-m-d H:i:s', now()));

                    $this->db->query("CALL `".TABLE_PREFIX."add_time`($userID, $previousPunchID, $editingUserID, $ipAddress, $reasonForAdding, $dbNewStart, $newGroupID, $newPunchTypeID, $newNotes, $newTags, $nextPunchID, $whenChanged)");

                }
                else {
                    $this->notices->add_notice('New punch must fall between the previous and next punches (may be invalid date/time...)!', 'alert', true);
                }
            }
            else {
                $this->notices->add_notice('Date, Time, and Reason for Adding are required!', 'alert', true);
            }
        }
        else
            $this->notices->add_notice('You do not have permission add time to that group!', 'alert', true);

        redirect('admin/run_reports#' . $this->input->post('anchorString'));
    }

/*
 * Backup
 */
    function backup(){
        if ($this->session->userdata('sys_admin')){
            $this->load->helper('file');
            $this->load->helper('download');
            $this->load->library('zip');
            $this->load->model('Backup');
            
            if (count($_POST)){
                $option = (isset($_POST['option']) ? sanitize($_POST['option']) : '');
                $action = (isset($_POST['action']) ? sanitize($_POST['action']) : '');
                if ($action == 'backup'){
                    if ($option == 'regular'){
                        $filename = $this->Backup->create_file();

                        $zipName = str_replace('.ptc3', '.zip', $filename);

                        // Clean data in cache if exists
                        @ob_end_clean();
                        
                        $this->zip->read_file($filename);
                        $this->zip->download(trim(str_replace(sys_get_temp_dir(), '', $zipName), '/'));
                    }
                }
                else if ($action == 'restore'){
                    $config['upload_path'] = sys_get_temp_dir();
                    $config['allowed_types'] = 'zip|ptc3';
                    $config['max_size']	= '2048';
                    $config['remove_spaces'] = false;
                    $config['overwrite'] = true;

                    $this->load->library('upload', $config);

                    if ($this->upload->do_upload()){
                        
                        $uploadInfo = $this->upload->data();
                        if (strpos($uploadInfo['file_type'], 'zip') !== false){
                            require_once(BASEPATH.'application/libraries/PclZip.php');
                            $archive = new PclZip($uploadInfo['full_path']);

                            $success = true;
                            if (! ($v_result_list = $archive->extract(PCLZIP_OPT_PATH, sys_get_temp_dir()))) {
                                $success = false;
                                $this->notices->add_notice("Error : ".$archive->errorInfo(true), 'error');
                            }
                            $starT = microtime(true);
                            if (! $this->Backup->import_file(sys_get_temp_dir().'/'.str_replace('.zip', '.ptc3', $uploadInfo['file_name']))){
                                $success = false;
                                $this->notices->add_notice('The uploaded zip file did not contain properly named backup file', 'error');
                            }
                            $elapsed = number_format(microtime(true) - $starT, 2);
                            
                            if ($success){
                                $this->notices->add_notice('<h3>Successfully restored backup!</h3>', 'success');
                                $this->notices->add_notice("Restore took $elapsed seconds", 'success');
                            }


                            unlink(sys_get_temp_dir().'/'.$uploadInfo['file_name']);
                            unlink(sys_get_temp_dir().'/'.str_replace('.zip', '.ptc3', $uploadInfo['file_name']));
                        }
                        else {
                            $this->notices->add_notice('Invalid file!', 'error');
                        }
                    }
                    else {
                        $this->notices->add_notice($this->upload->display_errors(), 'error');
                    }

                    $this->load->view('main/header', $this->data);
                        $this->load->view('main/admin/backup', $this->data);
                    $this->load->view('main/footer');
                }
            }
            else {
                $this->load->view('main/header', $this->data);
                    $this->load->view('main/admin/backup', $this->data);
                $this->load->view('main/footer');
            }
        }
        else{
            $this->notices->add_notice('You do not have permission backup!', 'error');
            redirect();
        }
    }

/*
 * Reset API Key
 */
     function reset_api_key(){
         $this->Config->update_item('APIKey', createRandomKey(20));
         redirect('admin/config');
     }
 
/*
 * Config - General
 */

    function config(){
        if ($this->session->userdata('sys_admin')){
            $this->load->library('form_validation');

        // Update other config stuff
            if (count($_POST)){
                switch($this->input->post('section')){
                    case 'general':
                        $this->session->set_userdata('activeAccordian', '');
                        $this->form_validation->set_rules('minPasswordLength', 'Minimum Password Legnth', 'trim|required|numeric|callback_password_length_check');
                        if ($this->input->post('restrictIPAddresses')){
                            $this->form_validation->set_rules('allowedIPAddresses', 'Allowed IP Addresses', 'trim|callback_ip_addresses_check');
                        }
                        if ($this->form_validation->run()){
                            $this->Config->update_item('timezone', $this->input->post('timezone'));
                            $this->Config->update_item('companyName', $this->input->post('companyName'));

                            $this->Config->update_item('language', $this->input->post('language'));

                        // This is here to simplify updates to users of the hosted service
                            if (strpos(BASE_URL, 'https://hosted.phptimeclock.com') === false){
                                // SSL
                                    if ($this->input->post('useSSL')){
                                        $this->Config->update_item('base_url', str_replace('http:', 'https:', $this->Config->item('base_url')));
                                    }
                                    else {
                                        $this->Config->update_item('base_url', str_replace('https:', 'http:', $this->Config->item('base_url')));
                                    }
                                    $this->Config->update_item('useSSL', $this->input->post('useSSL'));
                               // End SSL
                            }

                            $this->Config->update_item('selectGroupDisplay', $this->input->post('selectGroupDisplay'));
                            $this->Config->update_item('selectStatusStyle', $this->input->post('selectStatusStyle'));
                            
                            $this->Config->update_item('useTags', $this->input->post('useTags'));
                            $this->Config->update_item('requireEditReason', $this->input->post('requireEditReason'));

                            $this->Config->update_item('timeFormat', $this->input->post('timeFormat'));
                            $this->Config->update_item('dateFormat', $this->input->post('dateFormat'));

                            $this->Config->update_item('minPasswordLength', $this->input->post('minPasswordLength'));

                            if ($this->input->post('restrictIPAddresses')){
                                $this->Config->update_item('restrictIPAddresses', 'Yes ' . $this->input->post('allowedIPAddresses'));
                            }
                            else {
                                $this->Config->update_item('restrictIPAddresses', 'No');
                            }
                            $this->notices->add_notice('General Config Updated!', 'notice');
                        }

                        break;
                    case 'punchBoard':
                        $this->session->set_userdata('activeAccordian', 'punchBoard');
                        $this->form_validation->set_rules('punchBoardDays', 'Punch Board Days', 'trim|required|callback_punch_board_days_range_check');

                        if ($this->form_validation->run()){
                            $this->Config->update_item('lastNameView', $this->input->post('lastNameView'));
                            $this->Config->update_item('punchBoardGroup', $this->input->post('punchBoardGroup'));
                            $this->Config->update_item('punchBoardNotes', $this->input->post('punchBoardNotes'));
                            $this->Config->update_item('userIdentifier_punch', $this->input->post('userIdentifier_punch'));
                            $this->Config->update_item('userIdentifier_board', $this->input->post('userIdentifier_board'));
                            $this->Config->update_item('punchBoardDays', (int)$this->input->post('punchBoardDays'));

                            $this->notices->add_notice('Punch Board Config Updated!', 'notice');
                        }

                        break;
                    case 'other':
                            $this->session->set_userdata('activeAccordian', 'other');
//                        if ($this->form_validation->run()){
                            $this->Config->update_item('getPunchImages', $this->input->post('getPunchImages'));
                            $this->Config->update_item('developerMode', $this->input->post('developerMode'));
                            // API Config
                            $this->Config->update_item('apiEnabled', $this->input->post('apiEnabled'));
                            if ($this->input->post('apiEnabled') AND !strlen($this->Config->item('APIKey'))){
                                $this->Config->update_item('APIKey', createRandomKey(20));
                            }
                            $this->notices->add_notice('Other Config Updated!', 'notice');
//                        }
                        break;
                    default:
                        $this->notices->add_notice('Form error!', 'error');
                        break;
                }
            }
        }
        else{
            $this->notices->add_notice('You do not have permission view config!', 'error');
            redirect();
        }

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/config/index', $this->data);
        $this->load->view('main/footer');

        $this->session->set_userdata('activeAccordian', '');
    }

/*
 * Config - Punch Types
 */

    function punch_types(){
        if ($this->session->userdata('sys_admin')){
            $this->load->library('form_validation');

            if (count($_POST)){
            // Status Reordering
                if ($this->input->post('StatusUp')){
                    $statusID = $this->input->post('StatusUp');
                    $this->db->order_by('order');
                    $punch_types = $this->db->get('punch_types');

                    foreach ($punch_types->result() as $status){
                        if ($status->id == $statusID){
                            $this->db->where('id', $prevID);
                            $this->db->update('punch_types', array('order' => $status->order));

                            $this->db->where('id', $status->id);
                            $this->db->update('punch_types', array('order' => $prevOrder));
                            break;
                        }
                        else {
                            $prevID = $status->id;
                            $prevOrder = $status->order;
                        }
                    }
                }
                else if ($this->input->post('StatusDown')){
                    $statusID = $this->input->post('StatusDown');
                    $this->db->order_by('order');
                    $punch_types = $this->db->get('punch_types');
                    $punch_types = $punch_types->result();

                    foreach ($punch_types as $index => $status){
                        if ($status->id == $statusID){
                            $this->db->where('id', $statusID);
                            $this->db->update('punch_types', array('order' => $punch_types[$index + 1]->order));

                            $this->db->where('id', $punch_types[$index + 1]->id);
                            $this->db->update('punch_types', array('order' => $status->order));
                            break;
                        }
                    }
                }
            // Delete Selected
                else if ($this->input->post('DeleteSelected')){
                    foreach ($this->input->post('selectedStatuses') as $status){
                        $result = $this->db->get_where('punches', array('punch_type_id' => $status));
                        if ($result->num_rows()){
                            $inUseStatus = true;
                        }else {
                            $this->db->delete('punch_types', array('id' => $status));
                        }
                    }
                    if (isset($inUseStatus)){
                        $this->notices->add_notice('One or more statuses may not be deleted because there are existing punches with those status names.
                                                    You may disable these statuses if you wish', 'error');
                    }
                }
            // Update Statuses
                else if ($this->input->post('UpdateStatuses')){
                    $ids = explode(',', $this->input->post('ids'));
                    $data = array();
                    $names = $this->input->post('names');
                    $statuses = $this->input->post('statuses');
                    $colors = $this->input->post('colors');
                    $enabledStatuses = $this->input->post('enabledStatuses');
                    foreach ($ids as $id){
                        $data['name'] = $names[$id];
                        $data['status'] = $statuses[$id];
                        $data['color'] = $colors[$id];
                        $data['enabled'] = isset($enabledStatuses[$id]) AND $enabledStatuses[$id] ? 1 : 0;

                        $this->db->where('id', $id);
                        $this->db->update('punch_types', $data);
                    }
                }
            // Add New Status
                else if ($this->input->post('AddNewStatus')){
                    $this->form_validation->set_rules('newName', 'Name', 'trim|required|callback_status_name_check');
                    $this->form_validation->set_rules('newStatus', 'Status', 'required|callback');
                    $this->form_validation->set_rules('newColor', 'Color', 'trim|required|callback_status_color_check');
                    if ($this->form_validation->run()){
                        $data['name'] = $this->input->post('newName');
                        $data['status'] = $this->input->post('newStatus');
                        $data['color'] = $this->input->post('newColor');
                        $this->db->insert('punch_types', $data);

                        $this->db->where('id', $this->db->insert_id());
                        $this->db->update('punch_types', array('order' => $this->db->insert_id()));

                        $enabledDurations = explode(',', $this->Config->item('report_enabledDurations'));
                        $enabledTotals = explode(',',$this->Config->item('report_enabledTotals'));

                        $enabledDurations[] = $this->db->insert_id();
                        $enabledTotals[] = $this->db->insert_id();

                        $this->Config->update_item('report_enabledDurations', implode(',',$enabledDurations));
                        $this->Config->update_item('report_enabledTotals', implode(',',$enabledTotals));
                    }
                }
                $this->notices->add_notice('Config Updated!', 'notice');
            }
        }
        else{
            $this->notices->add_notice('You do not have permission view config!', 'error');
            redirect();
        }

        $this->db->order_by('order');
        $this->data['punchTypes'] = $this->db->get('punch_types');

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/config/punch_types', $this->data);
        $this->load->view('main/footer');
    }

/*
 * Config - Report
 */

    function reports(){
        if ($this->session->userdata('sys_admin')){
            $this->load->library('form_validation');

            if (count($_POST)){
                $this->form_validation->set_rules('roundingDigits', 'Rounding Digits', 'trim|required|numeric|callback_rounding_digits_check');

                if ($this->form_validation->run()){
                    $this->Config->update_item('report_roundingDigits', $this->input->post('roundingDigits'));
                    $this->Config->update_item('report_durationFormat', $this->input->post('durationFormat'));
                    $this->Config->update_item('report_showGroup', $this->input->post('showGroup'));
                    $this->Config->update_item('report_showGroupUpline', $this->input->post('showGroupUpline'));
                    $this->Config->update_item('report_showGroupBreakdown', $this->input->post('showGroupBreakdown'));
                    $this->Config->update_item('report_showTags', $this->input->post('showTags'));
                    $this->Config->update_item('report_showDuration', $this->input->post('showDuration'));

                    $enabledDurations = $this->input->post('enabledDurations') ? implode(',', $this->input->post('enabledDurations')) : '';
                    $enabledTotals = $this->input->post('enabledTotals') ? implode(',', $this->input->post('enabledTotals')) : '';
                    $this->Config->update_item('report_enabledDurations', $enabledDurations);
                    $this->Config->update_item('report_enabledTotals', $enabledTotals);

                    $this->Config->update_item('report_showOvertime', $this->input->post('showOvertime'));
                    $this->Config->update_item('report_weekStartOffset', $this->input->post('weekStartOffset'));
                    $this->Config->update_item('report_OTperWeekHours', $this->input->post('OTperWeekHours'));
                    $this->Config->update_item('report_OTperDayHours', $this->input->post('OTperDayHours'));
                    $this->Config->update_item('report_paginateEmployees', $this->input->post('paginateEmployees'));

                    $this->notices->add_notice('Config Updated!', 'notice');
                }
            }
        }
        else{
            $this->notices->add_notice('You do not have permission view config!', 'error', true);
            redirect();
        }

        $this->db->order_by('order');
        $this->data['punchTypes'] = $this->db->get('punch_types');

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/config/reports', $this->data);
        $this->load->view('main/footer');
    }
/*
 * Tags
 */
    function tags(){
        if ($this->session->userdata('sys_admin')){
            $this->load->library('form_validation');

            if (count($_POST)){
            // Update Tags
                if ($this->input->post('UpdateTags')){
                    if (is_array($this->input->post('names')) AND count($this->input->post('names'))){
                        $enabled = $this->input->post('enabled');
                        foreach ($this->input->post('names') as $index => $name){
                            $this->db->where('id', $index);
                            $this->db->update('tags', array('name' => $name, 'enabled' => isset($enabled[$index])));
                        }

                        foreach ($this->input->post('nameCombines') as $id => $newID){
                            if ($newID){
                                $this->db->where('tag_id', $id);
                                $this->db->update('punch_tags', array('tag_id' => $newID));

                                $this->db->delete('tags', array('id' => $id));
                            }
                        }
                    }
                }
            }
        }
        else{
            $this->notices->add_notice('You do not have permission view tags!', 'error');
            redirect();
        }

        

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/tags', $this->data);
        $this->load->view('main/footer');
    }

/*
 * Group Cameras
 */
    function group_cameras(){
        if (is_array($this->input->post('groupCameras'))){
            foreach ($this->input->post('groupCameras') as $groupID => $url){
                if ($url){
                    $size=@getimagesize($url);
                    switch(@$size["mime"]){
                        case "image/jpeg":
                        case "image/gif":
                        case "image/png":
                        case "image/bmp":
                      break;
                      default:
                            $this->notices->add_notice("The following URL is invalid (or is an image that is not jpg, gif, png, or bmp)!<br /> $url <br />", 'error');
                            break 2;
                    }
                }
                $this->db->set('camera_url', $url);
                $this->db->where('id', $groupID);
                $this->db->update('groups');
            }
        }

        $this->data['cameraURLs'] = $this->Group->get_camera_urls();

        $this->data['tree'] = $this->Group->tree(1, 0, false);

        $this->load->view('main/header', $this->data);
            $this->load->view('main/admin/group_cameras', $this->data);
        $this->load->view('main/footer');
    }
/*
 * Ajax
 */
    function ajax_tags(){
        $this->output->enable_profiler(false);

        $this->session->set_userdata('tagsEnabledFilter', $this->input->post('enabledFilter'));

        if ($this->session->userdata('tagsEnabledFilter') == 'Enabled')
            $this->db->where('enabled', 1);
        else if ($this->session->userdata('tagsEnabledFilter') == 'Disabled')
            $this->db->where('enabled', 0);
        $this->data['tags'] = $this->db->get('tags');
        $this->data['tags'] = $this->data['tags']->result();

        $this->load->view('main/admin/ajax/tags', $this->data);
    }

    function ajax_user_select(){
        $this->output->enable_profiler(false);
        
        $this->db->order_by('username', 'asc');
        $this->db->where("users.enabled = 1");
        $this->data['users'] = $this->db->get('users');
        $this->db->from('users');
        $this->db->join('user_groups', 'users.id = user_groups.user_id');
        $this->db->join('groups', 'user_groups.group_id = groups.id');
        $this->db->where("groups.id = " . $this->input->post('groupID'));
        $this->db->order_by('name', 'asc');
        $result = $this->db->get();

        $this->data['noShowUsers'] = array();
        if ($result->num_rows()){
            foreach($result->result() as $row){
                $this->data['noShowUsers'][] = $row->user_id;
            }
        }

        render_select_user($this->data['users'], 'userID', true, $this->data['noShowUsers']);
    }

    function ajax_show_users(){
        $this->output->enable_profiler(false);
        
        $this->db->order_by('username', 'asc');
        $this->db->from('users');
        $this->db->join('user_groups', 'users.id = user_groups.user_id');
        $this->db->join('groups', 'user_groups.group_id = groups.id');
        $this->db->where("groups.id = " . $this->input->post('groupID'));
        $this->db->order_by('name', 'asc');

        $this->db->where('users.enabled', ! $this->session->userdata('showDisabled'));
        
        $this->data['users'] = $this->db->get();

        $this->data['groupID'] = $this->input->post('groupID');
        $this->data['sysAdmin'] = $this->session->userdata('sys_admin');

        $this->load->model('Group');
        $this->data['tree'] = $this->Group->tree();

        $this->load->view('main/admin/ajax/manage_users', $this->data);
    }

    function ajax_run_reports(){
        $this->output->enable_profiler(false);

        $this->db->order_by('username', 'asc');
        $this->db->from('users');
        $this->db->join('user_groups', 'users.id = user_groups.user_id');
        $this->db->join('groups', 'user_groups.group_id = groups.id');
        $this->db->where("groups.id = " . $this->input->post('reportsGroupID'));
        $this->db->where('users.enabled', ! $this->session->userdata('showDisabled'));
        
        $this->db->order_by('name', 'asc');
        $this->data['users'] = $this->db->get();

        $this->data['reportsGroupID'] = $this->input->post('reportsGroupID');

        $this->data['statuses'] = $this->db->get_where('punch_types', array('enabled' => 1));

        $this->load->view('main/admin/ajax/run_reports', $this->data);
    }

     function ajax_audit_report_options(){
        $this->output->enable_profiler(false);

        $this->load->view('main/admin/ajax/report_audit_options', $this->data);
     }

    function ajax_report_options(){
        $this->output->enable_profiler(false);

        $groups = $this->Group->get_children($this->input->post('reportsGroupID'));

        $this->db->select('tags.id, tags.name');
        $this->db->distinct();
        $this->db->from('tags');
        $this->db->join('punch_tags', 'tags.id = tag_id', 'left');
        $this->db->join('punches', 'punches.id = punch_id', 'left');
        $this->db->where_in("group_id ", $groups);

        $this->data['tags'] = $this->db->get();

        $this->data['reportsGroupID'] = $this->input->post('reportsGroupID');

        $this->load->view('main/admin/ajax/report_options', $this->data);
    }

    function ajax_audit(){
        $this->output->enable_profiler(false);

        $this->db->select('audits.id, punch_id, editing_users.username, audits.ip_address AS editing_ip,
                           punches.ip_address AS punching_ip, reason_for_editing, edit_action, when_changed,
                           old_start, old_groups.name AS old_group, old_punch_types.name AS old_punch_type, old_notes, old_tags,
                           new_start, new_groups.name AS new_group, new_punch_types.name AS new_punch_type, new_notes, new_tags');
        $this->db->order_by('audits.id', 'asc');
        $this->db->from('audits');
        $this->db->join('groups AS old_groups', 'audits.old_group_id = old_groups.id', 'left');
        $this->db->join('groups AS new_groups', 'audits.new_group_id = new_groups.id', 'left');
        $this->db->join('users AS editing_users', 'audits.editing_user_id = editing_users.id', 'left');
        $this->db->join('punch_types AS old_punch_types', 'old_punch_type_id = old_punch_types.id', 'left');
        $this->db->join('punch_types AS new_punch_types', 'new_punch_type_id = new_punch_types.id', 'left');
        $this->db->join('punches', 'punch_id = punches.id');
        $this->db->join('users AS punching_users', 'punches.user_id = punching_users.id');
        
        $this->db->where("punch_id = " .$this->input->post('punchID'));

        $this->data['punches'] = $this->db->get();

        $this->load->view('main/admin/ajax/audit', $this->data);
    }

/*
 * Actions
 */
    function users_manage_do(){
        if ($this->session->userdata('sys_admin')){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('groupID', 'Group', 'required');

            if ($this->input->post('RemoveFromGroup')){
                if ($this->form_validation->run()){
                    foreach ($this->input->post('selectedUsers') as $user){
                        $this->db->delete('user_groups', array('user_id' => $user, 'group_id' => $this->input->post('groupID')));
                    }
                }
            }
            else if ($this->input->post('Disable')){
                if ($this->form_validation->run()){
                    if (in_array($this->session->userdata('userID'), $this->input->post('selectedUsers'))){
                        $this->notices->add_notice('You may not disable your own account!', 'error', true);
                    }
                    else {
                        foreach ($this->input->post('selectedUsers') as $user){
                            $this->db->or_where('id', $user);
                        }
                        $this->db->update('users', array('enabled' => 0));
                    }
                }
            }
            else if ($this->input->post('Enable')){
                if ($this->form_validation->run()){
                    foreach ($this->input->post('selectedUsers') as $user){
                        $this->db->or_where('id', $user);
                    }
                    $this->db->update('users', array('enabled' => 1));
                }
            }
            else if ($this->input->post('Move') OR $this->input->post('Add')){
                if ($this->form_validation->run()){
                    foreach ($this->input->post('selectedUsers') as $user){
                        if ($this->user_in_group_check($user, $this->input->post('newGroupID'))){
                            if ($this->input->post('groupID') == 1){
                                if ($this->form_validation->run()){
                                    $data['user_id'] = $user;
                                    $data['group_id'] = $this->input->post('newGroupID');

                                    $this->db->insert('user_groups', $data);
                                }
                            }
                            else {
                                $this->db->update('user_groups', array('group_id' => $this->input->post('newGroupID')), array('user_id' => $user, 'group_id' => $this->input->post('groupID')));
                            }
                        }
                    }
                }
            }
            else if ($this->input->post('SavePermissions')){
                foreach (explode(',', $this->input->post('userIDs')) as $userID){
                    $permissions[$userID] = $this->input->post("permissions_$userID");
                }

                foreach ($permissions as $userID => $permissions){
                    $existingPermssions = $this->db->get_where('user_groups', "user_id = $userID AND group_id = " . $this->input->post('groupID'));
                    $userPermissions = array();
                        foreach ($permissions as $permission => $value){
                            if ($permission == 'editTime' AND $value == 1){
                                $permissions['runReports'] = 1;
                            }
                        }
                        foreach ($permissions as $permission => $value){
                            if ($value == 1){
                                $userPermissions[] = $permission;
                            }
                            else if ($value == 0){
                                $userPermissions[] = "not_$permission";
                            }
                        }

                        $data['permissions'] = implode('|', $userPermissions);

                    if ($existingPermssions->num_rows()){
                        $existingPermssions = $existingPermssions->result();
                        $this->db->where('id', $existingPermssions[0]->id);
                        $this->db->update('user_groups', $data);
                    }
                    else {
                        $data['user_id'] = $userID;
                        $data['group_id'] = $this->input->post('groupID');
                        $this->db->insert('user_groups', $data);
                    }
                }

                $sysAdmins = $this->input->post('sysAdmin');
                foreach (explode(',', $this->input->post('userIDs')) as $userID){
                    $checked = isset($sysAdmins[$userID]) AND $sysAdmins[$userID] == 1 ? 1 : 0;
                    $this->db->where("id = $userID");
                    $this->db->update('users', array('sys_admin' => $checked));
                }
            }
        }
        else
            $this->notices->add_notice('You do not have permission to manage users!!!!!!!!!!!!', 'error', true);

        redirect('admin/groups_view');
    }


/*
 * Form Validation Callbacks
 */
    function username_check($username){
        $this->load->model('User');
        if ($this->User->username_exists($username)){
            $this->form_validation->set_message('username_check', "The username `$username` already exists!");
            return false;
        }
        else if (strpos($username, ' ') !== false){
            $this->form_validation->set_message('username_check', "Username may not contain spaces!");
            return false;
        }
        else return true;
    }

    function group_has_users_check($id){
        $this->db->where('group_id', $this->input->post('groupID'));
        $hasUsers = $this->db->count_all_results('user_groups');

        if ($hasUsers)
            return false;
        else
            return true;
    }

    function group_has_subgroups_check($id){
        $this->db->where('parent_id', $this->input->post('groupID'));
        $hasGroups = $this->db->count_all_results('groups');

        if ($hasGroups){
            $this->form_validation->set_message('group_has_subgroups_check', "The group may not be deleted because it has subgroups!");
            return false;
        }
        else return true;
    }

    function user_in_group_check($userID, $groupID){
        $this->db->where(array('user_id' => $userID, 'group_id' => $groupID));
        $hasGroups = $this->db->count_all_results('user_groups');

        if ($hasGroups){
            $this->session->set_flashdata('notices', $this->session->flashdata('notices') . "User can not be added/moved to group because the group already contains that user!<br />");
            return false;
        }
        else return true;
    }
    function is_everyone_check($id){
        if ($id == 1){
            $this->form_validation->set_message('is_everyone_check', "You may not change the parent of, rename or delete the everyone group!");
            return false;
        }
        else return true;
    }

    function status_name_check($name){
        $result = $this->db->get_where('punch_types', array('name' => $name));
        if ($result->num_rows()){
            $this->form_validation->set_message('status_name_check', "There is already a status with the name `$name`!");
            return false;
        }
        else return true;
    }
    function status_color_check($status){
        if (trim($status, 'abcdefABCDEF0123456789') != ''){
            $this->form_validation->set_message('status_color_check', "The status color may only contain hexadecimal characthers (A-F, 0-9)!");
            return false;
        }
        else if (strlen($status) != 3 AND strlen($status) != 6){
            $this->form_validation->set_message('status_color_check', "The status color must be 3 or 6 characters!");
            return false;
        }
        else return true;
    }

    function punch_board_days_range_check($days){
        if ($days < 0 OR $days > 31){
            $this->form_validation->set_message('punch_board_days_range_check', "Punch board days must be a number from 0-31!");
            return false;
        }
        else return true;
    }

    function password_length_check($length){
        if ($length < 2 OR $length > 16){
            $this->form_validation->set_message('password_length_check', "Minimum password length must be 2-16 characters");
            return false;
        }
        else return true;
    }

    function ip_addresses_check($ipAddressess){
        if (! $ipAddressess){
            $this->form_validation->set_message('ip_addresses_check', 'Allowed IP Addresses is required if `Restrict IP Addresses` is set to Yes!!!');
            return false;
        }

        $ipAddressess = explode(',', $ipAddressess);
        
        foreach ($ipAddressess as $index => $address){
            if (!$this->input->valid_ip($address)){
                $this->form_validation->set_message('ip_addresses_check', "One or more IP Addresses appears to be invalid");
                return false;
            }
        }
        return true;
    }

    function rounding_digits_check($digits){
        if ((int)$digits < 1 OR (int)$digits > 4){
            $this->form_validation->set_message('rounding_digits_check', "Rounding digits must be 1, 2, 3, or 4!");
                return false;
        }
        return true;
    }

    /*
     * Other
     */
    function is_sys_admin_check(){
        array(
            '1' => array('viewTime'),
            '2' => array('modifyTime', 'viewTime'),
            '3' => array('approveTime', 'viewTime')
        );
    }

    function custom_id_check($customID){
        if (! $customID) return true;

        $result = $this->db->get_where('users', array('id' => $this->input->post('userID')));
        $result = $result->result();
        if (count($result)){
            $currentCustomID = $result[0]->custom_id;
        }
        else {
            $currentCustomID = null;
        }

        if ($currentCustomID != $customID){
            $result = $this->db->get_where('users', array('custom_id' => $customID));
            if (count($result->result())){
                $this->form_validation->set_message('custom_id_check', "The custom ID `$customID` already exists!");
                return false;
            }
        }
        
        return true;
    }

    function pin_check($pin){
        if ($pin){
            if ($pin != $this->input->post('PIN2')){
                $this->form_validation->set_message('pin_check', "PIN and Confirm do not match!");
                return false;
            }
            if ($pin < 1000 OR $pin > 999999999999999){
                $this->form_validation->set_message('pin_check', "PIN must be 4-15 digits!");
                return false;
            }
            else return true;
        }
        else return true;
    }

    function __construct(){
        parent::__construct();

        if (is_dir(FCPATH.'/installation')){
            rrmdir(FCPATH.'/installation');
        }

        ip_bouncer($this->input->ip_address());

        if ($this->Config->item('developerMode')){
            $this->output->enable_profiler(TRUE);
        }

        $this->load->helper(array('interface_functions', 'url', 'form', 'menu'));

        $this->data['loggedIn'] = $this->session->userdata('userID') ? true : false;
        if ($this->session->userdata('userID') AND $this->Permissions->has_any_admin_permission()){
            $this->data['username'] = $this->session->userdata('username');
        }
        else if (strpos(current_URL(), 'ajax') !== false){
            echo '<span style="color:red; font-weight:bold;">Please Log In</span>';
            die();
        }
        else redirect();
    }
}
?>