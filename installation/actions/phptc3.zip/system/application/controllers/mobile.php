<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of mobile
 *
 * @author Jared
 */
class mobile extends Controller{
    private $data;

    function login(){
        if ($this->session->userdata('userID')){
            redirect('mobile');
        }

        $users = $this->db->query('SELECT DISTINCT user_id, username, first_name, last_name
                                    FROM  `'.TABLE_PREFIX.'user_groups`
                                    LEFT JOIN `'.TABLE_PREFIX.'users` ON user_id = `'.TABLE_PREFIX.'users`.`id`
                                    WHERE LOCATE(  "punch", permissions )
                                        AND NOT LOCATE(  "not_punch", permissions)
                                        AND enabled = 1
                                    ORDER BY username ASC');
        foreach ($users->result() as $user){
            $this->data['users'][$user->user_id] = $this->Config->item('userIdentifier_punch') == 'username' ? $user->username : "$user->first_name $user->last_name";
        }
        
        $this->load->view('mobile/header', $this->data);
            $this->load->view('mobile/login_view', $this->data);
        $this->load->view('mobile/footer');
    }

    function punch_board(){
        $startDate = date('Y-m-d H:i:s', strtotime(date(DATE_FORMAT, now())) - ($this->Config->item('punchBoardDays') * 3600*24));
        $this->db->where("date_time >= '$startDate'");
        $this->data['punchBoard'] = $this->db->get('punch_board');

        $punchTypes = $this->db->get('punch_types');
        foreach ($punchTypes->result() as $type){
            $this->data['punchColors'][$type->id] = $type->color;
        }

        $this->data['isMobile'] = 1;

        $this->load->view('mobile/header', $this->data);
            $this->load->view('main/ajax/punch_board', $this->data);
        $this->load->view('mobile/footer', $this->data);
    }

    function index(){
        $this->session->set_userdata('forwardToURL', curPageURL());
        
        $this->data['loggedIn'] = $this->session->userdata('userID') ? true : false;
        if ($this->data['loggedIn']){
            $this->data['username'] = $this->session->userdata('username');
        }
        else{
            redirect('mobile/login');
        }
        $this->load->library('form_validation');

        $this->load->model('Group');

        if (count($_POST)){
            if ($this->session->userdata('userID') AND 0){

            }
            else {
                if (! $this->session->userdata('userID')){
                    $this->form_validation->set_rules('userID', 'Username', 'trim|required|numeric');
                    $this->form_validation->set_rules('password', 'password', 'required|callback_password_check');
                }
                $this->form_validation->set_rules('status', 'Status', 'required|callback_status_change_check');
                $this->form_validation->set_rules('groupID', 'Group', 'required|callback_punch_permission_check');

                $userID = $this->input->post('userID');
            }

            if ($this->form_validation->run() != FALSE){
                $user_id = $this->session->userdata('userID') ? $this->session->userdata('userID') : (int)$this->input->post('userID');
                $group_id = (int)$this->input->post('groupID');
                if ((int)$this->input->post('status')){
                    $punch_type_id = (int)$this->input->post('status');

                    $this->db->select('name')->from('punch_types')->where('id', $punch_type_id);
                    $statusName = $this->db->get();
                    $statusName = $statusName->result();
                    $statusName = $statusName[0]->name;
                }
                else {
                    $statusName = $this->input->post('status');
                    
                    $this->db->select('id')->from('punch_types')->where('name', $this->input->post('status'));
                    $punch_type_id = $this->db->get();
                    $punch_type_id = $punch_type_id->result();
                    $punch_type_id = $punch_type_id[0]->id;
                }
                $ip_address = $this->db->escape($this->input->ip_address());
                $date_time = $this->db->escape(date('Y-m-d H:i:s', $this->time->time));
                $notes = $this->db->escape(htmlspecialchars($this->input->post('notes')));

                $tags = $this->input->post('tags');

                foreach (explode(',', $tags) as $tag){
                    $tag = trim($tag);
                    if ($tag){
                        $dbTags[] = $tag;
                    }
                }
                $dbTags = isset($dbTags) ? $this->db->escape(implode(',', $dbTags)) : $this->db->escape('');

                $this->db->query("CALL `".TABLE_PREFIX."punch` ($user_id, $group_id, $punch_type_id, $ip_address, $date_time, $notes, $dbTags)");

                if ($this->Config->item('getPunchImages') AND $this->Group->get_camera_url($group_id)){
                    $result = $this->db->get_where('punch_board', array('user_id' => $user_id));
                    $result = $result->result();
                    $lastPunchID = $result[0]->id;

                    if (1){
                        get_punch_image($lastPunchID, $this->Group->get_camera_url($group_id));
                    }

                    $folderName = date('M_Y', now());
                    $imageDir = FCPATH."/punch_images/$folderName/";
                    $imageName = $lastPunchID;
                    $origFilename = "$imageDir/$imageName.jpg";

                    $this->load->library('ImageResize');
                    $imageResize = new ImageResize($origFilename);

                    $imageResize->maxWidth  = 1024;
                    $imageResize->maxHeight = 768;
                    $imageResize->convert_image('jpg');

                    list($width, $height) = getimagesize($origFilename);
                    if ($width > 320 OR $height > 240){
                        $imageResize->newFilename = "$imageName".'_thumb';
                        $imageResize->imageDir  = $imageDir;
                        $imageResize->maxWidth  = 320;
                        $imageResize->maxHeight = 240;
                        $imageResize->containerW = 0;
                        $imageResize->containerH = 0;
    //                    $imageResize->pad = false;

                        $imageResize->resize_image();
                    }
                }

                $this->notices->add_notice($this->lang->line('Punch Successful')." ($statusName)", 'notice', false, true);
            }
        }
        $result = $this->db->get_where('punch_board', array('user_id' => $this->session->userdata('userID')));
        $result = $result->result_array();
        $this->data['lastUserPunch'] = @$result[0];

        $this->db->order_by('order');
        $this->data['statuses'] = $this->db->get_where('punch_types', array('enabled' => 1));

        $punchTypes = $this->db->get('punch_types');
        foreach ($punchTypes->result() as $type){
            $this->data['punchColors'][$type->id] = $type->color;
        }

        $this->data['permissionGroups'] = array();
        $this->data['tree'] = $this->Group->tree(0, 0, true);

        $this->data['permissionGroups'] = $this->Permissions->get_permission_groups($this->session->userdata('userID'), 'punch');

        $this->session->set_userdata('forardToURL', curPageURL());

        $this->load->view('mobile/header', $this->data);
            $this->load->view('mobile/dashboard_view', $this->data);
        $this->load->view('mobile/footer');
    }

    function status_change_check($newStatus){
        $this->load->model('User');

        $userID = $this->session->userdata('userID') ? $this->session->userdata('userID') : (int)$this->input->post('userID');

        if ($this->User->status_change_check($userID, $newStatus, $this->input->post('groupID'), $this->input->post('tags'))){
            return true;
        }
        else{
            $this->form_validation->set_message('status_change_check', $this->lang->line('Status same'));
            return false;
        }
    }

    function __construct(){
        parent::__construct();

        ip_bouncer($this->input->ip_address());

        $this->load->helper(array('interface_functions', 'url', 'form'));
        
        if ($this->session->userdata('userID') AND $this->Permissions->has_any_admin_permission()){
            $this->data['username'] = $this->session->userdata('username');
        }

        $this->lang->load('dashboard', 'en_US');
        $this->lang->load('general', 'en_US');
    }
}
?>
