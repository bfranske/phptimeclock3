<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
class Notices {
    /*
     * Adds notice to be displayed by user
     *
     * Param $notice - Notice to add
     * Param $type - CSS class for notice (notice (default), success, error)
     * Param $addToSession - Whether or not to add to session, only needed (and a must) pages that will not be displaying anything ("actions")
     *                       The notice is displayed on the next page load
     */
    function add_notice($notice, $type = 'notice', $addToSession = false, $fade = false){
        $array = $this->CI->session->userdata('notices');
        
        if ($fade){
            $string = "<span class='$type'>$notice</span>";
            $array[] = $string;
            $this->notices_fade[] = $string;
        }
        else if ($type == 'alert'){
            $array[] = $notice;
            $this->notices_alert[] = $notice;
            }
        else {
            $string = "<span class='$type'>$notice</span>";
            $array[] = $string;
            $this->notices[] = $string;
        }

        if ($addToSession)
            if ($fade)
                $this->CI->session->set_userdata('notices_fade', $array);
            else if ($type == 'alert')
                $this->CI->session->set_userdata('notices_alert', $array);
            else 
                $this->CI->session->set_userdata('notices', $array);
    }

    function __construct(){
        $this->CI = get_instance();
        $this->notices = $this->CI->session->userdata('notices');
        $this->notices_fade = $this->CI->session->userdata('notices_fade');
        $this->notices_alert = $this->CI->session->userdata('notices_alert');

        $this->CI->session->unset_userdata('notices');
        $this->CI->session->unset_userdata('notices_alert');
        $this->CI->session->unset_userdata('notices_fade');
    }
}
?>