<?php
/**
 * Description of ImageResize
 *
 * @author Jared
 */
class ImageResize {
    public $imageDir;
    public $newFilename;
    public $maxWidth;      public $maxHeight;
    public $containerW;    public $containerH;
    public $thumbWidth;    public $thumbHeight;
    public $fillColor = array('Red' => 255, 'Green' => 255, 'Blue' => 255);

    public $origFilename;
    public $sourceFile;
    public $redirectURL;
    public $cron;

    public $outputFormat = 'jpg';
    public $pad = true;

    public $ready = true;

    function add_error($error){
        add_error($error);
        echo $error;
        $this->ready = false;
    }

    function set_image_sourcefile($sourceFilename){
        $this->origFilename = basename($sourceFilename);
        $this->imageDir = str_replace($this->origFilename, '', $sourceFilename);
        $this->origFullFilename = $sourceFilename;
    }

    function get_image_type($filename = ''){
        $filename = $filename ? $filename : $this->origFullFilename;

        $size=getimagesize($filename);
        switch($size["mime"]){
            case "image/jpeg":
                $imageType = 'jpg'; //jpeg file
            break;
            case "image/gif":
                $imageType = 'gif'; //gif file
          break;
          case "image/png":
              $imageType = 'png'; //png file
          break;
        default:
            $imageType=false;
        break;
        }
        return $imageType;
    }
    function convert_image($targetFormat){
        $imageType = $this->get_image_type($this->origFullFilename);
        switch ($imageType){
            case 'jpg':
            case 'gif':
            case 'png':
            case 'bmp':
                break;
            default:
                $this->add_error('Only JPEG, GIF, PNG, and BMP files are accepted<br />' . $this->origFilename);
                return false;
                break;
        }

        list($width, $height) = getimagesize($this->origFullFilename) or die();
        if ($targetFormat != $imageType OR $width > $this->maxWidth OR $height > $this->maxHeight){
            $targetFilename = substr_replace(substr($this->origFullFilename, strrpos($this->origFullFilename, '.') + 1), $targetFormat, strrpos($this->origFullFilename, '.') + 1);
            $filename = $this->origFullFilename;
            $this->newFilename = basename(str_replace(substr($filename, strrpos($filename, '.')), "", $filename));
            $this->resize_image();
//            imagejpeg($image, $targetFilename);
        }
        else{
//            dump($width);
//            dump($height);
//            die();
        }
    }
    /*
 * Resizes an image
 * @Param $imageDir directory where image should be saved, relateive to installation directory
 * @Param $newFilename The new filename
 * @Param $origFilename Original filename, leave default if you want it to come from $_FILES['uploadedImage']['name']
 * @Param $sourceFile Original filename, leave default if you want it to come from $_FILES['uploadedImage']['name']
 */
// @TODO make image resize class
function resize_image(/*$imageDir, $newFilename, $maxWidth = 240, $maxHeight = 180, $containerW = false, $containerH = false, $thumbWidth = false, $thumbHeight = false, $cron = false*/){
  // Check for things not set
    if ($this->imageDir == '')    $this->add_error('Image Dir not set for ImageResize Object');
    if ($this->newFilename == '') $this->add_error('New filename not set for ImageResize Object');
    if ($this->maxWidth == '')    $this->add_error('Max Width not set for ImageResize Object');
    if ($this->maxHeight == '')   $this->add_error('Max Height not set for ImageResize Object');
    if ($this->outputFormat != 'jpg' AND $this->outputFormat != 'jpeg' AND $this->outputFormat != 'png' AND $this->outputFormat != 'gif')
        $this->add_error('Only JPG, PNG, and GIF formats are supported for output'.$this->outputFormat);

    if (! $this->ready){
        die('<br />Not Ready');
        return false;
    }
//dump($this);
//die();
    $imageType = $this->get_image_type($this->origFullFilename);

    $targetPath = $this->imageDir;
    $imageOrig = $targetPath . $this->origFilename;

//    dump($this->sourceFile);
//    dump($imageOrig);

    if (filesize($imageOrig) < 512){
        $this->add_error("<br /><strong>Image not valid, skipping</strong><br />");
        return false;
    }
    switch ($imageType){
        case 'jpg':
        case 'jpeg':
            $image = @imagecreatefromjpeg($imageOrig);
            break;
        case 'gif':
            $image = @imagecreatefromgif($imageOrig);
            break;
        case 'bmp':
            $image = @imagecreatefrombmp($imageOrig);
            break;
        case 'png':
            $image = @imagecreatefrompng($imageOrig);
            break;
        default:
            $this->add_error('Only JPEG, GIF, PNG, and BMP files are accepted<br />' . $this->origFilename);
            header("Location: $this->redirectURL");
            die();
            break;
    }

    if ($image === false){
        $this->add_error("<br /><strong>Image not valid, skipping</strong><br />");
        return false;
    }

  // Set container to max dimensions if not set
    if (! $this->containerW OR ! $this->containerH){
        list($width, $height) = getimagesize($imageOrig) or die();
        $width = $width < $this->maxWidth ? $width : $this->maxWidth;
        $height = $height < $this->maxHeight ? $height : $this->maxHeight;
        
        if (! $this->containerW) $this->containerW = $width;
        if (! $this->containerH) $this->containerH = $height;
    }

  // Set max dimensions to container if they exceed
    if ($this->maxHeight > $this->containerH) $this->maxHeight = $this->containerH;
    if ($this->maxWidth  > $this->containerW) $this->maxWidth  = $this->containerW;

// Get new dimensions
    list($width, $height) = getimagesize($imageOrig) or die();

    $newHeight = $height;
    $newWidth  = $width;
    $needsResize = false;
    if ($width > $this->maxWidth) {
        $needsResize = true;
        $newWidth = $this->maxWidth;
        $newHeight = $newHeight * $this->maxWidth / $width;
    }
    if ($newHeight > $this->maxHeight) {
        $needsResize = true;
        $presentHeight = $newHeight;
        $newHeight = $this->maxHeight;
        $newWidth = $newWidth * $this->maxHeight / $presentHeight;
    }

    if ($needsResize OR 1){
        $this->containerW == $this->containerW ? $this->containerW : $newWidth;
        $this->containerH == $this->containerH ? $this->containerH : $newHeight;

    // Resample
        $imageContainer = imagecreatetruecolor($this->containerW, $this->containerH);
        $fillColor = imagecolorallocate($imageContainer, $this->fillColor['Red'], $this->fillColor['Green'], $this->fillColor['Blue']);
        imagefill($imageContainer, 0, 0, $fillColor);
        $imageResized = imagecreatetruecolor($newWidth, $newHeight);

        imagecopyresampled($imageResized, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        $padWidth = $padHeight = 0;
        if ($this->pad){
            if ($this->containerW != $newWidth) $padWidth = ($this->containerW - $newWidth) / 2;
            if ($this->containerH != $newHeight) $padHeight = ($this->containerH - $newHeight) / 2;
        }
        imagecopyresampled($imageContainer, $imageResized, $padWidth, $padHeight, 0, 0, $newWidth, $newHeight, $newWidth, $newHeight);

    // Output
//        imagejpeg($imageContainer, $targetPath . $this->newFilename, 90);
        switch ($this->outputFormat){
                case 'jpg':
                case 'jpeg':
                    imagejpeg($imageContainer, $targetPath . $this->newFilename . '.jpg', 90);
                    break;
                case 'gif':
                    imagegif($imageContainer, $targetPath . $this->newFilename . '.gif', 90);
                    break;
                case 'png':
                    imagegif($imageContainer, $targetPath . $this->newFilename . '.png', 90);
                    break;
                default:
                    $this->add_error('Only JPEG, GIF, and PNG files may be output ' . $this->origFilename);
                    header("Location: $this->redirectURL");
                    die();
                    break;
            }

        if ($this->thumbWidth && $this->thumbHeight){
            $imageSmall = imagecreatetruecolor($this->thumbWidth, $this->thumbHeight);
            imagecopyresampled($imageSmall, $imageContainer, 0, 0, 0, 0, $this->thumbWidth, $this->thumbHeight, imagesx($imageContainer), imagesy($imageContainer));

            switch ($this->outputFormat){
                case 'jpg':
                case 'jpeg':
                    imagejpeg($imageSmall, $targetPath . $this->newFilename . '_small.jpg', 90);
                    break;
                case 'gif':
                    imagegif($imageSmall, $targetPath . $this->newFilename . '_small.gif', 90);
                    break;
                case 'png':
                    imagegif($imageSmall, $targetPath . $this->newFilename . '_small.png', 90);
                    break;
                default:
                    $this->add_error('Only JPEG, GIF, and PNG files may be output ' . $this->origFilename);
                    break;
            }
        }
        return true;
    }
}
    function __construct($sourceFilename = ''){
        if ($sourceFilename){
            $this->set_image_sourcefile($sourceFilename);
        }
    }
}
?>
