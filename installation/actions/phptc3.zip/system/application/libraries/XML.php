<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of XML
 *
 * @author Jared
 */
class XML {
    function array_to_xml($array, $level = 0){
        global $XMLOutput;
        foreach ($array as $index => $value){
            $XMLOutput .=  ($this->pad($level*4))."<$index>";
                if (is_array($value)){
                    $XMLOutput .= "\n";
                    $this->array_to_xml($value, $level + 1);
                    $XMLOutput .=  ($this->pad($level*4));
                }
                else{
//                    echo ($this->pad($level*4 + 4))."<$index>$value</$index>";
                    $XMLOutput .= $value;
                }
            
            $XMLOutput .=  "</$index>\n";
        }
        if ($level == 0){
//            $XMLOutput = htmlspecialchars($XMLOutput);
//            $XMLOutput = str_replace("\n", '<br />', $XMLOutput);
            return "$XMLOutput";
//            return $XMLOutput;
        }
    }

    function pad($num){
        for ($i = 1; $i <= $num; $i++){
            @$output .= ' ';
        }
        return @$output;
    }

    function __construct(){

    }
}
?>
