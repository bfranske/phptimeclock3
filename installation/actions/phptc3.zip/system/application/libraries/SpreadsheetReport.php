<?php
class SpreadsheetReport{
    private $userPunches = array();
    private $userUsedStatuses = array();

    function set_info($info){
        foreach ($info as $index => $value){
            $this->$index = $value;
        }
        $this->userUsedStatuses = array();

    //        $timeStart = microtime(true);
            $this->userPunches = $this->CI->Punches->sort_punches($this->punches);
    //        echo '<br />Sort: ' . number_format(microtime(true) - $timeStart, 5). '<br />';

    //        $timeStart = microtime(true);
            $this->punchData = $this->CI->Punches->process_punches($this->userPunches, $this->startDate);
    //        dump($this->punchData);
    //        echo 'Process: ' . number_format(microtime(true) - $timeStart, 5) . '<br />';
    //        dump(number_format(memory_get_peak_usage() / (1024*1024), 3));
    }

    function output_csv(){
        $data = '';
        
        foreach ($this->userPunches as $userID => $userDates){
            foreach ($userDates as $date => $userPunches){
                foreach ($userPunches as $userPunch){
//                    dump($userPunch);
                    extract($userPunch);

                    $duration = number_format($duration, ROUNDING_DIGITS);
                    $data .= "{$this->userInfo[$userID]['username']}, $statusName, $time, $date, $ip_address, $notes, $duration\n";
                }
            }
            $hours = number_format(@$this->punchData['totalHours'][$userID], ROUNDING_DIGITS);
            $otHours = number_format(@$this->punchData['totalOvertime'][$userID], ROUNDING_DIGITS);

            $hoursString = $hours . ((float)$otHours != 0 ? " (+ $otHours Overtime)" : '');
            $data .= "{$this->userInfo[$userID]['username']},,,,,,$hoursString\n\n";
        }
        force_download('times.csv', $data);
    }

    function output_excel(){
//        dump($this->startDate);
//        dump($this->ot);
//        die();

        require_once(BASEPATH.'application/libraries/PHPExcel.php');

        $row = $col = 1;

        $objPHPExcel = new PHPExcel;
        
        foreach ($this->userPunches as $userID => $userDates){
//            $userTotalDuration = 0;
            
            foreach ($userDates as $date => $userPunches){
                foreach ($userPunches as $userPunch){
                    extract($userPunch);

//                    $userTotalDuration += $duration;

                    $duration = number_format($duration, ROUNDING_DIGITS);

//                    $data .= "{$this->userInfo[$userID]['username']}, $statusName, $time, $date, $ip_address, $notes, $duration\n";
                    $objPHPExcel->setActiveSheetIndex(0)
                            ->setCellValue("A$row", $this->userInfo[$userID]['username'])
                            ->setCellValue("B$row", $statusName)
                            ->setCellValue("C$row", $time)
                            ->setCellValue("D$row", $date)
                            ->setCellValue("E$row", $ip_address)
                            ->setCellValue("F$row", $notes)
                            ->setCellValue("G$row", $duration);
//                    $objPHPExcel->getActiveSheet()->getStyle("A$row")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_RED);
                    $row++;
                }
            }
//            $objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->getColor()->setARGB('FF0000000');

            $objPHPExcel->getActiveSheet()->getStyle("A$row:G$row")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
            $objPHPExcel->getActiveSheet()->getStyle("A$row:G$row")->getFill()->getStartColor()->setARGB('FFFFFF00');
            $objPHPExcel->getActiveSheet()->getStyle("A$row:G$row")->getFont()->setBold(true);

            $hours = number_format(@$this->punchData['totalHours'][$userID], ROUNDING_DIGITS);
            $otHours = number_format(@$this->punchData['totalOvertime'][$userID], ROUNDING_DIGITS);
//            dump($hours);
//            dump($otHours);
            $hours = number_format($otHours ? $hours - $otHours : $hours, ROUNDING_DIGITS);
//            dump($hours);

            $hoursString = $hours . ((float)$otHours != 0 ? " (+ $otHours Overtime)" : '');
            $objPHPExcel->setActiveSheetIndex(0)
                            ->setCellValue("G$row", $hoursString)
                            ->setCellValue("A$row", $this->userInfo[$userID]['username']);
            $row++;
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A:')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(8);

        $fileName = sys_get_temp_dir().'/'.createRandomKey(20).'.xls';

        $objWriter = new PHPExcel_Writer_Excel5($objPHPExcel);
        $objWriter->save($fileName);

        $data = file_get_contents($fileName);
        force_download('punches.xls', $data);
    }

//    private function get_col_letter($colNum){
//        return substr('ABCDEFGHIJKLMNOPQRSTUVWXYZ', $colNum -1, 1);
//    }

    function __construct(){
        $this->CI =& get_instance();

        $punchDateFormat = str_ireplace('/y', '', DATE_FORMAT);
        $punchDateFormat = str_ireplace('y/', '', $punchDateFormat);
        define('SHORT_DATE_FORMAT', $punchDateFormat);
        
        define('ROUNDING_DIGITS', $this->CI->Config->item('report_roundingDigits'));
        define('DURATION_FORMAT', $this->CI->Config->item('report_durationFormat'));
    }
}

?>
