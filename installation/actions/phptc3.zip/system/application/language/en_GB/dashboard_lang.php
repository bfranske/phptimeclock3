<?php
$lang['hello world'] = 'Hello Wourld';

?>