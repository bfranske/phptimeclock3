<?php
$lang['Home']       = 'Home';
$lang['Username']   = 'Username';
$lang['Full Name']  = 'Full Name';
$lang['Password']   = 'Password';
$lang['Status']     = 'Status';
$lang['Group']      = 'Group';
$lang['Date']       = 'Date';
$lang['Time']       = 'Time';
$lang['Notes']      = 'Notes';
$lang['Tags']       = 'Tags';
$lang['Tag(s)']     = 'Tag(s)';
$lang['Time']       = 'Time';

?>
