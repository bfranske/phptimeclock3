<?php
/*
 * Dashboard (Includes mobile)
 */
$lang['Select User'] = 'Select User';
$lang['Change Status'] = 'Change Status';
$lang['No punch permissions'] = 'You do not have any punch permissions!';
$lang['Username is required'] = 'Username is required';
$lang['Password is required'] = 'Password is required';
$lang['Full Punchboard'] = 'Full Punchboard';
$lang['Last Punch'] = 'Last Punch';

/*
 * Controller
 */
$lang['Punch Successful'] = 'Punch Successful';
$lang['Incorrect Password!'] = 'Incorrect Password!';
$lang['Status same'] = 'The status/group/tags chosen are the same as your current status!';
$lang['No group punch permission'] = 'You do not have permission to punch into that group!';

/*
 * No IE Support
 */
$lang['No IE support'] = 'Sorry, Internet Explorer is not fully supported due to numerous page rendering glitches, disregard for web standards, and unpatched security vulnerabilities.';
$lang['All other major browsers supported'] = 'All other major web browsers are supported.';
//$lang['Mozilla Firefox'] = 'Mozilla Firefox';
$lang['Firefox desc'] = 'Most popular open source web browser.';
//$lang['Google Chrome'] = 'Google Chrome';
$lang['Chrome desc'] = 'Unmatched speeds and stability.';
// $lang['Opera'] = 'Opera';
$lang['Opera desc'] = 'Lesser known, though good and fully standards compliant.';
//$lang['Safari'] = 'Safari';
$lang['Safari desc'] = 'Apple&reg; web browser, very similar to Google Chrome.';
$lang['IE improvement note'] = 'Note:  Internet Explorer version 9 (currently in beta), is actually showing vast improvements over previous versions, and should be fully supported.';

/*
 * Punch Board
 */


/*
 *  Select Group
 */
$lang['Select User First'] = 'Select User First';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
// $CI->lang->line('')
// ".$CI->lang->line('')."
// '.$CI->lang->line('').'
?>
<?php //$CI->lang->line('') ?>