<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */

$CI =& get_instance();

$punchDateFormat = str_ireplace('/y', '', DATE_FORMAT);
$punchDateFormat = str_ireplace('y/', '', $punchDateFormat);
define('PUNCH_DATE_FORMAT', $punchDateFormat);
//dump($CI->Permissions->has_permission(1, 'punch', 33));
echo '<div id="punchMod">';
    if (! $CI->session->userdata('userID') OR $CI->Permissions->has_any_punch_permission()){
        echo '<span style="color:red">' . validation_errors() . '</span>';

        show_notices();

        echo form_open('mobile', 'name="punchForm"');
            table_open();
                if (! $this->session->userdata('userID')){
                    echo '<tr><td>'.$CI->lang->line('Username').'</td></tr>';
                    echo '<tr><td><select name="userID" id="userID" onchange="refreshGroups(this.options[this.selectedIndex].value)" tabindex="1">';
                        form_select($CI->lang->line('Select User'), '');
                        foreach ($users as $id => $username){
                            form_select($username, $id, set_select('userID', $id));
                        }
                    echo '</select></td></tr>';
                }
                // Group
                if (count($permissionGroups)){
                    if (count($permissionGroups) > 1 OR $CI->Config->item('selectGroupDisplay') == 'always'){
                         echo $CI->lang->line('Group').'<br />';

                        echo '<select name="groupID"  tabindex="3">';
                            render_tree_select_group($tree, false, 0, true, $permissionGroups);
                        echo '</select>';
                    }
                    else {
                        if ($CI->Config->item('selectGroupDisplay') == 'nameIfOne'){
                            foreach ($permissionGroups as $id => $group){
                                echo $CI->lang->line('Group')." - $group";
                            }
                        }
                        else {
                            echo '<img src="'. BASE_URL . 'css/images/ajax-spacer.png" />';
                        }
                        foreach ($permissionGroups as $id => $group){
                            form_hidden('groupID', $id);
                        }
                    }
                }
                else {
                    echo $CI->lang->line('Group').'<br />';
                    echo '<select name="groupID" tabindex="3">';
                        form_select($CI->lang->line('Select User First'), '');
                    echo '</select>';
                }
                // End Group

                if (!$this->session->userdata('userID')){
                    echo '<tr><td>'.$CI->lang->line('Password').'</td></tr>';
                    echo '<tr><td><input type="password" name="password" style="width:143px;" tabindex="4"/></td></tr>';
                }

                if ($this->Config->item('selectStatusStyle') == 'dropdown'){
                    echo '<tr><td>'.$CI->lang->line('Status').'</td></tr>';
                    echo '<tr><td><select name="status"  tabindex="5">';
                        foreach ($statuses->result() as $status){
                            form_select($status->name, $status->id);
                        }
                    echo '</select></td></tr>';
                }

                echo '<tr><td>'.$CI->lang->line('Notes').'</td></tr>';
                echo '<tr><td><input type="text" name="notes" style="width:143px;" tabindex="6"/></td></tr>';

                if ($CI->Config->item('useTags') == 'Yes'){
                    echo '<tr><td>'.$CI->lang->line('Tag(s)').'</td></tr>';
                    echo '<tr><td><input type="text" name="tags" id="tags" style="width:143px;" tabindex="7"/></td></tr>';
                }

                if ($this->Config->item('selectStatusStyle') == 'buttons'){
                    echo '<tr><td>'.$CI->lang->line('Status').'</td></tr>';
                    foreach ($statuses->result() as $index => $status){
                        $tabIndex = $index + 10;
                        echo "<tr><td align=center><input type='submit' value='$status->name' name='status' style='width:120px; color:#$status->color;' class='statusButton' tabindex='$tabIndex'/></td></tr>";
                    }
                }
                else {
                    echo '<tr><td><input type="submit" value="'.$CI->lang->line('Change Status').'" tabindex="8"></td></tr>';
                }
            table_close();
        echo form_close();
    //    dump($_POST);
    }
    else {
        echo $CI->lang->line('No punch permissions');
    }
echo '</div>';

if (is_array($lastUserPunch)){
    echo '<div id="punchBoard">';
        echo '<h4>'.$CI->lang->line('Last Punch').'</h4>';
        extract($lastUserPunch);
    //    dump($lastUserPunch);
        echo '<table>';
            table_data($CI->lang->line('Time'), date(PUNCH_DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone'))));
            table_data($CI->lang->line('Group'), $group_name);
            table_data($CI->lang->line('Status'), "<span style='color:#{$punchColors[$punch_type_id]}'>$status_name</span>");
            table_data($CI->lang->line('Notes'), $notes);
            table_data($CI->lang->line('Tags'), $tags);
        echo '</table>';
        echo anchor('mobile/punch_board', $CI->lang->line('Full Punchboard'));
    echo '</div>';
}

?>
<script type="text/javascript">
//<![CDATA[
    <?php if (! $CI->session->userdata('userID') OR $CI->Permissions->has_any_punch_permission()){ ?>
            var frmvalidator = new Validator("punchForm");
            frmvalidator.EnableMsgsTogether();

            frmvalidator.addValidation("userID","req", "<?php echo $CI->lang->line('Username is required') ?>");
            frmvalidator.addValidation("password","req", "<?php echo $CI->lang->line('Password is required') ?>");
    <?php } ?>
//]]>
</script>