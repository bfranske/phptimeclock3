<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

        <title>phpTimeClock v3 - <?php echo $CI->Config->item('companyName'); ?></title>
        
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/gen_validatorv31.js"></script>

<!--        <link rel="stylesheet" href="<?php echo $CI->config->item('base_url') ?>css/layout.css" type="text/css" />-->
        <link rel="stylesheet" href="<?php echo $CI->config->item('base_url') ?>css/mobile_layout.css" type="text/css" />
    </head>
    <body>
        <div id="header">
            <div id="CompanyName">
                <h4><?php echo $CI->Config->item('companyName'); ?></h4>
            </div>
            <div id="sessionLinks">
                    <?php
                        if ($CI->session->userdata('userID')){
                            echo "Logged in as " . $CI->session->userdata('username') . ' ' . anchor('login/do_logout', 'Logout');
                        }
                    ?>
            </div>
        </div>

        <div id="body">


        