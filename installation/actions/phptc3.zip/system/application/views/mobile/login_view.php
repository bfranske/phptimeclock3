<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    show_notices();

    echo validation_errors();

    echo form_open('login/do_login', 'name="loginForm"');
    echo '<table>';
            echo '<tr><td>Username</td><td><select name="userID" id="userID" onchange="refreshGroups(this.options[this.selectedIndex].value)" tabindex="1">';
                form_select('Select User', '');
                foreach ($users as $id => $username){
                    form_select($username, $id, $this->session->userdata('mobileLoginUsername') == $id ? 'selected="selected"' : '');
                }
            echo '</select></td></tr>';
            form_pass('Password', 'password', '', true, 'tabindex="2"');
            form_hidden('forwardToURL', curPageURL());
            form_submit('Login', false, true, true, false, 1, 'tabindex="3"');
    echo '</table>';
?>
<script type="text/javascript">
    var frmvalidator = new Validator("loginForm");
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req", "Username is required");
    frmvalidator.addValidation("password","req", "Password is required");
</script>
