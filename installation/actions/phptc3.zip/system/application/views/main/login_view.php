<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    show_notices();

    echo validation_errors();

    echo form_open('login/do_login', 'name="loginForm"');
    echo '<table>';
            form_text('Username', 'username', '', true, false, 'tabindex="1"');
            form_pass('Password', 'password', '', true, 'tabindex="2"');
            form_submit('Login', false, true, true, false, 1, 'tabindex="3"');
    echo '</table>';
?>
<script type="text/javascript">
    var frmvalidator = new Validator("loginForm");
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req", "Username is required");
    frmvalidator.addValidation("password","req", "Password is required");
</script>
