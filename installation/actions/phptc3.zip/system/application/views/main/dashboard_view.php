<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<?php

?>
<script type="text/javascript">
    $(function() {
        var availableTags = [<?php echo $availableTags ?>];
        function split(val) {
                return val.split(/,\s*/);
        }
        function extractLast(term) {
                return split(term).pop();
        }

        $("#tags").autocomplete({
                minLength: 0,
                source: function(request, response) {
                        // delegate back to autocomplete, but extract the last term
                        response($.ui.autocomplete.filter(availableTags, extractLast(request.term)));
                },
                focus: function() {
                        // prevent value inserted on focus
                        return false;
                },
                select: function(event, ui) {
                        var terms = split( this.value );
                        // remove the current input
                        terms.pop();
                        // add the selected item
                        terms.push( ui.item.value );
                        // add placeholder to get the comma-and-space at the end
                        terms.push("");
                        this.value = terms.join(", ");
                        return false;
                }
        });
});
</script>
<?php
$CI =& get_instance();
//dump($CI->Permissions->has_permission(1, 'punch', 33));
echo '<div id="punchMod">';
    if (! $CI->session->userdata('userID') OR $CI->Permissions->has_any_punch_permission()){
        echo '<span style="color:red">' . validation_errors() . '</span>';

        show_notices();

        echo form_open('', 'name="punchForm"');
            table_open();
                if (! $this->session->userdata('userID')){
                    echo '<tr><td>'.$CI->lang->line('Username').'</td></tr>';
                    echo '<tr><td><select name="userID" id="userID" onchange="refreshGroups(this.options[this.selectedIndex].value)" tabindex="1">';
                        form_select($CI->lang->line('Select User'), '');
                        foreach ($users as $id => $username){
                            form_select($username, $id, set_select('userID', $id));
                        }
                    echo '</select></td></tr>';
                }
                echo '<tr><td id="groupID">';
                echo '</td></tr>';

                if (!$this->session->userdata('userID')){
                    echo '<tr><td>'.$CI->lang->line('Password').'</td></tr>';
                    echo '<tr><td><input type="password" name="password" style="width:143px;" tabindex="4"/></td></tr>';
                }

                if ($this->Config->item('selectStatusStyle') == 'dropdown'){
                    echo '<tr><td>'.$CI->lang->line('Status').'</td></tr>';
                    echo '<tr><td><select name="status"  tabindex="5">';
                        foreach ($statuses->result() as $status){
                            form_select($status->name, $status->id);
                        }
                    echo '</select></td></tr>';
                }

                echo '<tr><td>'.$CI->lang->line('Notes').'</td></tr>';
                echo '<tr><td><input type="text" name="notes" style="width:143px;" tabindex="6"/></td></tr>';

                if ($CI->Config->item('useTags') == 'Yes'){
                    echo '<tr><td>'.$CI->lang->line('Tag(s)').'</td></tr>';
                    echo '<tr><td><input type="text" name="tags" id="tags" style="width:143px;" tabindex="7"/></td></tr>';
                }

                if ($this->Config->item('selectStatusStyle') == 'buttons'){
                    echo '<tr><td>'.$CI->lang->line('Status').'</td></tr>';
                    foreach ($statuses->result() as $index => $status){
                        $tabIndex = $index + 10;
                        echo "<tr><td align=center><input type='submit' value='$status->name' name='status' style='width:120px; color:#$status->color;' class='statusButton' tabindex='$tabIndex'/></td></tr>";
                    }
                }
                else {
                    echo '<tr><td><input type="submit" value="'.$CI->lang->line('Change Status').'" tabindex="8"></td></tr>';
                }
            table_close();
        echo form_close();
    //    dump($_POST);
    }
    else {
        echo $CI->lang->line('No punch permissions');
    }
echo '</div>';

echo '<div id="punchBoard">';
    
echo '</div>';

?>
<script type="text/javascript">
//<![CDATA[
    function refreshBoard()
    {
        $.ajax({
            url: "<?php echo $CI->config->item('base_url') ?>index.php/dashboard/ajax_Punch_Board/",
//                data: "&groupID=" + id,
//                type: "POST",
            success: function(data) {
              $("#punchBoard").html(data);
            }
        });
    }

    function refreshGroups(id)
    {
        $("#groupID").html("<img src='<?php echo $CI->config->item('base_url') ?>css/images/ajax-loader.gif' alt='AJAX Loader' />");
        $.ajax({
            url: "<?php echo $CI->config->item('base_url') ?>index.php/dashboard/ajax_Select_Group/",
                data: "&userID=" + id + '&echoGroups=1',
                type: "POST",
            success: function(data) {
              $("#groupID").html(data);
            }
        });
    }

    $(document).ready(function(){
        refreshBoard();
        setInterval ( "refreshBoard()", 90000 );

    <?php if ($this->session->userdata('userID')){ ?>
        refreshGroups(<?php echo $this->session->userdata('userID'); ?>);
    <?php } else { ?>
        refreshGroups($('#userID').val());
    <?php } ?>
    });

    <?php if (! $CI->session->userdata('userID') OR $CI->Permissions->has_any_punch_permission()){ ?>
            var frmvalidator = new Validator("punchForm");
            frmvalidator.EnableMsgsTogether();

            frmvalidator.addValidation("userID","req", "<?php echo $CI->lang->line('Username is required') ?>");
            frmvalidator.addValidation("password","req", "<?php echo $CI->lang->line('Password is required') ?>");
    <?php } ?>
//]]>
</script>