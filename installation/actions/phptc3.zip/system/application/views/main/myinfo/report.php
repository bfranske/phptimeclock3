<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();

    $CI->benchmark->mark('output_start');

    define('ROUNDING_DIGITS', $CI->Config->item('report_roundingDigits'));
    define('DURATION_FORMAT', $CI->Config->item('report_durationFormat'));
    define('SHOW_GROUP', $CI->Config->item('report_showGroup'));
    define('SHOW_TAGS', ($CI->Config->item('report_showTags') AND $CI->Config->item('useTags')));
    define('SHOW_DURATION', $CI->Config->item('report_showDuration'));

    $enabledDurations = explode(',', $CI->Config->item('report_enabledDurations'));
    $enabledTotals = explode(',', $CI->Config->item('report_enabledTotals'));
    
    if (!isset($punches)){
        echo '<h3>No punches found for date range</h3>';
    }
    else {
        show_notices();

            $punchTable = array();
            $statusesTime = array();

            $result = $CI->db->get_where('users', array('id' => ($this->session->userdata('userID'))));
            $result = $result->result();
            $username = $result[0]->username;
            $fullName = $result[0]->first_name . ' ' . $result[0]->last_name;

            echo "<a name='$username'></a>";
            echo "<span style='color:#00C; font-size:28px; font-weight:bold;'>$username ($fullName)</span> ";
            echo "<span style='color:#000; font-size:14px; font-weight:bold;'>{$startDate} To {$endDate}</span> ";

            $userOvertime = $weekHours = $dayTime = 0;
            $overtimeStatuses = array();
            $weekOTStartDate = strtotime($startDate) - (date('w', strtotime($startDate)) * 24 * 3600);

            foreach ($punches as $punch){
                extract($punch);

                $spanStr = "<span style='color:#{$punchColors[$status_name]}'>";
                $dateText = date(DATE_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                $timeText = date(TIME_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                if ($duration !== NULL){
                    $duration = number_format($duration / 3600, ROUNDING_DIGITS);
                }
                else {
                    $duration = number_format((now() - strtotime($date_time)) / 3600, ROUNDING_DIGITS) . ' (Now)' ;
                }
                $punchTable[$dateText][] =
                array('id' => $id,
                      'userID' => $user_id,
                      'dateText' => $dateText,
                      'timeText' => $timeText,
                      'time' => $spanStr . $timeText . '</span>',
                      'duration' => $duration,
                      'statusName' => "$spanStr $status_name </span>",
                      'statusNameText' => $status_name,
                      'status' => trim($status),
                      'punchTypeID' => $punch_type_id,
                      'groupID' => $group_id,
                      'groupName' => $group_name,
                      'notes' => $notes,
                      'tags' => $tags,
                      'approved' => $approved,
                      'approved_by' => $approved_by);
            }

            ksort($punchTable);
            $totalTime = 0;

            $groups = $ids = array();
            
            foreach ($punchTable as $date => $punches){
                $dayOvertimeStatuses = array();
                if ($this->Config->item('report_showOvertime') == 'week'){
//                    dump(date('m/d/y',       strtotime($date) - (date('w', strtotime($date)) * 24 * 3600)));
//                    dump(date('m/d/y', $weekOTStartDate));
                    if (($weekOTStartDate < (strtotime($date) - (date('w', strtotime($date)) * 24 * 3600)))){
//                        dump('RESET');
//                        dump($weekHours);
                        $weekOTStartDate = strtotime($date) - (date('w', strtotime($date)) * 24 * 3600);
                        if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                            $userOvertime += $weekHours - $this->Config->item('report_OTperWeekHours');
                            $weekHours = 0;
                        }
                    }
                }

                if (strtotime($startDate) <= strtotime($date)){

                    $dayStatusesTime = array();

                    $dayOfWeek = date('l', strtotime($date));
                    $dayTime = 0;
                    echo "<h4 style='color:black'>$date ($dayOfWeek)</h4>";

                    $groupHeader = SHOW_GROUP ? '<th width="107">Group</th>' : '';
                    $tagsHeader = SHOW_TAGS ? '<th width="140">Tags</th>' : '';
                    $durationHeader = SHOW_DURATION ? '<th width="100">Duration</th>' : '';

                    echo '<table class="punchTable">';
                        echo "<tr><th width='100'>Start</th>$durationHeader<th width='100'>Status</th>$groupHeader<th width='210'>Notes</th>$tagsHeader</tr>";
                        $i = 1;
                }
                    $dayHours = 0;
                    foreach ($punches as $punch){
                        extract($punch);

                        if ($status){
                            $dayTime += $duration;
                            if ($this->Config->item('report_showOvertime') == 'week'){
                                $wasOnOvertime = false;
                                if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                    $wasOnOvertime = true;
                                }
                                $weekHours += $duration;
                                if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                    if ($wasOnOvertime){
                                        @$overtimeStatuses[$statusNameText] += $duration;
                                    }
                                    else {
                                        @$overtimeStatuses[$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                    }
                                }
                            }
                            else if ($this->Config->item('report_showOvertime') == 'day'){
                                $wasOnOvertime = false;
                                if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                    $wasOnOvertime = true;
                                }
                                $dayHours += $duration;
                                if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                    if ($wasOnOvertime){
                                        @$dayOvertimeStatuses[$statusNameText] += $duration;
                                    }
                                    else {
                                        @$dayOvertimeStatuses[$statusNameText] += $dayHours - $this->Config->item('report_OTperDayHours');
                                    }
                                }
                            }
                        }
                        
                        if (strtotime($startDate) <= strtotime($date)){
                            if (in_array($punchTypeID, $enabledTotals)){
                                @$dayStatusesTime[$statusNameText] += $duration;
                                @$statusesTime[$statusNameText] += $duration;
                            }
                            $notes = htmlspecialchars($notes);

                            $groupString = SHOW_GROUP ? "<td width='107'>$groupName</td>" : '';
                            $tagsString = SHOW_TAGS ? "<td width='275'>$tags</td>" : '';
                            if (! in_array($punchTypeID, $enabledDurations))
                                $durationText = '';
                            else
                                $durationText = DURATION_FORMAT == 'decimal' ? number_format((float)$duration, ROUNDING_DIGITS) : duration_to_time(number_format((float)$duration, ROUNDING_DIGITS));
                            $durationString = SHOW_DURATION ? "<td width='107'>$durationText</td>" : '';

                            $classString = ae_detect_ie() ? ($i ? "class='odd'" : "class='even'") : '';
                            echo "<tr id='row$id' $classString><td>$time</td>$durationString<td>$statusName</td>$groupString<td>$notes</td>$tagsString</tr>";

                            $i = $i ? 0 : 1;
                        }
                    }

                    if (strtotime($startDate) <= strtotime($date)){
                        $totalTime += $dayTime;
                    }
                    if ($this->Config->item('report_showOvertime') == 'day' AND $dayTime > $this->Config->item('report_OTperDayHours')){
                        $userOvertime += $dayTime - $this->Config->item('report_OTperDayHours');
                    }

                    if (strtotime($startDate) <= strtotime($date)){
                        $dayHours = DURATION_FORMAT == 'decimal' ? number_format($dayTime, ROUNDING_DIGITS) : duration_to_time(number_format($dayTime, ROUNDING_DIGITS));
                        echo "<tr><td colspan='9'>";
                            echo "<b>Day Hours $dayHours | </b>";
                            $statusesString = '';
                            foreach ($dayStatusesTime as $status => $time){
                                $overtimeString = isset($dayOvertimeStatuses[$status]) ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($overtimeStatuses[$status], ROUNDING_DIGITS) : duration_to_time(number_format($overtimeStatuses[$status], ROUNDING_DIGITS)))." OT)" : '';
                                if (isset($dayOvertimeStatuses[$status])) $time -= $dayOvertimeStatuses[$status];
                                $spanStr = "<span style='color:#{$punchColors[$status]}'>";
                                $time = DURATION_FORMAT == 'decimal' ? number_format($time, ROUNDING_DIGITS) : duration_to_time(number_format($time, ROUNDING_DIGITS));
                                $statusesString .= "$spanStr $status: $time $overtimeString</span>, ";
                            }
                            echo trimString($statusesString, 2);
                        echo "</td></tr>";
                    echo '</table>';
                    }

                if ($this->Config->item('report_showOvertime') == 'week'){
                    if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                        $userOvertime += $weekHours - $this->Config->item('report_OTperWeekHours');
                    }
                }
    //            echo "<h4>Day Hours $dayHours</h4>";
            }
            $totalHours = $totalTime;
            if ($userOvertime)
                $totalHours -= $userOvertime;
            $totalHours = DURATION_FORMAT == 'decimal' ? number_format($totalTime, ROUNDING_DIGITS) : duration_to_time(number_format($totalTime, ROUNDING_DIGITS));
            $overtimeString = $userOvertime ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($overtimeString, ROUNDING_DIGITS) : duration_to_time(number_format($overtimeString, ROUNDING_DIGITS)))." Overtime)" : '';
            echo "<h3>Total Hours $totalHours $overtimeString</h3>";

            echo "<b>Statuses</b> ";
            $statusesString = '';

            foreach ($statusesTime as $status => $time){
                $overtimeString = isset($overtimeStatuses[$status]) ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($overtimeStatuses[$status], ROUNDING_DIGITS) : duration_to_time(number_format($overtimeStatuses[$status], ROUNDING_DIGITS)))." OT)" : '';
                if (isset($overtimeStatuses[$status])) $time -= $overtimeStatuses[$status];
                $spanStr = "<span style='color:#{$punchColors[$status]}'>";
                $time = DURATION_FORMAT == 'decimal' ? number_format($time, ROUNDING_DIGITS) : duration_to_time(number_format($time, ROUNDING_DIGITS));
                $statusesString .= "$spanStr $status: $time $overtimeString</span>, ";
            }
            echo trimString($statusesString);
    }
    $CI->benchmark->mark('output_end');


    echo '<span style="color:#8c9297" id="punchStats">';
        echo "<br /><br />Total punches:  $totalPunches. <br />";
        echo 'Report fetched in ' . number_format($CI->benchmark->elapsed_time('report_start', 'report_end'), 4) . '<br />';
        echo 'Page generated in ' . number_format($CI->benchmark->elapsed_time('output_start', 'output_end'), 4) . '<br />';
    echo '</span>';
?>
