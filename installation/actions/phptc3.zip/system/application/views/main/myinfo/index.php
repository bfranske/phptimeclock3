<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<?php
    $CI =& get_instance();
    echo validation_errors();

    show_notices();

    define('ROUNDING_DIGITS', $CI->Config->item('report_roundingDigits'));
    define('DURATION_FORMAT', $CI->Config->item('report_durationFormat'));
    define('SHOW_GROUP', $CI->Config->item('report_showGroup'));
    define('SHOW_TAGS', ($CI->Config->item('report_showTags') AND $CI->Config->item('useTags')));
    define('SHOW_DURATION', $CI->Config->item('report_showDuration'));

    $enabledDurations = explode(',', $CI->Config->item('report_enabledDurations'));

    $result = $CI->db->get_where('users', array('id' => ($this->session->userdata('userID'))));
    $result = $result->result();
    $username = $result[0]->username;
    $fullName = $result[0]->first_name . ' ' . $result[0]->last_name;
    
    echo "<h3 style='color:#00C'>$username ($fullName)</h3>";
/*
 * My Info
 */
    echo '<h2>My Info</h2>';

    echo '<h4>Password</h4>';
    echo form_open('user');
        table_open();
            form_pass('Password', 'newPass', '', true, "tabindex='1'");
            form_pass('Confirm', 'newPass2', '', true, "tabindex='2'");

            form_pass('PIN', 'PIN');
            form_pass('Confirm', 'PIN2');
            
            form_submit('Update', false, true, true, false, 1, "tabindex='3'");
        table_close();
    echo form_close();

/*
 * My Time
 */
    $startDate = gmt_to_local(now() - (3600*24*(date('w', gmt_to_local(now(), $CI->Config->item('timezone'))))), $CI->Config->item('timezone'));

    echo '<h3>My Time</h3>';
    echo form_open('user/report');
        echo 'Show my hours for the following date range';
        table_open();
//            $startDate = gmt_to_local(now() - (3600*24*(date('w', now()))), $CI->Config->item('timezone'));
            form_text('Start Date', 'startDate', date(DATE_FORMAT, $startDate), true, 9, "id='datepicker_start' tabindex='4'");
            form_text('End Date', 'endDate', date(DATE_FORMAT, gmt_to_local(now(), $CI->Config->item('timezone'))), true, 9, "id='datepicker_end' tabindex='5'");

            form_submit('Show Hours', false, true, true, false, 1, "tabindex='6'");
        table_close();
    echo form_close();

/*
 * Recent activity
 */

            $punchTable = array();
            $statusesTime = array();

            echo "<h3>Recent Punches</h3>";

            foreach ($punches as $punch){
                extract($punch);

                $spanStr = "<span style='color:#{$punchColors[$status_name]}'>";
                $dateText = date(DATE_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                $timeText = date(TIME_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                if ($duration !== NULL){
                    $duration = number_format($duration / 3600, ROUNDING_DIGITS);
                }
                else {
                    $duration = number_format((now() - strtotime($date_time)) / 3600, ROUNDING_DIGITS) . ' (Now)' ;
                }
                $punchTable[$dateText][] =
                array('id' => $id,
                      'userID' => $user_id,
                      'dateText' => $dateText,
                      'timeText' => $timeText,
                      'time' => $spanStr . $timeText . '</span>',
                      'duration' => $duration,
                      'statusName' => "$spanStr $status_name </span>",
                      'statusNameText' => $status_name,
                      'status' => trim($status),
                      'punchTypeID' => $punch_type_id,
                      'groupID' => $group_id,
                      'groupName' => $group_name,
                      'notes' => $notes,
                      'tags' => $tags,
                      'approved' => $approved,
                      'approved_by' => $approved_by);
            }

            ksort($punchTable);

            $groups = $ids = array();
            foreach ($punchTable as $date => $punches){

                $dayOfWeek = date('l', strtotime($date));
                $notes = htmlspecialchars($notes);
                echo "<h4 style='color:black'>$date ($dayOfWeek)</h4>";

                $groupHeader = SHOW_GROUP ? '<th width="107">Group</th>' : '';
                $tagsHeader = SHOW_TAGS ? '<th width="140">Tags</th>' : '';
                $durationHeader = SHOW_DURATION ? '<th width="100">Duration</th>' : '';

                echo '<table class="punchTable">';
                    echo "<tr><th width='100'>Start</th>$durationHeader<th width='100'>Status</th>$groupHeader<th width='210'>Notes</th>$tagsHeader</tr>";
                    $i = 1;
                    foreach ($punches as $punch){
                        extract($punch);
                        $groupString = SHOW_GROUP ? "<td width='107'>$groupName</td>" : '';
                        $tagsString  = SHOW_TAGS  ? "<td width='107'>$tags</td>" : '';
                        if (! in_array($punchTypeID, $enabledDurations))
                            $duration = '';
                        $duration = DURATION_FORMAT == 'decimal' ? number_format((float)$duration, ROUNDING_DIGITS) : duration_to_time(number_format((float)$duration, ROUNDING_DIGITS));
                        $durationString = SHOW_DURATION ? "<td width='107'>$duration</td>" : '';

                        $classString = ae_detect_ie() ? ($i ? "class='odd'" : "class='even'") : '';
                        echo "<tr id='row$id' $classString><td>$time</td>$durationString<td>$statusName</td>$groupString<td>$notes</td>$tagsString</tr>";
                        $i = $i ? 0 : 1;
                    }
                echo '</table>';
            }
?>
<script type="text/javascript">
    $(function() {
        $("#datepicker_start").datepicker();
    });

    $(function() {
        $("#datepicker_end").datepicker();
    });
</script>