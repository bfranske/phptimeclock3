<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<style type="text/css">
    
</style>

<?php
    $CI =& get_instance();

    if (@$isMobile){
        echo anchor('mobile', $CI->lang->line('Home'));
    }
    
    $punchDateFormat = str_ireplace('/y', '', DATE_FORMAT);
    $punchDateFormat = str_ireplace('y/', '', $punchDateFormat);
    define('PUNCH_DATE_FORMAT', $punchDateFormat);

    table_open('class="punchTable" cellpadding="0" cellspacing="0"');
        if ($CI->Config->item('userIdentifier_board') == 'username')
            $userIdentifierText = $CI->lang->line('Username');
        else
            $userIdentifierText = $CI->lang->line('Full Name');
        $userIdentifierWidth = ($CI->Config->item('punchBoardGroup') == 'Show' AND $CI->Config->item('punchBoardNotes') == 'Show') ? 120 : 140;
        echo "<tr>";
            echo "<th width=$userIdentifierWidth>$userIdentifierText</th>";
            echo "<th width=70>".$CI->lang->line('Status')."</th>";
            if ($CI->Config->item('punchBoardGroup') == 'Show')
                echo "<th width=130>".$CI->lang->line('Group')."</th>";
            echo "<th width=50>".$CI->lang->line('Date')."</th>";
            echo "<th width=100>".$CI->lang->line('Time')."</th>";
            if ($CI->Config->item('punchBoardNotes') == 'Show') 
                echo "<th width=280>".$CI->lang->line('Notes')."</th>";
        echo "</tr>";

        $i = 1;
        foreach($punchBoard->result() as $lastPunch){
            $date = date(PUNCH_DATE_FORMAT, gmt_to_local(strtotime($lastPunch->date_time), $CI->Config->item('timezone')));
            $time = date(TIME_FORMAT, gmt_to_local(strtotime($lastPunch->date_time), $CI->Config->item('timezone')));
            $spanStr = "<span style='color:#{$punchColors[$lastPunch->punch_type_id]}'>";
            if ($CI->Config->item('userIdentifier_board') == 'username')
                $userIdentifier = $lastPunch->username;
            else{
                if ($CI->Config->item('lastNameView') == 'name')
                    $userIdentifier = $lastPunch->first_name . ' ' .$lastPunch->last_name;
                else
                    $userIdentifier = $lastPunch->first_name . ' ' . strtoupper(substr(trim($lastPunch->last_name), 0, 1)) . '.';
            }
            $notes = strlen($lastPunch->notes) > 43 ? substr($lastPunch->notes, 0, 40) . '...' : $lastPunch->notes;
            $classString = (ae_detect_ie() or @$isMobile) ? ($i ? "class='odd'" : "class='even'") : '';
            echo "<tr $classString>";
                echo "<td>$userIdentifier</td>";
                echo "<td>$spanStr $lastPunch->punch_name</span></td>";
                if ($CI->Config->item('punchBoardGroup') == 'Show')
                    echo "<td>$lastPunch->group_name</td>";
                echo "<td>$spanStr $date</span></td>";
                echo "<td>$spanStr $time</span></td>";
                if ($CI->Config->item('punchBoardNotes') == 'Show') {
                    $tip = $lastPunch->notes ? "class='tooltip' title='$lastPunch->notes'" : '';
                    echo "<td $tip>$notes</td>";
                }
            echo "</tr>";
            $i = $i ? 0 : 1;
        }
    table_close();
?>
<?php if (! @$isMobile){ ?>
    <script type="text/javascript">
        tooltip();
    </script>
<?php } ?>