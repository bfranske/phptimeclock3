<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<?php
$CI =& get_instance();
if (count($permissionGroups)){
    if (count($permissionGroups) > 1 OR $CI->Config->item('selectGroupDisplay') == 'always'){
        if ($echoGroups)
            echo $CI->lang->line('Group').' <br />';

        echo '<select name="groupID"  tabindex="3">';
            render_tree_select_group($tree, false, 0, true, $permissionGroups);
        echo '</select>';
    }
    else {
        if ($CI->Config->item('selectGroupDisplay') == 'nameIfOne'){
            foreach ($permissionGroups as $id => $group){
                echo $CI->lang->line('Group')." - $group";
            }
        }
        else {
            echo '<img src="'. BASE_URL . 'css/images/ajax-spacer.png" />';
        }
        foreach ($permissionGroups as $id => $group){
            form_hidden('groupID', $id);
        }
    }
}
else {
    echo $CI->lang->line('Group').' <br />';
    echo '<select name="groupID" tabindex="3">';
        form_select($CI->lang->line('Select User First'), '');
    echo '</select>';
}

//dump ($CI->Config->item('selectGroupDisplay'));
?>
