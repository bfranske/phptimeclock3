<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<?php
    $CI =& get_instance();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        
        <title>phpTimeClock v3 - <?php echo $CI->Config->item('companyName'); ?></title>

        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/jquery-1.4.2.min.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/jquery-ui-1.8.4.custom.min.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/gen_validatorv31.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/fancybox/jquery.fancybox-1.3.1.pack.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/fancybox/jquery.easing-1.3.pack.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/image_preview.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>includes/js/tool_tip.js"></script>

        <script type="text/javascript" src="<?php echo BASE_URL ?>includes/js/jquery_functions.js"></script>

        <link rel="stylesheet" href="<?php echo $CI->config->item('base_url') ?>css/layout.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $CI->config->item('base_url') ?>css/print_layout.css" media="print"  type="text/css" />

        <!-- J-Query UI !-->
        <link href="<?php echo BASE_URL; ?>css/jquery/jquery-ui-1.8.4.custom.css" media="screen" rel="stylesheet" type="text/css" />

        <!-- CSS DropDown !-->
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/dropdown/dropdown.css" media="screen" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/dropdown/themes/default/default.css" media="screen" rel="stylesheet" type="text/css" />

        <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/fancybox/jquery.fancybox-1.3.1.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/colorPicker/colorpicker.css" type="text/css" />

        <!--[if lt IE 7]>
        <script type="text/javascript" src="js/jquery/jquery.js"></script>
        <script type="text/javascript" src="js/jquery/jquery.dropdown.js"></script>
        <![endif]-->

        <!--[if IE]>
                <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/ie-only.css" />
        <![endif]-->

        <script type="text/javascript">
            $(function() {
		$("#datepicker_start").datepicker();
            });

            $(function() {
		$("#datepicker_end").datepicker();
            });
            $(function() {
                $( "#accordion" ).accordion({ autoHeight: false });
            });
            $(document).ready(function() {
                $(function() {
                     $("#accordion").accordion({collapsible: false, autoHeight: false, active: '.activeAccordian'});
                });
            });

        </script>
    </head>
    <body>
        <div id="wrapper">

            <div id="header">
                <div id="sessionLinks">
                        <?php
                            if ($CI->session->userdata('userID')){
                                echo "Logged in as " . $CI->session->userdata('username') . ' ' . anchor('login/do_logout', 'Logout');
                            }
                            else {
                                echo '<a id="inline" href="#data">Login</a>';
                                echo '<div style="display:none"><div id="data" style="padding:15px">';
                                    echo form_open('login/do_login', 'name="loginForm"');
                                        echo '<table>';
                                            form_text('Username', 'username', '', true, false, 'id', 'username');
                                            form_pass('Password', 'password');
                                            form_submit('Login');
                                        echo '</table>';
                                    echo form_close();
                                echo '</div></div>';
                                ?>
                                    <script type="text/javascript">
                                        var frmvalidator = new Validator("loginForm");
                                        frmvalidator.EnableMsgsTogether();

                                        frmvalidator.addValidation("username","req", "Username is required");
                                        frmvalidator.addValidation("password","req", "Password is required");


$(document).ready(function() {
	/* Using custom settings */

	$("a#inline").fancybox({
		'hideOnContentClick': false,
                'onComplete': function(){
                    $('#username').focus()
                }
//                'onComplete': $('#username').focus()
	});
        $("a#inline2").fancybox({
		'hideOnContentClick': false
	});

        
	/* Apply fancybox to multiple items */

	$("a.group").fancybox({
		'transitionIn'	:	'elastic',
		'transitionOut'	:	'elastic',
		'speedIn'		:	600,
		'speedOut'		:	200,
		'overlayShow'	:	false
	});

});
                                    </script>
                                <?php
                            }
                        ?>
                </div>

                <div id="topMenu">
                    <?php
                        show_menu();
                    ?>
                </div>
            </div>

            <div id="body">
            

        