<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
//echo form_open('admin/users_manage_do');
    $CI =& get_instance();

    $formUsers = array();

    echo '<tr><td colspan="5"><strong>Run Reports</strong></td></tr>';

    echo '<tr><th width="25"><input type="checkbox" class="checkall"></th><th>Username</th><th>First Name</th><th>Last Name</th></tr>';

        $i = 1;
        foreach ($users->result() as $row){
            $classString = ae_detect_ie() ? ($i ? "class='odd'" : "class='even'") : '';
            echo "<tr $classString>";
                form_checkbox('', 'selectedUsers[]', $row->user_id, false, false, false, 1, false, 'class="selectedUsersCheck"');
                echo '<td>'.$row->username.'</td>'.
                '<td>'.$row->first_name.'</td>'.
                '<td>'.$row->last_name.'</td>';
            echo '</tr>';
            $i = $i ? 0 : 1;
        }

    echo '<tr><td colspan=7><table>';
        form_hidden('reportsGroupID', $reportsGroupID);
        $startDate = gmt_to_local(now() - (3600*24*(date('w', gmt_to_local(now(), $CI->Config->item('timezone'))))), $CI->Config->item('timezone'));
        form_text('Start Date', 'startDate', date(DATE_FORMAT, $startDate), 2, 10, "id='datepicker_start'");
        form_text('End Date', 'endDate', date(DATE_FORMAT, gmt_to_local(now(), $CI->Config->item('timezone'))), false, 10, "id='datepicker_end'");
        echo "<td><input type='submit' name='reportType' value='Detail Report'></td>";
        echo "<td><input type='submit' name='reportType' value='Summary Report'></td>";
        echo "<td><input type='submit' name='reportType' value='Group Overview'></td>";
        echo "<td><input type='button' name='reportType' value='Audit Report' onclick='showAuditOptions()'></td>";

//        form_submit('Detail Report', true, false);
//        form_submit('Summary Report', true, false);
        echo "</tr>";
//        echo 'Groups to include';
//        echo '<select name="groupScope">';
//            form_select('All Groups', 'all');
//            form_select('Child groups', 'children');
//            form_select('This group only', 'explicit');
//        echo '</select>';
        form_hidden('groupScope', 'children');
    echo '</td></tr>';
    echo "<tr style='background:#D2DAE1'><td></td><td></td><td></td><td></td>";
    echo "<td><input type='submit' name='reportType' value='CSV Report'></td>";
    echo "<td><input type='submit' name='reportType' value='Excel Report'></td>";
    echo "<td><input type='button' value='More Options' onclick='showOptions()' /></td></tr>";
    echo '</table></td></tr>';

//echo form_close();
?>
<script type="text/javascript">
    $(function () { // this line makes sure this code runs on page load
	$('.checkall').click(function () {
		$('.selectedUsersCheck').attr('checked', this.checked);
	});
    })
</script>
<script type="text/javascript">
    $(function() {
        $("#datepicker_start").datepicker();
    });

    $(function() {
        $("#datepicker_end").datepicker();
    });
</script>
