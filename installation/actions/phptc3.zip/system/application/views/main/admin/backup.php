<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<div id="adminContent">
    <h3>Download Backup</h3>

    <?php
        echo 'This is where you can download a backup of your installation.<br />
              You should take caution to not let this file get into the wrong hands.<br />';

        echo '<table>';
            echo form_open('admin/backup', 'name="backupForm"');
                form_hidden('option', 'regular');
                form_hidden('action', 'backup');
                form_submit('Download Backup');
            echo form_close();
        echo '</table>';
    ?>

    <?php show_notices() ?>

    <h3>Restore Backup</h3>

    This is where you can restore a backup of your installation.  File must be zipped.<br />
    The .ptc3 file in the zip must be named identical to zip.<br />
    WARNING!  This will overwrite your existing installation, make sure this is what you want to do!<br />
    It is STRONGLY recommended that you do a backup before restoring, in case of file corruption, as the database is emptied before restoring!

    <?php
    echo form_open_multipart('admin/backup');?>

    <input type="file" name="userfile" size="20" />

    <?php
    echo '<table>';
        form_hidden('action', 'restore');
        form_submit('Restore from backup');
    echo '</table>';

    echo form_close(); ?>

</div>

