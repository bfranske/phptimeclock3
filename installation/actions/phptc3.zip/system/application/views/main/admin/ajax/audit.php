<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();

    foreach ($punches->result_array() as $punch){
        extract($punch);

        $when_changed = date(DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($when_changed), $CI->Config->item('timezone')));
        $old_start = date(DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($old_start), $CI->Config->item('timezone')));
        $new_start = date(DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($new_start), $CI->Config->item('timezone')));

        $bgClasses = array('add' => 'auditAdd',
                           'edit' => 'auditEdit',
                           'delete' => 'auditDelete');
        echo '<tr><td>';
            echo "<div class='{$bgClasses[$edit_action]}'>";
                echo '<table class="auditTable">';
                    echo "<tr><th>Editing User</th><th>Editing IP</th><th>Punching IP</th><th>Reason</th><th>Action</th><th>When</th><tr>";
                    echo "<tr><td>$username</td><td>$editing_ip</td><td>$punching_ip</td><td>$reason_for_editing</td><td>$edit_action</td><td>$when_changed</td></tr>";
                echo '</table>';

                echo '<table class="auditTable">';
                    echo "<tr><th></th><th>Start</th><th>Group</th><th>Status</th><th>Notes</th><th>Tags</th></tr>";
                    if ($edit_action != 'add')
                        echo "<tr><td><strong>Old</strong></td><td>$old_start</td><td>$old_group</td><td>$old_punch_type</td><td>$old_notes</td><td>$old_tags</td></tr>";
                    echo "<tr><td><strong>New</strong></td><td>$new_start</td><td>$new_group</td><td>$new_punch_type</td><td>$new_notes</td><td>$new_tags</tr>";
                echo '</table>';
                echo '<hr />';
            }
            echo "<input type='button' value='Hide' onclick='deleteRow(\"AddAudit\", ".$CI->input->post('punchID').")'/>";
            echo '</div>';
        echo '</td></tr>';
    

//    $this->db->select('audits.id, punch_id, username, ip_address, reason_for_editing, edit_action,
//                       old_start, old_end, old_groups.name AS old_group, old_punch_types.name AS old_punch_type, old_notes, old_tags,
//                       new_start, new_end, new_groups.name AS new_group, new_punch_types.name AS new_punch_type, new_notes, new_tags');
?>
