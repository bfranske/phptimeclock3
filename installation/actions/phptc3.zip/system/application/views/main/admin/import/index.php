<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<div id="adminContent">
    <h4>Import From Another Database</h4>

    <?php
        if (isset($errors)){
            foreach ($errors as $error){
                echo "<br />$error<br/>";
            }
        }
        
        echo form_open_multipart('admin/import_from_db_do');
            echo table_open();
                form_text('DB Host', 'dbHost', isset($dbCredentials) ? $dbCredentials['dbHost'] : '');
                form_text('DB User', 'dbUser', isset($dbCredentials) ? $dbCredentials['dbUser'] : '');
                form_text('DB Pass', 'dbPass', isset($dbCredentials) ? $dbCredentials['dbPass'] : '');
                form_text('DB Name', 'dbName', isset($dbCredentials) ? $dbCredentials['dbName'] : '');

                form_label('Table prefix (usually can be left empty)');
                form_text('Table Prefix', 'tablePrefix', isset($_SESSION['tablePrefix']) ? $_SESSION['tablePrefix'] : '');
                form_submit('Import From Database', true);
            echo table_close();
        echo form_close();
    ?>
</div>
