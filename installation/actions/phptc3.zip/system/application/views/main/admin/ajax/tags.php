<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();

    show_notices();
    
        echo table_open();
            echo '<tr><td>Enabled?</td><td>Name</td><td>Merge with</td></tr>';
            foreach ($tags as $tag){
                form_checkbox('', "enabled[$tag->id]", 1, ($tag->enabled ? true : false), 2, false);
                form_text('', "names[$tag->id]", $tag->name, false);
                echo "<td><select name='nameCombines[$tag->id]'>";
                    form_select('Select', 0);
                    foreach ($tags as $tagCombine){
                        if ($tagCombine->id != $tag->id)
                            form_select($tagCombine->name, $tagCombine->id);
                    }
                echo '</select></td></tr>';
            }
            form_submit('Update Tags', true, true, true, false, 2);

        table_close();
    echo form_close();

?>
