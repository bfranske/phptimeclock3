<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<h2>Configuration - Reports</h2>
<?php
    $CI =& get_instance();

    $enabledDurations = explode(',', $CI->Config->item('report_enabledDurations'));
    $enabledTotals = explode(',', $CI->Config->item('report_enabledTotals'));

    echo '<span style="color:red">' . validation_errors() . '</span>';

    show_notices();

    echo form_open('admin/reports', 'name="reportDefaultsForm"');
        echo '<h3>Report Settings</h3>';

        table_open();
            form_text('Rounding (1-4 Digits)', 'roundingDigits', $CI->Config->item('report_roundingDigits'), true, 2);

            echo '<tr><td>Duration format? </td>';
            echo '<td><input name="durationFormat" value="decimal" type="radio" '.($CI->Config->item('report_durationFormat') == 'decimal' ? 'checked="checked"' : '').' /><label>Decimal</label>
                      <input name="durationFormat" value="minutes" type="radio" '.($CI->Config->item('report_durationFormat') == 'minutes' ? 'checked="checked"' : '').' /><label>Minutes</label></td></tr>';

            echo '<tr><td>Show Group? </td>';
            echo '<td><input name="showGroup" value="1" type="radio" '.($CI->Config->item('report_showGroup') ? 'checked="checked"' : '').' /><label>Yes</label>
                      <input name="showGroup" value="0" type="radio" '.(!$CI->Config->item('report_showGroup') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';

            echo '<tr class="tooltip" title="Shows parents of groups on detail report. (They can always be viewed by mousing over the group.)"><td>Show Group Upline? </td>';
            echo '<td><input name="showGroupUpline" value="1" type="radio" '.($CI->Config->item('report_showGroupUpline') ? 'checked="checked"' : '').' /><label>Yes</label>
                      <input name="showGroupUpline" value="0" type="radio" '.(!$CI->Config->item('report_showGroupUpline') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';

            echo '<tr class="tooltip" title="Shows per group breakdown on each user on detail and summary reports"><td>Show Group Breakdown? </td>';
            echo '<td><input name="showGroupBreakdown" value="1" type="radio" '.($CI->Config->item('report_showGroupBreakdown') ? 'checked="checked"' : '').' /><label>Yes</label>
                      <input name="showGroupBreakdown" value="0" type="radio" '.(!$CI->Config->item('report_showGroupBreakdown') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';

            echo '<tr><td>Show Tags? </td>';
            echo '<td><input name="showTags" value="1" type="radio" '.($CI->Config->item('report_showTags') ? 'checked="checked"' : '').' /><label>Yes</label>
                      <input name="showTags" value="0" type="radio" '.(!$CI->Config->item('report_showTags') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';

            echo '<tr><td>Show Duration? </td>';
            echo '<td><input name="showDuration" value="1" type="radio" '.($CI->Config->item('report_showDuration') ? 'checked="checked"' : '').' /><label>Yes</label>
                      <input name="showDuration" value="0" type="radio" '.(!$CI->Config->item('report_showDuration') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';

            echo '<tr><td>Paginate Employees? </td>';
            echo '<td><input name="paginateEmployees" value="1" type="radio" '.($CI->Config->item('report_paginateEmployees') ? 'checked="checked"' : '').' /><label>Yes</label>
                      <input name="paginateEmployees" value="0" type="radio" '.(!$CI->Config->item('report_paginateEmployees') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';
        table_close();
        table_open();
            echo '<tr><td>Prints each employee on seperate page on detail report.</td></tr>';
        table_close();

        echo '<br /><strong>Overtime</strong>';

        table_open();
            echo '<tr><td>Show Overtime? </td>';
            echo '<td><input name="showOvertime" value="week" type="radio" '.($CI->Config->item('report_showOvertime') == 'week' ? 'checked="checked"' : '').' /><label>Week</label>
                      <input name="showOvertime" value="day"  type="radio" '.($CI->Config->item('report_showOvertime') == 'day' ? 'checked="checked"' : '').' /><label>Day</label>
                      <input name="showOvertime" value="0"    type="radio" '.(!$CI->Config->item('report_showOvertime') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';
            echo '<tr><td>Week Start? </td>';
            echo '<td><input name="weekStartOffset" value="0" type="radio" '.($CI->Config->item('report_weekStartOffset') == '0' ? 'checked="checked"' : '').' /><label>Sun</label>
                      <input name="weekStartOffset" value="1" type="radio" '.($CI->Config->item('report_weekStartOffset') == '1' ? 'checked="checked"' : '').' /><label>Mon</label>
                      <input name="weekStartOffset" value="2" type="radio" '.($CI->Config->item('report_weekStartOffset') == '2' ? 'checked="checked"' : '').' /><label>Tue</label>
                      <input name="weekStartOffset" value="3" type="radio" '.($CI->Config->item('report_weekStartOffset') == '3' ? 'checked="checked"' : '').' /><label>Wed</label>
                      <input name="weekStartOffset" value="4" type="radio" '.($CI->Config->item('report_weekStartOffset') == '4' ? 'checked="checked"' : '').' /><label>Thu</label>
                      <input name="weekStartOffset" value="5" type="radio" '.($CI->Config->item('report_weekStartOffset') == '5' ? 'checked="checked"' : '').' /><label>Fri</label>
                      <input name="weekStartOffset" value="6" type="radio" '.($CI->Config->item('report_weekStartOffset') == '6' ? 'checked="checked"' : '').' /><label>Sat</label>
                  </td></tr>';
            form_text('Per Week Hours', 'OTperWeekHours', $CI->Config->item('report_OTperWeekHours'), true, 3);
            form_text('Per Day Hours',  'OTperDayHours',  $CI->Config->item('report_OTperDayHours'),  true, 3);
        table_close();
        
        if ($punchTypes->num_rows){
            echo '<br /><strong>Punch Types to Show</strong>';
            table_open();
                echo '<tr><td>Name</td><td>Type</td><td>Color</td><td>Duration</td><td>Total</td></tr>
                        ';
                foreach($punchTypes->result() as $index => $type){
                    $status = $type->status ? 'In' : 'Out';
                    echo "<tr><td>$type->name</td>";
                    echo "<td>$status</td>";
                    echo "<td style='background:#$type->color' width='25'> </td>";
                        @$indexes[] = $index;

                    form_checkbox('', "enabledDurations[$type->id]", $type->id, (in_array($type->id, $enabledDurations) ? 1 : 0), false, false);
                    form_checkbox('', "enabledTotals[$type->id]", $type->id, (in_array($type->id, $enabledTotals) ? 1 : 0), 3, false);
                    echo "
                         ";
                }
            echo table_close();
        }

        form_submit('Update', true, false, false);
    echo '</form>';

    ?>
    <script type="text/javascript">
        var frmvalidator = new Validator("reportDefaultsForm");
        frmvalidator.EnableMsgsTogether();

        frmvalidator.addValidation("newName","req", "Punch type name is required");
        frmvalidator.addValidation("newColor","req", "Punch type color is required");
    </script>


<?php

?>
