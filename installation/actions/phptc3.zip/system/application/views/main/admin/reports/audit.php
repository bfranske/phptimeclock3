<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();
    
//    dump($CI->session->userdata('reportsPostData'));
    extract($CI->session->userdata('reportsPostData'));
    echo "<h3>Audits $startDate - $endDate</h3>";
    echo '<strong>';
        foreach ($auditTypes as $index => $auditType){
            echo ($index ? ', ' : '') . "$auditType";
        }
        echo ' audits';
    echo '</strong>';

    if (isset($audits) AND count($audits)){
        foreach ($audits as $audit){
            $users[$audit->punching_user][] = $audit;
        }
        $bgClasses = array('add' => 'auditAdd',
                          'edit' => 'auditEdit',
                          'delete' => 'auditDelete');
        foreach ($users as $username => $user){
            echo "<h3>$username</h3>";
            foreach ($user as $audit){
                $when_changed = date(DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($audit->when_changed), $CI->Config->item('timezone')));
                $old_start = date(DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($audit->old_start), $CI->Config->item('timezone')));
                $new_start = date(DATE_FORMAT.' '.TIME_FORMAT, gmt_to_local(strtotime($audit->new_start), $CI->Config->item('timezone')));
                echo "<div class='{$bgClasses[$audit->edit_action]}'>";
                echo '<table class="auditTable">';
                    echo "<tr><th>Editing User</th><th>Editing IP</th><th>Punching IP</th><th>Reason</th><th>Action</th><th>When</th><tr>";
                    echo "<tr><td>$audit->editing_user</td><td>$audit->audit_ip</td><td>$audit->punching_ip</td><td>$audit->reason_for_editing</td><td>$audit->edit_action</td><td>$audit->when_changed</td></tr>";
                echo '</table>';

                echo '<table class="auditTable">';
                    echo "<tr><th></th><th>Start</th><th>Group</th><th>Status</th><th>Notes</th><th>Tags</th></tr>";
                    if ($audit->edit_action != 'add')
                        echo "<tr><td><strong>Old</strong></td><td>$audit->old_start</td><td>$audit->old_group</td><td>$audit->old_punch_type</td><td>$audit->old_notes</td><td>$audit->old_tags</td></tr>";
                    echo "<tr><td><strong>New</strong></td><td>$audit->new_start</td><td>$audit->new_group</td><td>$audit->new_punch_type</td><td>$audit->new_notes</td><td>$audit->new_tags</tr>";
                echo '</table>';
                echo '</div>';
                echo '<hr />';
            }
        }
    }
    else {
        echo '<h3>No audits found for search criteria.</h3>';
    }
//    dump($audits);
?>
