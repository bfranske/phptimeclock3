<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<style>
    #userInfo{
        float:left;
        width:300px;
    }
    #userGroups{
        float:left;
        width:500px;
    }
</style>

<?php $userInfo = $userInfo['base'][0]; ?>
<div id="adminContent">
    <?php
        echo validation_errors();

        show_notices();
    ?>

    <?php
        echo anchor('admin/groups_view', 'Back to management');
    ?>

    <h3>View User <?php echo "$userInfo->username ($userInfo->first_name $userInfo->last_name)" ?></h3>

    <?php
        echo '<div id="userInfo">';
        echo '<h3>Info</h3>';
            echo form_open('admin/user_view?id=' . $userInfo->id);
                echo '<table>';
                    form_hidden('userID', $userInfo->id);
                    form_text('Username', 'username', $userInfo->username, true);
                    form_text('First Name', 'firstName', $userInfo->first_name, true);
                    form_text('Last Name', 'lastName', $userInfo->last_name, true);
                    form_text('Email', 'email', $userInfo->email, true);
                    form_checkbox('Enabled', 'enabled', 1, $userInfo->enabled ? true : false);

                    form_pass('New Password', 'newPass');
                    form_pass('Confirm', 'newPass2');

                    form_pass('PIN', 'PIN');
                    form_pass('Confirm', 'PIN2');

                    form_text('Custom ID', 'customID', $userInfo->custom_id);

                    form_submit('Update User Info');
                echo '</table>';
            echo form_close();
        echo '</div>';

        echo '<div id="userGroups">';
            echo '<h3>Permissions</h3>';
            echo '<table>';
                echo '<tr><th>Name</th><th>Permissions</th></tr>';
                foreach ($groups as $group){
                    extract($group);
                    $permissions = str_replace('|', ', ', $permissions);
                    $permissions = str_replace('not_', 'Not ', $permissions);
                    $permissions = str_replace('punch', 'Punch', $permissions);
                    $permissions = str_replace('runReports', 'Run Reports', $permissions);
                    $permissions = str_replace('editTime', 'Edit Time', $permissions);
                    echo "<tr><td>$name</td><td>$permissions</td></tr>";
                }
            echo '</table>';
        echo '</div>';
    ?>

</div>
