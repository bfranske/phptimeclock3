<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<?php
    $CI =& get_instance();

    echo '<span style="color:red">' . validation_errors() . '</span>';

    show_notices();
        echo '<h2>Edit Tags</h2>';

        echo '<p>Tags may be given when employees are punching.  They are useful for things such as project tracking.  Reports may be ran that are filtered by tags.</p>';
        echo 'Disabling tags prevents them from showing up in the autofill in the tags textbox when punching.<br />';
        echo 'You may rename tags that have been used.<br />';
        echo 'Merging tags takes all the tags of one tags and make them another tag.  This is useful for similarly typed tags.<br />';

        echo '<h4>Filter</h4>';
        
        echo form_open('admin/tags', 'name="editTagsForm"');
            table_open();
                if (! $this->session->userdata('tagsEnabledFilter')) $this->session->set_userdata('tagsEnabledFilter', 'Enabled');
                form_radio('All', 'enabledFilter', 'All', $this->session->userdata('tagsEnabledFilter') == 'All' ? 1 : 0, 2, true, 1, "onchange='ajaxFilter(\"All\")'");
                form_radio('Enabled', 'enabledFilter', 'Enabled', $this->session->userdata('tagsEnabledFilter') == 'Enabled' ? 1 : 0, false, true, 1, "onchange='ajaxFilter(\"Enabled\")'");
                form_radio('Disabled', 'enabledFilter', 'Disabled', $this->session->userdata('tagsEnabledFilter') == 'Disabled' ? 1 : 0, 3, true, 1, "onchange='ajaxFilter(\"Disabled\")'");
            table_close();
        // Form closed in AJAX

        echo '<div id="tagsForm">';

        echo '</div>'

?>
<script type="text/javascript">
//<![CDATA[
    function ajaxFilter(type)
    {
        $("#tagsForm").html("<img src='<?php echo $CI->config->item('base_url') ?>css/images/ajax-loader.gif' alt='AJAX Loader' />");
        $.ajax({
            url: "<?php echo BASE_URL ?>index.php/admin/ajax_tags/",
                data: "&enabledFilter=" + type,
                type: "POST",
            success: function(data) {
              $("#tagsForm").html(data);
            }
        });
    }

    $(document).ready(function(){
        ajaxFilter('<?php echo $this->session->userdata('tagsEnabledFilter') ? $this->session->userdata('tagsEnabledFilter') : 'Enabled'?>');
    });
</script>
