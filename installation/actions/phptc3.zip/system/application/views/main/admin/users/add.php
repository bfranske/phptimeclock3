<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php

?>
<div id="adminContent">
    <h3>Add User</h3>

    <?php 
        echo '<span style="color:red">' . validation_errors() . '</span>';

        if (count($_POST) AND $status == 'Success'){
            echo '<strong>User Added</strong>';
        }

        echo '<table>';
            echo form_open('admin/user_add', 'name="loginForm"');
                form_text('Username', 'username', set_value('username'));
                form_pass('Password', 'password', set_value('password'));
                form_pass('Confirm', 'password2');
                form_text('First Name', 'firstName', set_value('firstName'));
                form_text('Last Name', 'lastName', set_value('lastName'));
                form_text('Email', 'email', set_value('email'));
                echo '<tr><td>Group</td><td>';
                    echo '<select name="groupID">';
                        render_tree_select_group($tree['children'][0]);
                    echo '</select>';
                echo '</td></tr>';
                form_submit('Add User');
            echo form_close();
        echo '</table>';
    ?>
</div>

<script type="text/javascript">
    var frmvalidator = new Validator("loginForm");
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req", "Username is required");
    frmvalidator.addValidation("password","req", "Password is required");
    frmvalidator.addValidation("firstName","req", "First Name is required");
    frmvalidator.addValidation("lastName","req", "Last Name is required");

    function CheckForm(){
      var frm = document.forms["loginForm"];
  // First Name
      if(frm.password.value != frm.password2.value) {
        sfm_show_error_msg('The Password and verified password do not match!',frm.userpass);
        return false;
      }
    }

    frmvalidator.setAddnlValidationFunction("CheckForm");
</script>
