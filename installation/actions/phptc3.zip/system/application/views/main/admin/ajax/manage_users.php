<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
//echo form_open('admin/users_manage_do');
    $CI =& get_instance();

    $formUsers = array();

    echo '<tr><td colspan=5><strong>Manage Users</strong></td></tr>';

    echo '<tr><th><input type="checkbox" class="checkall"></th><th>Username</th><th>First Name</th><th>Last Name</th><th>Sys Admin?</th><th>Punch</th><th>Edit Time</th><th>Run Reports</th></tr>';
    $i = 1;
    foreach ($users->result() as $row){
//        dump($row);
        $formUsers[] = $row->user_id;
        $classString = ae_detect_ie() ? ($i ? "class='odd'" : "class='even'") : '';
        echo "<tr $classString>";
            echo "<td><input type='checkbox' value='$row->user_id' name='selectedUsers[]' class='selectedUsersCheck'></td>";
            echo '<td>'.anchor("admin/user_view/?id=$row->user_id", $row->username).'</td>'.
            '<td>'.$row->first_name.'</td>'.
            '<td>'.$row->last_name.'</td>';
            form_checkbox('', "sysAdmin[$row->user_id]", 1, ($row->sys_admin ? true : false), false, false, 1);
            echo form_select_permissions($row->user_id, $groupID) . '</tr>';
        $i = $i ? 0 : 1;
    }
    echo '<tr><td colspan=8><table><tr><td>With Selected:  </td>';
        form_hidden('groupID', $groupID);
        form_hidden('userIDs', implode(',', $formUsers));
        if ($groupID != 1)
            form_submit('Remove From Group', true, false, false);
            if ($CI->session->userdata('showDisabled')){
                form_submit('Enable', true, false, false, false, 2);
            }
            else{
                form_submit('Disable', true, false, false, false, 2);
            }
        echo '<td colspan=3 width=400><input type="submit" value="Save Permissions" name="SavePermissions" class="rightFloat"></td></tr>';

        echo $groupID == 1 ? '<tr><td colspan=3>Add to Group:<select name="newGroupID">': '<td colspan=3>Move to Group:<select name="newGroupID">';
            render_tree_select_group($tree['children'][0], false, 0, false);
        echo '</select></td>';
        form_submit(($groupID == 1 ? 'Add' : 'Move'), true, false, false, false);
    echo '</tr></table></td></tr>';
//echo form_close();
?>
<script type="text/javascript">
    $(function () { // this line makes sure this code runs on page load
	$('.checkall').click(function () {
		$('.selectedUsersCheck').attr('checked', this.checked);
//                $(this).parents().find(':checkbox').attr('checked', this.checked);
	});
    })
</script>