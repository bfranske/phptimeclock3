<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();

    $formUsers = array();

    echo '<tr><th colspan="5"><h3>Report Options</h3></th></tr>';

    echo '<tr><td colspan="5"><strong>Tags</strong></td></tr>';

    echo '<tr><td><table>';
        $maxCols = 6;
        $currentCol = 1;
        foreach ($tags->result() as $row){
            if ($currentCol == 1)
                echo '<tr>';
            form_checkbox('', 'selectedTags[]', $row->id, false, false, false);
            echo "<td>$row->name</td>";
            if ($currentCol == $maxCols){
                $currentCol = 1;
                echo '</tr>';
            }
            else {
                $currentCol++;
            }
        }
    echo '</table></td></tr>';

//    form_submit('Run Report', false, true, false, false, 1, "style='float:right'");
    echo "<tr><td colspan='10'><input type='button' value='Hide Options' onclick='hideOptions()'/></td></tr>";
?>

