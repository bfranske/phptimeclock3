<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<div id="accordion">
    <h3 <?php echo ! $this->session->userdata('activeAccordian') ? 'class="activeAccordian"' : '' ?>><a href="#">General</a></h3>
    <div>
    <?php
        $CI =& get_instance();

        echo '<span style="color:red">' . validation_errors() . '</span>';

        show_notices();

        echo form_open('admin/config');
            form_hidden('section', 'general');
            table_open();
        // Company Name
                form_text('Company Name', 'companyName', $CI->Config->item('companyName'), true, false, '', 'class="tooltip" title="Shows as page title in brower."');
        // Timezone
                echo '<tr class="tooltip" title="Timezone to show all times in."><td>Timezone </td><td>' . timezone_menu($CI->Config->item('timezone'), '', 'timezone') . '</td></tr>';

        // This is here to simplify updates to users of the hosted service
                if (strpos(BASE_URL, 'https://hosted.phptimeclock.com') === false){
        // SSL
                    echo "<tr class='tooltip' title='Use SSL (encypted connection).  Your server must be set up to use SSL, if not, this will break your installation!'><td>Use SSL?</td><td colspan='4'><input type='radio' name='useSSL'  value='1' ".($CI->Config->item('useSSL') ? 'checked="checked"' : '')." /><label>Yes</label>
                                 <input type='radio' name='useSSL' value='0' ".($CI->Config->item('useSSL') ? '' : 'checked="checked"')." /><label>No</label></td></tr>";
                }

    /*
     * Localization will be in 3.1
     */
    //    // Language
    //            echo '<tr><td>Language</td>';
    //            echo '<td><select name="language">';
    //                form_select('English US', 'en_US', false, $CI->Config->item('language') == 'en_us' ? 1 : '');
    //                form_select('English GB', 'en_GB', false, $CI->Config->item('language') == 'en_GB' ? 1 : '');
    //                form_select('Spanish', 'spanish', false, $CI->Config->item('language') == 'spanish' ? 1 : '');
    //                form_select('Portuguese', 'portuguese', false, $CI->Config->item('language') == 'portuguese' ? 1 : '');
    //                form_select('German', 'german', false, $CI->Config->item('language') == 'german' ? 1 : '');
    //                form_select('Estonian', 'estonian', false, $CI->Config->item('language') == 'estonian' ? 1 : '');
    //            echo '</select></td></tr>';

        // Group Select If Only 1
                echo '<tr class="tooltip" title="What to show for group on punchboard if selected/logged in user is allowed to punch into excactly 1 group."><td>Group Select If Only 1</td><td><select name="selectGroupDisplay">';
                    form_select('Always show', 'always', false, $CI->Config->item('selectGroupDisplay') == 'always' ? 1 : '');
                    form_select('Name only if 1', 'nameIfOne', false, $CI->Config->item('selectGroupDisplay') == 'nameIfOne' ? 1 : '');
                    form_select('Show nothing if 1', 'noneIfOne', false, $CI->Config->item('selectGroupDisplay') == 'noneIfOne' ? 1 : '');
                echo '</select></td></tr>';

        // Status Select Style
                echo '<tr class="tooltip" title="Use select box or buttons for choosing punch status."><td>Status Select Style: </td>';
                echo '<td><input name="selectStatusStyle" value="dropdown" type="radio" '.($CI->Config->item('selectStatusStyle') == 'dropdown' ? 'checked="checked"' : '').' /><label>Dropdown</label>
                          <input name="selectStatusStyle" value="buttons" type="radio" '.($CI->Config->item('selectStatusStyle') == 'buttons' ? 'checked="checked"' : '').' /><label>Buttons</label></td></tr>';

    //            form_radio('Dropdown', 'selectStatusStyle', 'dropdown', $CI->Config->item('selectStatusStyle') == 'dropdown' ? 1 : 0, false);
    //            form_radio('Buttons',  'selectStatusStyle', 'buttons', $CI->Config->item('selectStatusStyle')  == 'buttons' ? 1 : 0, 3);

        // Use Tags?
                echo '<tr class="tooltip" title="Tags are an optional input on punching.  Tags can a search parameter on reports."><td>Use Tags: </td>';
                echo '<td><input name="useTags" value="Yes" type="radio" '.($CI->Config->item('useTags') == 'Yes' ? 'checked="checked"' : '').' /><label>Yes</label>
                          <input name="useTags" value="No" type="radio" '.($CI->Config->item('useTags')  == 'No' ? 'checked="checked"' : '').' /><label>No</label></td></tr>';
        // Require Edit Reason?
                echo '<tr class="tooltip" title="Setting to yes requires edit reason to be given when adding/editing/removing punches."><td>Require Edit Reason: </td>';
                echo '<td><input name="requireEditReason" value="1" type="radio" '. ( $CI->Config->item('requireEditReason') ? 'checked="checked"' : '').' /><label>Yes</label>
                          <input name="requireEditReason" value="0"  type="radio" '.(!$CI->Config->item('requireEditReason') ? 'checked="checked"' : '').' /><label>No</label></td></tr>';

        // Date/Time Format?
    //            $dateFormats = array(
    //                array('MM/DD/YYYY', 'm/d/Y'),
    //                array('MM/DD/YY', 'm/d/y'),
    //                array('DD/MM/YYYY', 'd/m/Y'),
    //                array('DD/MM/YY', 'd/m/y'),
    //                array('YYYY/DD/MM', 'Y/d/m'),
    //                array('YY/DD/MM', 'y/d/m'),
    //                array('YYYY/MM/DD', 'Y/m/d'),
    //                array('YY/MM/DD', 'y/m/d')
    //            );

                $dateFormats = array(
                    'MM/DD/YYYY',
                    'MM/DD/YY',
                    'DD/MM/YYYY',
                    'DD/MM/YY',
                    'YYYY/DD/MM',
                    'YY/DD/MM',
                    'YYYY/MM/DD',
                    'YY/MM/DD',
                );
                echo '<tr  class="tooltip" title="System wide date format."><td colspan="5"><strong>Date/Time Format</strong></td></tr>';

                echo '<tr><td>Date: </td>';
                echo '<td><select name="dateFormat">';
                    foreach ($dateFormats as $format){
                        $convertedFormat = str_replace('YYYY', 'Y', $format);
                        $convertedFormat = str_replace('YY',   'y', $convertedFormat);
                        $convertedFormat = str_replace('MM',   'm', $convertedFormat);
                        $convertedFormat = str_replace('DD',   'd', $convertedFormat);
                        form_select("$format (" . date($convertedFormat, now()) . ')', $convertedFormat, '', $CI->Config->item('dateFormat') == $convertedFormat ? 1 : '');
                    }
                echo '</select></td></tr>';

                echo '<tr><td>Time: </td>';
                echo '<td><input name="timeFormat" value="12Hr" type="radio" '.($CI->Config->item('timeFormat') == '12Hr' ? 'checked="checked"' : '').' /><label>12Hr</label>
                          <input name="timeFormat" value="24Hr" type="radio" '.($CI->Config->item('timeFormat')  == '24Hr' ? 'checked="checked"' : '').' /><label>24Hr</label></td></tr>';

                table_close();

                table_open();
                form_text('Minimum Password Length:', 'minPasswordLength', $CI->Config->item('minPasswordLength'), true, 3, '', ' class="tooltip" title="Minumum character length of user passwords"');
            table_close();
            echo '<strong>Warning!</strong>  Setting minimum password length to less than 8 is generally a bad idea!';
            echo '<br /><br />';

                // Restrict IP Addresses
            table_open();
                echo '<tr class="tooltip" title="Access to your timeclock may be restricted to certain IP addresses.  This will allow ranges in the future.  Use this option with caution!"><td>Restrict IP Addresses? </td>';
                echo '<td><input name="restrictIPAddresses" value="1" type="radio" '.(strpos($CI->Config->item('restrictIPAddresses'), 'Yes') !== false ? 'checked="checked"' : '').' /><label>Yes</label>
                          <input name="restrictIPAddresses" value="0" type="radio" '.(strpos($CI->Config->item('restrictIPAddresses'), 'No') !== false ? 'checked="checked"' : '').' /><label>No</label></td></tr>';
    //            form_radio('Yes', 'restrictIPAddresses', '1', strpos($CI->Config->item('restrictIPAddresses'), 'Yes') !== false ? 1 : 0, false);
    //            form_radio('No',  'restrictIPAddresses', '0', strpos($CI->Config->item('restrictIPAddresses'), 'Yes') === false ? 1 : 0, false);
                if (strpos($CI->Config->item('restrictIPAddresses'), 'Yes') !== false){
                    $allowedIPAddresses = str_replace('Yes ', '', $CI->Config->item('restrictIPAddresses'));
                }
                else
                    $allowedIPAddresses = '';
                form_text('Allowed IP Addresses ', 'allowedIPAddresses', $allowedIPAddresses, true, false, '', ' class="tooltip" title="IP addresses to allow access to your timeclock, comma seprated."');
            table_close();
            echo 'Comma seperated.  Will be more flexible in the future.<br />
                    <strong>Warning:</strong>  Setting this to not include your current IP address may result in you not being able to access your Timeclock.<br />
                    <strong>*** You Have Been Warned!!! ***</strong>';
            table_open();
                form_submit('Update Config', true, true);
            table_close();
            echo form_close();
            ?></div>
            <h3 <?php echo $this->session->userdata('activeAccordian') == 'punchBoard' ? 'class="activeAccordian"' : '' ?>><a href="#">Punch Board</a></h3>
            <div><?php
            echo form_open('admin/config');

            form_hidden('section', 'punchBoard');
        // Punch Board
            echo '<h3>Punch Board</h3>';
            table_open();

        // Show Last Initial?
                echo '<tr class="tooltip" title="Show last initial/name on punchboard."><td>Last Names: </td>';
                echo '<td><input name="lastNameView" value="initial" type="radio" '.($CI->Config->item('lastNameView') == 'initial' ? 'checked="checked"' : '').' /><label>Initial</label>
                          <input name="lastNameView" value="name" type="radio" '.($CI->Config->item('lastNameView')  == 'name' ? 'checked="checked"' : '').' /><label>Name</label></td></tr>';
        // User Identifier
                echo '<tr><td><strong>User Identifier: </strong></td></tr>';

                echo '<tr class="tooltip" title="Show username/full name on punch form."><td>Punch Interface: </td>';
                echo '<td><input name="userIdentifier_punch" value="username" type="radio" '.($CI->Config->item('userIdentifier_punch') == 'username' ? 'checked="checked"' : '').' /><label>Username</label>
                          <input name="userIdentifier_punch" value="fullname" type="radio" '.($CI->Config->item('userIdentifier_punch')  == 'fullname' ? 'checked="checked"' : '').' /><label>Full Name</label></td></tr>';

                echo '<tr class="tooltip" title="Show username/full name on punch board."><td>In/Out Board: </td>';
                echo '<td><input name="userIdentifier_board" value="username" type="radio" '.($CI->Config->item('userIdentifier_board') == 'username' ? 'checked="checked"' : '').' /><label>Username</label>
                          <input name="userIdentifier_board" value="fullname" type="radio" '.($CI->Config->item('userIdentifier_board')  == 'fullname' ? 'checked="checked"' : '').' /><label>Full Name</label></td></tr>';

        // Punch Board Columns?
                echo '<tr><td colspan="5"><strong>Punch Board Columns</strong></td></tr>';

                echo '<tr class="tooltip" title="Show group column on punch board."><td>Group: </td>';
                echo '<td><input name="punchBoardGroup" value="Show" type="radio" '.($CI->Config->item('punchBoardGroup') == 'Show' ? 'checked="checked"' : '').' /><label>Show</label>
                          <input name="punchBoardGroup" value="Hide" type="radio" '.($CI->Config->item('punchBoardGroup')  == 'Hide' ? 'checked="checked"' : '').' /><label>Hide</label></td></tr>';

                echo '<tr class="tooltip" title="Show notes column on punch board."><td>Notes: </td>';
                echo '<td><input name="punchBoardNotes" value="Show" type="radio" '.($CI->Config->item('punchBoardNotes') == 'Show' ? 'checked="checked"' : '').' /><label>Show</label>
                          <input name="punchBoardNotes" value="Hide" type="radio" '.($CI->Config->item('punchBoardNotes')  == 'Hide' ? 'checked="checked"' : '').' /><label>Hide</label></td></tr>';

            table_close();
            table_open();
                form_label('Days to show back on punch board.');
                form_text('(0-31)', 'punchBoardDays', $CI->Config->item('punchBoardDays'), true, false, '', ' class="tooltip" title="Users with last punch being older than this may days will now show on punch board.  Settting to 0 will show only punches from current day."');
            table_close();

            table_open();
                form_submit('Update Config', true, true);
            table_close();
            echo form_close();
            ?>
          </div>
          <h3 <?php echo $this->session->userdata('activeAccordian') == 'other' ? 'class="activeAccordian"' : '' ?>><a href="#">Other</a></h3>
          <div> <?php
          echo form_open('admin/config');

          form_hidden('section', 'other');
        // Get images for punches?
            table_open();
            echo '<tr class="tooltip" title="You may have camera images associated with user punches.  Further setup is allowed if enabled.  Cameras may be set per group (explicitly).  Pulls images from a web address."><td>Get images for punches? </td>';
                echo '<td><input name="getPunchImages" value="1" type="radio" '.($CI->Config->item('getPunchImages') == '1' ? 'checked="checked"' : '').' /><label>Yes</label>
                          <input name="getPunchImages" value="0" type="radio" '.($CI->Config->item('getPunchImages')  == '0' ? 'checked="checked"' : '').' /><label>No</label></td></tr>';
            table_close();
            if ($CI->Config->item('getPunchImages')){
                echo anchor('admin/group_cameras', 'Edit camera sources');
            }

        // Developer Mode
            echo '<br />';
            echo '<strong>Developer Mode</strong> (Shows benchmark and some debugging info at the bottom of every page)';
            table_open();
                form_checkbox('Enable', 'developerMode', 1, $CI->Config->item('developerMode'));
            table_close();

            echo '<h3>API Configuration</h3>';
            echo '<strong>The API allows user punching using methods other than the web browser, such as via phone system, and the desktop/phone applications (comming soon).</strong>';
            table_open();
                echo '<tr><td>API Key:</td><td>'.$this->Config->item('APIKey').'</td></tr>';
            table_close();
            ?>
            <script type="text/javascript">

            function confirmReset()
            {
            var agree=confirm("Are you sure you want to reset your API Key?");
            if (agree)
            return true ;
            else
            return false ;
            }

            </script>
            <?php

            echo '<a href="'.BASE_URL.'index.php/admin/reset_api_key">Reset API Key</a><br />';

            table_open();
                echo '<tr><td>API Enabled: </td>';
                echo '<td><input name="apiEnabled" value="1" type="radio" '.($CI->Config->item('apiEnabled') == '1' ? 'checked="checked"' : '').' /><label>Yes</label>
                          <input name="apiEnabled" value="0" type="radio" '.($CI->Config->item('apiEnabled')  == '0' ? 'checked="checked"' : '').' /><label>No</label></td></tr>';
            table_close();

            table_open();
                form_submit('Update Config', true, true);
            table_close();
        echo form_close();

        echo form_close();
        
        echo '<h4>';
            echo anchor('admin/import', 'Import Existing Installation');
        echo '</h4>';

        echo '<h4>';
            echo anchor('admin/backup', 'Backup/Restore Installation');
        echo '</h4>';
        ?>
        </div>
</div>