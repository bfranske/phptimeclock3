<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    show_notices();

    echo form_open('admin/group_cameras');
        echo '<table id="myTable" class="everythingTable" cellpadding="0" cellspacing="0">';
            echo '<tr><td>';
                echo '<table>';
                    render_tree_list_group($tree, '', false);
                echo '</table>';
            echo '</td><td>';
                echo '<table>';
                global $groupTreeIDs;
                    foreach ($groupTreeIDs as $groupID){
                        echo "<tr><td height='26'><input type='text' name='groupCameras[$groupID]' value='{$cameraURLs[$groupID]}' size='100'/></td></tr>";
                    }
                echo '</table>';
           echo '</td></tr>';
           form_submit('Update');
        echo '</table>';
    echo form_close();

?>