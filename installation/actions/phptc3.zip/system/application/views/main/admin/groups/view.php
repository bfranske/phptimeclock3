<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<div id="adminContent">
    <h3>View Groups</h3>

    <?php
        $CI =& get_instance();

        if (ae_detect_ie()){
            $a_browser_data = browser_detection('full');

            if ( $a_browser_data[1] < 9 )
            {
                echo '<span style="color:red">
                    This page will not look right in Internet Explorer versions before 9 (currently in beta).
                    We <strong>STRONGLY</strong> recommend using another browser due to numerous unpatched security vulnerabilites, disregard for web standards, and rendering glitches found only in Internet Exploer.
                    '.anchor('dashboard/no_ie_support', 'Here').' is a list of fully supported browsers.<br />
                  </span>';
            }
        }

        echo '<span style="color:red">' . validation_errors() . '</span>';

        show_notices();

        echo '<strong>Total Number of groups: ' . $groups->num_rows() . '</strong><br /><br />';

        echo form_open('admin/groups_view');
//            echo '<table>';
                form_hidden('action', 'toggleDisabled');
                form_hidden('showDisabled', ! $CI->session->userdata('showDisabled'));
                form_submit('Show Only '. ($CI->session->userdata('showDisabled') ? 'Enabled' : 'Disabled') .' Users', false, false, false);
//            echo '</table>';
        echo form_close();
        if ($CI->Group->are_disabled_groups()){
            echo form_open('admin/groups_view');
                form_hidden('action', 'toggleDisabledGroups');
                form_hidden('showDisabledGroups', ! $CI->session->userdata('showDisabledGroups'));
                form_submit(($CI->session->userdata('showDisabledGroups') ? 'Hide' : 'Show') .' Disabled groups', false, false, false);
            echo form_close();
        }
        if (isset($tree['children'])){
            echo '<table id="myTable" class="everythingTable" cellpadding="0" cellspacing="0" width="935">';
                foreach ($tree['children'] as $child){
                    render_tree_list_group($tree['children'][0]/*, 'admin/group_view/'*/);
                }
            echo '</table>';
        }
        ?>
    <script type="text/javascript">
//<![CDATA[
        var rowOpen = false;

        var beenClickedAddSubGroup = new Array();
        function AddSubGroup(id, level){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddSubGroup[id]) == 'undefined'){
                    beenClickedAddSubGroup[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20" alt="" />';
                    content = '<tr id="AddSubGroup' + id + '"><td colspan="8">' + '<?php echo form_open('admin/groups_view'); ?>';
                        content += '<table border=0 cellpadding="0" cellspacing="0"><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table border=0 cellpadding="0" cellspacing="0" class="AddSubGroup">';
                                    content += '<tr><td>Name</td><td><input type="text" name="name" tabindex="1"/></td></tr>';
                                    content += '<input type="hidden" name="parentID" value="' + id + '" />';
                                    content += "<?php echo form_hidden('action', 'addGroup'); ?>";
                                    content += '<tr><td> </td><td><input type="submit" value="Add Group!" tabindex="2"/></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddSubGroup\", " + id + ")'/></td>";
                        content += '</tr></table>';
                    content += '<?php echo form_close(); ?>' + '</td></tr>';

                    $('#row' + id).after(content);
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddMoveGroup = new Array();
        function AddMoveGroup(id, level){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddMoveGroup[id]) == 'undefined'){
                    beenClickedAddMoveGroup[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddMoveGroup' + id + '"><td colspan="8">' + '<?php echo form_open('admin/groups_view'); ?>';
                        content += '<table border=0 cellpadding="0" cellspacing="0"><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table border=0 cellpadding="0" cellspacing="0" class="AddMoveGroup">';
                                    content += '<tr><td>New Parent Group</td><td>';
                                        content += '<select name="parentID">';
                                            content += '<?php echo render_tree_select_group($tree['children'][0], true)?>';
                                        content += '</select>';
                                    content += '</td></tr>';
                                    content += '<input type="hidden" name="groupID" value="' + id + '" />';
                                    content += "<?php echo form_hidden('action', 'moveGroup'); ?>";
                                    content += '<tr><td> </td><td><input type="submit" value="Move Group!" /></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddMoveGroup\", " + id + ")' /></td>";
                        content += '</tr></table>';
                    content += '<?php echo form_close(); ?>' + '</td></tr>';
                    $('#row' + id).after(content);
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddUser = new Array();
        function AddUser(id, level){
            if (rowOpen == false){
                rowOpen = true;

                if (typeof(beenClickedAddUser[id]) == 'undefined'){
                    beenClickedAddUser[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddUser' + id + '"><td colspan="8">' + '<?php echo form_open('admin/groups_view', 'name="addUser"'); ?>';
                        content += '<table border=0 cellpadding="0" cellspacing="0"><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table>';
                                    if (id != 1){
                                        content += '<tr><td>Add User to Group</td><td id="td_AddUser' + id + '">';
                                        content += '</td></tr>';
                                        content += '<tr><td></td><td>Only enabled users are selectable.</td></tr>';
                                        content += '<tr><td><strong>OR New User</strong></td></tr>';
                                    }
                                    <?php $minPasswordLength = $this->Config->item('minPasswordLength'); ?>
                                    content += "<?php form_text('Username', 'username', '', true, false, "tabindex='1'") ?>";
                                    content += "<?php form_pass('Password', 'password', '', true, "tabindex='2'", " class='tooltip' title='Passwords must be at least $minPasswordLength characters (changeable in config).'") ?>";
                                    content += "<?php form_pass('Confirm', 'password2', '', true, "tabindex='3'", " class='tooltip' title='Passwords must be at least $minPasswordLength characters (changeable in config).'") ?>";
                                    content += "<?php form_text('First Name', 'firstName', '', true, false, "tabindex='4'") ?>";
                                    content += "<?php form_text('Last Name', 'lastName', '', true, false, "tabindex='5'") ?>";
                                    content += "<?php form_text('Email', 'email', '', true, false, "tabindex='6'") ?>";
                                    content += "<?php form_text('Custom ID', 'customID', '', true, false, "tabindex='6'", '', "class='tooltip' title='Custom ID must be 4-15 numbers'") ?>";
                                    content += "<?php form_checkbox('System Admin', 'sysAdmin', '1')?>";
                                    content += '<input type="hidden" name="groupID" value="' + id + '" />';
                                    content += "<?php echo form_hidden('action', 'addUser'); ?>";
                                    content += '<tr><td> </td><td><input type="submit" value="Add User!" tabindex="8"/></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddUser\", " + id + ")' /></td>";
                        content += '</tr></table>';
                    content += '<?php echo form_close(); ?>' + '</td></tr>';

                    $('#row' + id).after(content);

                    tooltip();
                    
                    $.ajax({
                        url: "<?php echo $CI->config->item('base_url') ?>index.php/admin/ajax_user_select",
                        data: "&groupID=" + id,
                        type: "POST",
                        success: function(data) {
                          $("#td_AddUser" + id).html(data);
                        }
                      });
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddShowUsers = new Array();
        function AddShowUsers(id, level){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddShowUsers[id]) == 'undefined'){
                    beenClickedAddShowUsers[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddShowUsers' + id + '"><td colspan="8">' + '<?php echo form_open('admin/users_manage_do'); ?>';
                        content += '<table border=0 cellpadding="0" cellspacing="0"><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table id="table_ShowUsers' + id + '">';
                                    content += '<tr><td></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddShowUsers\", " + id + ")' /></td>";
                        content += '</tr></table>';
                    content += '<?php echo form_close(); ?>' + '</td></tr>';
                    $('#row' + id).after(content);

                    $("#table_ShowUsers" + id).ajaxStart(function() {
                        $("#table_ShowUsers" + id).html("<img src='<?php echo $CI->config->item('base_url') ?>css/images/ajax-loader.gif' alt=''/>");
                    });

                    $.ajax({
                        url: "<?php echo $CI->config->item('base_url') ?>index.php/admin/ajax_show_users",
                        data: "&groupID=" + id,
                        type: "POST",
                        success: function(data) {
                          $("#table_ShowUsers" + id).html(data);
//                          $("#adminContent").style.display = inline;
//                          $("#adminContent").style.display = inline-block;
                        }
                      });
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddDeleteGroupConfirm = new Array();
        function AddDeleteGroupConfirm(id, level){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddDeleteGroupConfirm[id]) == 'undefined'){
                    beenClickedAddDeleteGroupConfirm[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddDeleteGroupConfirm' + id + '"><td colspan="8">' + '<?php echo form_open('admin/groups_view'); ?>';
                        content += '<table><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table>';
                                    content += '<tr><td> </td><td><input type="submit" value="YES, I am SURE I want to delete this group!" /></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddDeleteGroupConfirm\", " + id + ")' /></td>";
                        content += '</tr></table>';

                        content += '<input type="hidden" name="groupID" value="' + id + '" />';
                        content += "<?php echo form_hidden('action', 'deleteGroup'); ?>";
                    content += '<?php echo form_close(); ?>' + '</td></tr>';
                    $('#row' + id).after(content);
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddDisableGroupConfirm = new Array();
        function AddDisableGroupConfirm(id, level){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddDisableGroupConfirm[id]) == 'undefined'){
                    beenClickedAddDisableGroupConfirm[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddDisableGroupConfirm' + id + '"><td colspan="8">' + '<?php echo form_open('admin/groups_view'); ?>';
                        content += '<table><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table>';
                                    content += '<tr><td> </td><td><input type="submit" value="YES, I am SURE I want to disable this group!" /></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddDisableGroupConfirm\", " + id + ")' /></td>";
                        content += '</tr></table>';

                        content += '<input type="hidden" name="groupID" value="' + id + '" />';
                        content += "<?php echo form_hidden('action', 'disableGroup'); ?>";
                    content += '<?php echo form_close(); ?>' + '</td></tr>';
                    $('#row' + id).after(content);
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddRunReports = new Array();
        function AddRunReports(id, level){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddRunReports[id]) == 'undefined'){
                    beenClickedAddRunReports[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddRunReports' + id + '"><td colspan="8">' + '<?php echo form_open('admin/run_reports', array('name' => 'runReports')); ?>';
                        content += '<table border="0" cellpadding="0" cellspacing="0"><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table id="table_RunReports' + id + '">';
                                content += '</table>';
                            content += '</td>';
                            content += '</tr><tr>';
                                content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddRunReports\", " + id + ")' /></td>";
                            content += '</tr>';
                        content += '</table>';

                        content += '<table id="table_ReportOptionsMain"  border="0" cellpadding="0" cellspacing="0">';
                            content += '<tr>';
                                content += '<td>' + spacerString + '</td>';
                                content += '<td>';
                                    content += '<table id="table_ReportOptions">';
                                    content += '</table>';
                                content += '</td>';
                            content += '</tr>';
                        content += '</table>';

                        content += '<table id="table_ReportAuditOptionsMain"  border="0" cellpadding="0" cellspacing="0">';
                            content += '<tr>';
                                content += '<td>' + spacerString + '</td>';
                                content += '<td>';
                                    content += '<table id="table_ReportAuditOptions">';
                                    content += '</table>';
                                content += '</td>';
                            content += '</tr>';
                        content += '</table>';
                        content += '<?php echo form_close(); ?>';

                    content += '</td></tr>';
                    $('#row' + id).after(content);

                    $("#table_RunReports" + id).ajaxStart(function() {
                        $("#table_RunReports" + id).html("<img src='<?php echo $CI->config->item('base_url') ?>css/images/ajax-loader.gif' />");
                    });

                    $.ajax({
                        url: "<?php echo $CI->config->item('base_url') ?>index.php/admin/ajax_run_reports",
                        data: "&reportsGroupID=" + id,
                        type: "POST",
                        success: function(data) {
                          $("#table_RunReports" + id).html(data);
//                          $("#adminContent").style.display = inline;
//                          $("#adminContent").style.display = inline-block;
                        }
                      });

                      $.ajax({
                        url: "<?php echo $CI->config->item('base_url') ?>index.php/admin/ajax_report_options",
                        data: "&reportsGroupID=" + id,
                        type: "POST",
                        success: function(data) {
                          $("#table_ReportOptions").html(data);
                        }
                      });

                      $.ajax({
                        url: "<?php echo $CI->config->item('base_url') ?>index.php/admin/ajax_audit_report_options",
                        data: "&reportsGroupID=" + id,
                        type: "POST",
                        success: function(data) {
                          $("#table_ReportAuditOptions").html(data);
                        }
                      });
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        var beenClickedAddRenameGroup = new Array();
        function AddRenameGroup(id, level, name){
            if (rowOpen == false){
                rowOpen = true;
                if (typeof(beenClickedAddRenameGroup[id]) == 'undefined'){
                    beenClickedAddRenameGroup[id] = 1;
                    spacerString = '<img src="' + '<?php echo $CI->config->item('base_url') ?>' + 'css/images/list_spacer.png" width=' + ((level + 1) * 30) + ' height="20"  alt="" />';
                    content = '<tr id="AddRenameGroup' + id + '"><td colspan="8">' + '<?php echo form_open('admin/groups_view'); ?>';
                        content += '<table border=0 cellpadding="0" cellspacing="0"><tr>';
                            content += '<td>' + spacerString + '</td>';
                            content += '<td>';
                                content += '<table class="AddRenameGroup">';
                                    content += '<input type="hidden" name="groupID" value="' + id + '" />';
                                    content += "<?php echo form_hidden('action', 'renameGroup'); ?>";
                                    content += '<tr><td><input type="text" name="newName" value="' + name + '" /></td></tr>';
                                    content += '<tr><td><input type="submit" value="Rename group" /></td></tr>';
                                content += '</table>';
                            content += '</td>';
                        content += '</tr><tr>';
                            content += "<td></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddRenameGroup\", " + id + ")' /></td>";
                        content += '</tr></table>';
                    content += '<?php echo form_close(); ?>' + '</td></tr>';
                    $('#row' + id).after(content);
                }
            }
            else {
                alert('You must close the open section before opening another!');
            }
        }

        function hideOptions(){
            $('#table_ReportOptionsMain').hide();
        }
        function showOptions(){
            $('#table_ReportOptionsMain').show();
        }

        function hideAuditOptions(){
            $('#table_ReportAuditOptionsMain').hide();
        }
        function showAuditOptions(){
            $('#table_ReportAuditOptionsMain').show();
        }

        function deleteRow(rowname, id){
            rowOpen = false;
            $('#' + rowname + id).remove();
            switch(rowname){
                case 'AddSubGroup':
                    beenClickedAddSubGroup[id] = undefined;
                    break;
                case 'AddMoveGroup':
                    beenClickedAddMoveGroup[id] = undefined;
                    break;
                case 'AddUser':
                    beenClickedAddUser[id] = undefined;
                    break;
                case 'AddShowUsers':
                    beenClickedAddShowUsers[id] = undefined;
                    break;
                case 'AddDeleteGroupConfirm':
                    beenClickedAddDeleteGroupConfirm[id] = undefined;
                    break;
                case 'AddDisableGroupConfirm':
                    beenClickedAddDisableGroupConfirm[id] = undefined;
                    break;
                case 'AddRunReports':
                    beenClickedAddRunReports[id] = undefined;
                    break;
                case 'AddEditTime':
                    beenClickedAddEditTime[id] = undefined;
                    break;
                case 'AddRenameGroup':
                    beenClickedAddRenameGroup[id] = undefined;
                    break;
                default:
                    break;
            }
        }

//                content += '<script type="text/javascript">';
//                    content += 'var frmvalidator = new Validator("addUser");';
//                    content += 'frmvalidator.EnableMsgsTogether();';
//
//                    content += 'frmvalidator.addValidation("username","req", "Username is required");';
//                    content += 'frmvalidator.addValidation("password","req", "Password is required");';
//                content += "script ";
//
//]]>
    </script>
    <?php
//        dump($tree);
    ?>
</div>
