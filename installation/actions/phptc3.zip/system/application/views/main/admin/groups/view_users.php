<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<h3>Users</h3>
<?php
    echo '<strong>Total Number of users in group: ' . $groupUsers->num_rows() . '</strong><br /><br />';
        echo '<table>';
            echo '<tr><th>ID</th><th>Username</th><th>First Name</th><th>Last Name</th></tr>';
            foreach ($groupUsers->result() as $row){
                echo '<tr><td>'.anchor("admin/user_view/?id=$row->id", $row->id).'</td>'.
                     '<td>'.anchor("admin/user_view/?id=$row->id", $row->username).'</td>'.
                     '<td'.anchor("admin/user_view/?id=$row->id", $row->first_name).'</td>'.
                     '<td>'.anchor("admin/user_view/?id=$row->id", $row->last_name).'</td></tr>';
            }
        echo '</table>';
?>