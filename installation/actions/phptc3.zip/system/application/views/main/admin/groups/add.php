<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<div id="adminContent">
    <h3>Add Group</h3>

    <?php
        echo '<span style="color:red">' . validation_errors() . '</span>';

        if (count($_POST) AND $status == 'Success'){
            echo '<strong>Group Added</strong>';
        }

        echo form_open('admin/group_add', 'name="groupAddForm"');
            echo '<table>';
                form_text('Name', 'name');
                ?> <tr><td>Parent Group</td><td><select name="parentID">
                    <?php
                        render_tree_select_group($groups);
                    ?>
                </select></td></tr> <?php
                form_submit('Add User');
            echo '</table>';
        echo form_close();
//        dump($groups);
    ?>

</div>

<script type="text/javascript">
    var frmvalidator = new Validator("groupAddForm");
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("name","req", "Group name is required");
</script>
