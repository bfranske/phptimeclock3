<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<h2>Configuration - Punch Types</h2>

<?php
    $CI =& get_instance();

    echo '<span style="color:red">' . validation_errors() . '</span>';

    show_notices();

    echo form_open('admin/punch_types');
        echo '<h3>Punch Types</h3>';
        table_open();
            echo '<tr><td>Delete?</td><td>Name</td><td>Type</td><td></td><td>Color</td><td>Order</td><td>Enabled?</td></tr>
                    ';
            $ids = '';
            $firstRow = true;
            foreach($punchTypes->result() as $index => $type){
                form_checkbox('', "selectedStatuses[]", $type->id, false, 2, false);
                form_text('', "names[$type->id]", $type->name, false);
                echo "<td><input type='radio' name='statuses[$type->id]'  value='1' " . ($type->status ? 'checked="checked"' : '') . " />In ";
                echo "<input type='radio' name='statuses[$type->id]' value='0' " . (!$type->status ? 'checked="checked"' : '') . " />Out </td>";
//                form_text('', "statuses[$type->id]", $type->status ? 'In' : 'Out', 0);
                echo "<td style='background:#$type->color' width='25'> </td>";
                    @$indexes[] = $index;
                form_text('', "colors[$type->id]", $type->color, false, false, "'id='colorSelector$index'", '', "class='tooltip' title='Drag around color selection, click color wheel in bottom right to update.'");
//                form_text('', "colors[$type->id]", $type->color, false);

                echo '<td>';
                    if ($firstRow == true){
                        echo '<div style="width:24px; height:22px; float:left;"> </div>';
                        $firstRow = false;
                    }
                    if ($index != 0)
                        echo "<input type='image' src='" . base_url(). "css/images/Arrow_Up_Button.png' name='StatusUp' value='$type->id' style='padding-right:2px' />";
                    if ($index != $punchTypes->num_rows() - 1)
                        echo "<input type='image' src='" . base_url(). "css/images/Arrow_Down_Button.png' name='StatusDown' value='$type->id' style='padding-right:2px' />";
                echo '</td>';
                form_checkbox('', "enabledStatuses[$type->id]", 1, ($type->enabled ? 1 : 0), 3, false);
                $ids .= "$type->id,";
                echo "
                     ";
            }
        table_close();
        form_hidden('ids', trimString($ids));

        table_open();
            form_submit('Delete Selected', true, 2);
            form_submit('Update Statuses', true, 3);
        table_close();
    echo form_close();

    echo form_open('admin/punch_types', 'name="newPunchTypeForm"');

        echo '<h3>Add Punch Type</h3>';
        echo table_open();
            echo '<tr><td>Name</td><td>Status</td><td>Color</td><td>Enabled?</td></tr>';
            form_text('', 'newName', set_value('newName'), 2);
            echo "<td><input type='radio' name='newStatus'  value='1'" . ($this->input->post('newStatus') == 1 ? 'checked="checked"' : '') . " />In ";
            echo "<input type='radio' name='newStatus' value='0' " . ($this->input->post('newStatus') == 0 ? 'checked="checked"' : '') . " />Out </td>";
            form_text('', "newColor", set_value('newColor'), false, false, "id='colorSelectorAdd'");
            @$indexes[] = 'Add';
            form_checkbox('', "newEnabled", 1, 1, 3, false);
            form_submit('Add New Status', true, true, false, false, 2);

            $ids = trimString($ids);
        table_close();
        form_hidden('ids', $ids);
    echo form_close();
    ?>
    <script type="text/javascript">
        var frmvalidator = new Validator("newPunchTypeForm");
        frmvalidator.EnableMsgsTogether();

        frmvalidator.addValidation("newName","req", "Punch type name is required");
        frmvalidator.addValidation("newColor","req", "Punch type color is required");
    </script>

    <script type="text/javascript" src="<?php echo $CI->config->item('base_url') ?>includes/js/colorPicker/colorpicker.js"></script>
    
    <script type="text/javascript">
        $('<?php foreach ($indexes as $i => $index) echo "#colorSelector$index" . ($i + 1 < count($indexes) ? ',' : '') ?>').ColorPicker({
                onSubmit: function(hsb, hex, rgb, el) {
                        $(el).val(hex);
                        $(el).ColorPickerHide();
                },
                onBeforeShow: function () {
                        $(this).ColorPickerSetColor(this.value);
                }
//                onChange: function (hsb, hex, rgb, el) {
//                        $(el).val(hex);
//                        $('#colorSelector').val(hex);
//                }

        })
        .bind('keyup', function(){
                $(this).ColorPickerSetColor(this.value);
        });


    </script>
<?php

?>
