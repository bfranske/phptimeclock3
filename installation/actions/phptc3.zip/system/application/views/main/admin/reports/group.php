<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $punchDateFormat = str_ireplace('/y', '', DATE_FORMAT);
    $punchDateFormat = str_ireplace('y/', '', $punchDateFormat);
    define('SHORT_DATE_FORMAT', $punchDateFormat);

    if (isset($groupScope)){
        switch ($groupScope){
            case 'all':
                $groupScopeText = 'All Groups';
                break;
            case 'children':
                $groupScopeText = "$groupName";
                if (count($groupUsers) > 1)
                    $groupScopeText .= " and Sub Groups";
                break;
            case 'explicit':
                $groupScopeText = "$groupName (not showing punches from child groups)";
                break;
            default:
                break;
        }
    }
    else {
        $groupScope = $groupScopeText = $reportsGroupID = $totalPunches = '';
    }

    echo "<h3>Group Summary Report - $groupScopeText</h3>";
    echo "<span style='color:#000; font-size:18px; font-weight:bold;'>{$startDate} To {$endDate}</span> ";

    $CI =& get_instance();
    $CI->benchmark->mark('output_start');

//    dump($tree);

//    if (isset($tree['children'])){
//        echo '<table id="myTable" class="everythingTable" cellpadding="0" cellspacing="0">';
//            echo '<tr><td>';
//                foreach ($tree['children'] as $child){
//                    render_tree_list_group($tree['children'][0], '', false);
//                }
//            echo '</td><td>';
//                echo '<table>';
//
//                echo '</table>';
//           echo '</td></tr>';
//        echo '</table>';
//    }

    define('ROUNDING_DIGITS', $CI->Config->item('report_roundingDigits'));
    define('DURATION_FORMAT', $CI->Config->item('report_durationFormat'));

    $enabledTotals = explode(',', $CI->Config->item('report_enabledTotals'));

//    echo "<a name='home'></a>";
//
//    echo "<h3>Group Summary Report - $groupScopeText</h3>";

    if (!isset($users)){
        echo '<h3>No users selected or no punches found for date range (there may or may not be punches you have permission to view)</h3>';
    }
    else {
        show_notices();

        echo validation_errors();

// Initialize arrays so all statuses get populated on parent groups, and to prevent use of @
        $groupOvertime = array();
        $groupHours = array();
        $reportGroupIDs = $CI->group->get_children($reportsGroupID);
        foreach ($reportGroupIDs as $child){
            $groupTotalHours[$child] = '';
            $groupHours[$child] = '';
            $groupOvertime[$child] = '';
            foreach ($statuses as $id => $info){
                $groupStatuses[$child][$info['id']] = 0;
                $overtimeStatuses[$child][$info['id']] = 0;
            }
        }
        foreach ($users as $index => $user){
            $punchTable = array();
            $statusesTime = array();
            $punches = $user;

            if (isset($usernames)){
                $username = $usernames[$index];
                $fullName = $fullNames[$index];
            }
            else {
                $result = $CI->db->get_where('users', array('id' => $index));
                $result = $result->result();
                $username = $result[0]->username;
                $fullName = $result[0]->first_name . ' ' . $result[0]->last_name;
            }

            foreach ($punches as $punch){
                extract($punch);

                $spanStr = "<span style='color:#{$punchColors[$status_name]}'>";
                $dateText = date(DATE_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                $timeText = date(TIME_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                if ($duration !== NULL){
                    $duration = number_format($duration / 3600, ROUNDING_DIGITS);
                }
                else {
                    $duration = number_format((now() - strtotime($date_time)) / 3600, ROUNDING_DIGITS) . ' (Now)' ;
                }
                $punchTable[$dateText][] =
                array('id' => $id,
                      'userID' => $user_id,
                      'dateText' => $dateText,
                      'timeText' => $timeText,
                      'time' => $spanStr . $timeText . '</span>',
                      'duration' => $duration,
                      'statusName' => "$spanStr $status_name </span>",
                      'statusNameText' => $status_name,
                      'status' => trim($status),
                      'punchTypeID' => $punch_type_id,
                      'groupID' => $group_id,
                      'groupName' => $group_name,
                      'notes' => $notes,
                      'tags' => $tags,
                      'approved' => $approved,
                      'approved_by' => $approved_by,
                      'auditIDs' => $audit_ids);
            }

            $totalTime = 0;

            $groups = $ids = array();
            $i = 0;

            $weekHours = $dayTime = 0;
            
            $weekMinus =  + (7 - $CI->Config->item('report_weekStartOffset'));
            $startDOW = date('w', (strtotime($startDate)));
            $dayOffset = $CI->Config->item('report_weekStartOffset');
            $weekOTStartDate = strtotime($startDate) + ($dayOffset - $startDOW)*24*3600;
            if (strtotime($startDate) - $weekMinus*24*3600 < strtotime($startDate) - $startDOW*24*3600){
                $weekOTStartDate = strtotime($startDate) - 7*24*3600 + ($dayOffset - $startDOW)*24*3600;
            }
            $currentEnd = $weekOTStartDate + 6*24*3600;

            foreach ($punchTable as $date => $punches){
                $dayOvertimeStatuses = array();
                if ($this->Config->item('report_showOvertime') == 'week'){
                    $startDOW = date('w', (strtotime($startDate)));
                    $dayOffset = $CI->Config->item('report_weekStartOffset');
                    if ($currentEnd < strtotime($date)){
                        $weekMinus =  + (7 - $CI->Config->item('report_weekStartOffset'));
                        $startDOW = date('w', (strtotime($date)));
                        $dayOffset = $CI->Config->item('report_weekStartOffset');
                        $weekOTStartDate = strtotime($date) + ($dayOffset - $startDOW)*24*3600;

                        $currentEnd = $weekOTStartDate + 6*24*3600;

                        $weekHours = 0;
                    }
                }

                $dayStatusesTime = array();
                $dayHours = 0;
                $dayTime = 0;
                foreach ($punches as $punch){
                    extract($punch);
//dump($punch);
                    if (in_array($groupID, $reportGroupIDs)){
                        $groupStatuses[$groupID][$punchTypeID] += $duration;
//                        dump($groupID);
//                        dump($reportGroupIDs);
                    }
                    else {
                        
                    }

                    if ($status){
                        if (in_array($groupID, $reportGroupIDs)){
                            $groupTotalHours[$groupID] += $duration;
                        }
                        $dayTime += $duration;
                        if ($this->Config->item('report_showOvertime') == 'week'){
                            $wasOnOvertime = false;
                            if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                $wasOnOvertime = true;
                            }
                            $weekHours += $duration;
                            if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                if ($wasOnOvertime){
                                    $groupTotalHours[$groupID] -= $duration;
                                    $overtimeStatuses[$groupID][$punchTypeID] += $duration;
                                    $groupOvertime[$groupID] += $duration;
                                }
                                else {
                                    if (in_array($groupID, $reportGroupIDs)){
                                        $groupTotalHours[$groupID] -= $weekHours - $this->Config->item('report_OTperWeekHours');
                                        $overtimeStatuses[$groupID][$punchTypeID] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                        $groupOvertime[$groupID] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                    }
                                }
                            }
                        }
                        else if ($this->Config->item('report_showOvertime') == 'day' AND strtotime($startDate) <= strtotime($date)){
                            $wasOnOvertime = false;
                            if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                $wasOnOvertime = true;
                            }
                            $dayHours += $duration;
                            if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                if ($wasOnOvertime){
                                    $groupTotalHours[$groupID] -= $duration;
                                    $overtimeStatuses[$groupID][$punchTypeID] += $duration;
                                    $groupOvertime[$groupID] += $duration;
                                }
                                else {
                                    $groupTotalHours[$groupID] -= $dayHours - $this->Config->item('report_OTperDayHours');
                                    $overtimeStatuses[$groupID][$punchTypeID] += $dayHours - $this->Config->item('report_OTperDayHours');
                                    $groupOvertime[$groupID] += $dayHours - $this->Config->item('report_OTperDayHours');
                                }
                            }
                        }
                    }

                    $dayOfWeek = date('l', strtotime($date));
                }

                if (strtotime($startDate) <= strtotime($date)){
                    $totalTime += $dayTime;
                    if (in_array($groupID, $reportGroupIDs)){
                        $groupHours[$groupID] += $dayTime;
                    }
                }

                if ($this->Config->item('report_showOvertime') == 'day' AND $dayTime > $this->Config->item('report_OTperDayHours')){
                    $userOvertime += $dayTime - $this->Config->item('report_OTperDayHours');
                }
            }
            if ($this->Config->item('report_showOvertime') == 'week'){
                $weekHours = 0;
            }
        }

        $originalGroupTotalHours = $groupTotalHours;
        $originalGroupStatuses = $groupStatuses;
        $originalGroupOT = $groupOvertime;
        $originalOTStatuses = $overtimeStatuses;
        $enabledTotals = explode(',', $CI->Config->item('report_enabledTotals'));

            echo '<table id="myTable" class="everythingTable" cellpadding="0" cellspacing="0">';
                echo '<tr><td>';
                    echo '<table>';
                        render_tree_list_group($tree, '', false);
                    echo '</table>';
                echo '</td><td>';
                    echo '<table>';
                    global $groupTreeIDs;
                        foreach ($groupTreeIDs as $groupID){
                            if (isset($groupTotalHours[$groupID])){
                                foreach ($CI->group->get_children($groupID) as $child){
                                    if ($child != $groupID){
                                        $groupTotalHours[$groupID] += $originalGroupTotalHours[$child];
                                        $groupOvertime[$groupID] += $originalGroupOT[$child];

                                        foreach ($originalGroupStatuses[$child] as $status => $hours){
                                            $groupStatuses[$groupID][$status] += $originalGroupStatuses[$child][$status];
                                            $overtimeStatuses[$groupID][$status] += $originalOTStatuses[$child][$status];
                                        }
                                    }
                                }
                                echo "<tr><td height='23'>";
//                                    echo '<table><tr>';
                                        $groupOTString = $groupOvertime[$groupID] ? "(+".(@number_format($groupOvertime[$groupID], ROUNDING_DIGITS))." OT)" : '';
                                        echo "<strong>{$groupTotalHours[$groupID]} $groupOTString</strong></td>";
                                        if (isset($originalGroupStatuses[$child])){
                                            foreach ($originalGroupStatuses[$child] as $status => $hours){
                                                if (in_array($status, $enabledTotals)){
                                                    $statusName = $statuses[$status]['name'];
                                                    $statusColor = $statuses[$status]['color'];
                                                    $groupStatuses[$groupID][$status] -= @$overtimeStatuses[$groupID][$status];
                                                    $OTString = @$overtimeStatuses[$groupID][$status] ? "(+".(@number_format($overtimeStatuses[$groupID][$status], ROUNDING_DIGITS))." OT)" : '';
                                                    if ($groupStatuses[$groupID][$status])
                                                        echo "<td><span style='color:#$statusColor'>$statusName " . @$groupStatuses[$groupID][$status]." $OTString</span></td>";
                                                    else
                                                        echo "<td style='padding:0px'></td>";
                                                }
                                            }
                                        }
//                                    echo '</tr></table>';
                                echo "</td></tr>";
                                @$totalRows[] = $groupID;
                            }
                        }
                    echo '</table>';
               echo '</td></tr>';
            echo '</table>';


//        echo 'grpids';
//        dump($groupTreeIDs);
//        dump(@$totalRows);
//        echo 'grptotalhours';
//        dump($groupTotalHours);
//        dump($groupStatuses);
//        dump("****OT*****");
//        dump(@$overtimeStatuses);

//        if (count($ids) OR isset($noPermissionNeedsApproved)){
//            if ($CI->Permissions->has_permission($groupID, 'editTime') AND count($ids)){
////                echo '<br />';
//                echo form_open('admin/approve_time_do');
//                    form_hidden('ids', implode(',', $ids));
//                    form_hidden('groups', implode(',', $groups));
//                    form_hidden('reportsGroupID', $reportsGroupID);
//                    echo '<span style="float:right; color:red">';
//                        if (isset($noPermissionNeedsApproved))
//                            echo 'This report contains punches that have not been approved, you may approve the ones that you have permission to. ';
//                        else
//                            echo 'This report contains punches that have not been approved. ';
//                        form_submit('Approve Punches', false, false, false);
//                    echo '</span>';
//                echo form_close();
//            }
//            else {
//                echo '<span style="float:right; color:red">';
//                    echo 'This report contains punches that have not been approved, please contact a supervisor to get these approved. ';
//                echo '</span>';
//            }
//        }
//        else {
//            echo '<span style="float:right; color:green">';
//                echo 'All punches on this report have been approved. ';
//            echo '</span>';
//        }

        $CI->benchmark->mark('output_end');
    }

    echo "<span class='noPrint'>";
        if (isset($cantViewPunches) AND $cantViewPunches){
            echo '<h4>The report scope includes groups you do not have permission to view.  Users may or may not have punches from groups you do not have permission to view</h4>';
        }
        if ($groupScope != 'all' AND (! (($reportsGroupID == 1) AND ($groupScope == 'all' OR $groupScope == 'children')))){
            echo '<h4>This is not an all inclusive report, users may or may not have punches in other groups</h4>';
        }
    echo '</span>';

    echo '<span style="color:#8c9297" id="punchStats" class="noPrint">';
        echo "Total punches:  $totalPunches. <br />";
        echo 'Report fetched in ' . number_format($CI->benchmark->elapsed_time('report_start', 'report_end'), 4) . '<br />';
        echo 'Page generated in ' . number_format($CI->benchmark->elapsed_time('output_start', 'output_end'), 4) . '<br />';
    echo '</span>';
?>
