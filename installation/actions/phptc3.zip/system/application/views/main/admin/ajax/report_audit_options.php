<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();

    $formUsers = array();

    echo '<tr><th colspan="5"><h3>Audit Report Options</h3></th></tr>';

    echo "<tr>";
        echo "<tr><td></td><td>username</td></tr>";
    echo "</tr>";
    form_checkbox('Add', 'auditTypes[]', 'add', true);
    form_checkbox('Edit', 'auditTypes[]', 'edit', true);
    form_checkbox('Delete', 'auditTypes[]', 'delete', true);

    echo "<tr><td></td><td><input type='submit' name='reportType' value='Audit Report' style='float:right'></td></td>";
    echo "<tr><td colspan='10'><input type='button' value='Hide Options' onclick='hideAuditOptions()'/></td></tr>";
?>

