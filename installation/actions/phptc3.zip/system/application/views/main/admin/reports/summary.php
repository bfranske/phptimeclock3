<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $punchDateFormat = str_ireplace('/y', '', DATE_FORMAT);
    $punchDateFormat = str_ireplace('y/', '', $punchDateFormat);
    define('SHORT_DATE_FORMAT', $punchDateFormat);
    
    if (isset($groupScope)){
        switch ($groupScope){
            case 'all':
                $groupScopeText = 'All Groups';
                break;
            case 'children':
                $groupScopeText = "$groupName";
                if (count($groupUsers) > 1)
                    $groupScopeText .= " and Sub Groups";
                break;
            case 'explicit':
                $groupScopeText = "$groupName (not showing punches from child groups)";
                break;
            default:
                break;
        }
    }
    else {
        $groupScope = $groupScopeText = $reportsGroupID = $totalPunches = '';
    }

    $CI =& get_instance();
    $CI->benchmark->mark('output_start');

    define('ROUNDING_DIGITS', $CI->Config->item('report_roundingDigits'));
    define('DURATION_FORMAT', $CI->Config->item('report_durationFormat'));

    $enabledTotals = explode(',', $CI->Config->item('report_enabledTotals'));

    echo "<a name='home'></a>";

    echo "<h3>Hours Summary Report - $groupScopeText</h3>";

    if (!isset($users)){
        echo '<h3>No users selected or no punches found for date range (there may or may not be punches you have permission to view)</h3>';
    }
    else {
        show_notices();

        echo validation_errors();

        $groups = $ids = array();
        foreach ($users as $index => $user){
            $punchTable = array();
            $statusesTime = array();
            $punches = $user;
            $userGroupTimes = array();
            $userGroupOTTimes = array();
            $totalIn = array();

            if (isset($usernames)){
                $username = $usernames[$index];
                $fullName = $fullNames[$index];
            }
            else {
                $result = $CI->db->get_where('users', array('id' => $index));
                $result = $result->result();
                $username = $result[0]->username;
                $fullName = $result[0]->first_name . ' ' . $result[0]->last_name;
            }

            echo "<a name='$username'></a>";
            echo "<span style='color:#00C; font-size:28px; font-weight:bold;'>$username ($fullName)</span> ";
            echo "<span style='color:#000; font-size:14px; font-weight:bold;'>{$startDate} To {$endDate}</span> ";
            echo '<a href="#home" class="backToTop">Back to Top</a>';

            $userUsedStatuses = array();
            foreach ($punches as $punch){
                extract($punch);

                if (! in_array($status_name, $userUsedStatuses)){
                    $userUsedStatuses[] = $status_name;
                }
//dump($punch);
                $spanStr = "<span style='color:#{$punchColors[$status_name]}'>";
                $dateText = date(DATE_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                $timeText = date(TIME_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                if ($duration !== NULL){
                    $duration = number_format($duration / 3600, ROUNDING_DIGITS);
                }
                else {
                    $duration = number_format((now() - strtotime($date_time)) / 3600, ROUNDING_DIGITS) . ' (Now)' ;
                }
                $punchTable[$dateText][] =
                array('id' => $id,
                      'userID' => $user_id,
                      'dateText' => $dateText,
                      'timeText' => $timeText,
                      'time' => $spanStr . $timeText . '</span>',
                      'duration' => $duration,
                      'statusName' => "$spanStr $status_name </span>",
                      'statusNameText' => $status_name,
                      'status' => trim($status),
                      'punchTypeID' => $punch_type_id,
                      'groupID' => $group_id,
                      'groupName' => $group_name,
                      'notes' => $notes,
                      'tags' => $tags,
                      'approved' => $approved,
                      'approved_by' => $approved_by,
                      'auditIDs' => $audit_ids);
                }
//dump($punchTable);
            $totalTime = 0;

            $i = 0;
            
            $userOvertime = $weekHours = $dayTime = 0;
            $overtimeStatuses = array();
            $weekMinus =  + (7 - $CI->Config->item('report_weekStartOffset'));
            $startDOW = date('w', (strtotime($startDate)));
            $dayOffset = $CI->Config->item('report_weekStartOffset');
            $weekOTStartDate = strtotime($startDate) + ($dayOffset - $startDOW)*24*3600;
            if (strtotime($startDate) - $weekMinus*24*3600 < strtotime($startDate) - $startDOW*24*3600){
                $weekOTStartDate = strtotime($startDate) - 7*24*3600 + ($dayOffset - $startDOW)*24*3600;
            }
            $currentEnd = $weekOTStartDate + 6*24*3600;
//            dump($punchTable);
//            die();
            echo "<table class='everythingTable'>";
            foreach ($punchTable as $date => $punches){
                $dayOvertimeStatuses = array();
                if ($this->Config->item('report_showOvertime') == 'week'){
                    $startDOW = date('w', (strtotime($startDate)));
                    $dayOffset = $CI->Config->item('report_weekStartOffset');
                    if ($currentEnd < strtotime($date)){
                        echo '<tr><td><hr></td></tr>';
                        $weekMinus =  + (7 - $CI->Config->item('report_weekStartOffset'));
                        $startDOW = date('w', (strtotime($date)));
                        $dayOffset = $CI->Config->item('report_weekStartOffset');
                        $weekOTStartDate = strtotime($date) + ($dayOffset - $startDOW)*24*3600;
//                        $weekOTStartDate = strtotime($date) - (date('w', strtotime($date) + (7 - $CI->Config->item('report_weekStartOffset'))) * 24 * 3600) + $CI->Config->item('report_weekStartOffset') *3600*24;
                        $currentEnd = $weekOTStartDate + 6*24*3600;
                        if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                            $userOvertime += $weekHours - $this->Config->item('report_OTperWeekHours');
                        }
                        $weekHours = 0;
                    }
                }
                
                    $dayStatusesTime = array();
                    $dayHours = 0;
                    $dayTime = 0;
                    foreach ($punches as $punch){
                        extract($punch);
                        @$userGroupTimes[$groupName][$statusNameText] += $duration;
                        
                        if ($status){
                            @$totalIn[$groupName] += $duration;
                            
                            $dayTime += $duration;
                            if ($this->Config->item('report_showOvertime') == 'week'){
                                $wasOnOvertime = false;
                                if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                    $wasOnOvertime = true;
                                }
                                $weekHours += $duration;
                                if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                    if ($wasOnOvertime){
                                        @$overtimeStatuses[$statusNameText] += $duration;
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $duration;
                                    }
                                    else {
                                        @$overtimeStatuses[$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                    }
                                }
                            }
                            else if ($this->Config->item('report_showOvertime') == 'day'){
                                $wasOnOvertime = false;
                                if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                    $wasOnOvertime = true;
                                }
                                $dayHours += $duration;
                                if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                    if ($wasOnOvertime){
                                        @$dayOvertimeStatuses[$statusNameText] += $duration;
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $duration;
                                    }
                                    else {
                                        @$dayOvertimeStatuses[$statusNameText] += $dayHours - $this->Config->item('report_OTperDayHours');
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                    }
                                }
                            }
                        }
//dump($punch);  if ($this->Config->item('report_showOvertime') == 'day'
                        if (strtotime($startDate) <= strtotime($date)){
                            if (in_array($punchTypeID, $enabledTotals)){
                                @$dayStatusesTime[$statusNameText] += $duration;
                                @$statusesTime[$statusNameText] += $duration;
                            }
                        }

                /*
                 * Permisssion
                 */
                        if (strtotime($startDate) <= strtotime($date)){
                            if ($CI->Permissions->has_permission($groupID, 'editTime')){
                                if (! $approved){
                                    $ids[] = $id;
                                    $groups[] = $groupID;
                                }
                            }
                            else {
                                if (! $approved)
                                    $noPermissionNeedsApproved = true;
                                if ($showEditButtons){
                                    echo '<td></td><td></td><td></td></tr>';
                                }
                            }
                        }

                        $dayOfWeek = date('l', strtotime($date));
                    }

                    if (strtotime($startDate) <= strtotime($date)){
                        $totalTime += $dayTime;
                    }

                    if ($this->Config->item('report_showOvertime') == 'day' AND $dayTime > $this->Config->item('report_OTperDayHours')){
                        $userOvertime += $dayTime - $this->Config->item('report_OTperDayHours');
                    }

                    $dayHours = number_format($dayTime, ROUNDING_DIGITS);
                    if (strtotime($startDate) <= strtotime($date)){
                        echo "<tr><td colspan='9'>";
                            echo "<b>".date('D ' . SHORT_DATE_FORMAT, strtotime($date))." Hours $dayHours | </b>";
    //                        echo "<b>Statuses for day</b> ";
                                $statusesString = '';
                                foreach ($dayStatusesTime as $status => $time){
                                    $overtimeString = isset($dayOvertimeStatuses[$status]) ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($dayOvertimeStatuses[$status], ROUNDING_DIGITS) : duration_to_time(number_format($dayOvertimeStatuses[$status], ROUNDING_DIGITS)))." OT)" : '';
                                    if (isset($dayOvertimeStatuses[$status])) $time -= $dayOvertimeStatuses[$status];
                                    $spanStr = "<span style='color:#{$punchColors[$status]}'>";
                                    $time = DURATION_FORMAT == 'decimal' ? number_format($time, ROUNDING_DIGITS) : duration_to_time(number_format($time, ROUNDING_DIGITS));
                                    $statusesString .= "$spanStr $status: $time $overtimeString</span>, ";
                                }
                                echo trimString($statusesString, 2);
                        echo "</td></tr>";
                    
                    }

                }
                echo "</table>";
                if ($this->Config->item('report_showOvertime') == 'week'){
                    if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                        $userOvertime += $weekHours - $this->Config->item('report_OTperWeekHours');
                    }
                    $weekHours = 0;
                }

            $totalHours = $totalTime;
            if ($userOvertime)
                $totalHours -= $userOvertime;
            $overtimeString = $userOvertime ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($userOvertime, ROUNDING_DIGITS) : duration_to_time(number_format($userOvertime, ROUNDING_DIGITS)))." Overtime)" : '';
            $totalTime -= $userOvertime;
            $totalHours = DURATION_FORMAT == 'decimal' ? number_format($totalTime, ROUNDING_DIGITS) : duration_to_time(number_format($totalTime, ROUNDING_DIGITS));
            echo "<h3>Total Hours $totalHours $overtimeString</h3>";

            echo '<div style="float:left">';
                echo "<b>Statuses for $fullName: </b> ";
                $statusesString = '';

                foreach ($statusesTime as $status => $time){
                    $spanStr = "<span style='color:#{$punchColors[$status]}'>";
                    $overtimeString = isset($overtimeStatuses[$status]) ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($overtimeStatuses[$status], ROUNDING_DIGITS) : duration_to_time(number_format($overtimeStatuses[$status], ROUNDING_DIGITS)))." OT)" : '';
                    if (isset($overtimeStatuses[$status])) $time -= $overtimeStatuses[$status];
                    $time = DURATION_FORMAT == 'decimal' ? number_format($time, ROUNDING_DIGITS) : duration_to_time(number_format($time, ROUNDING_DIGITS));
                    $statusesString .= "$spanStr $status:  $time $overtimeString</span>, ";
                }
                echo trimString($statusesString);
                echo '<br />';
//                dump($overtimeStatuses);
            echo '</div>';

            echo '<div style="clear:both"> </div>';
//            dump($userGroupTimes);
//            dump($userGroupOTTimes);
//            dump($userUsedStatuses);

            if ($CI->Config->item('report_showGroupBreakdown')){
                $groupStatusesOrder = array();
                echo '<table class="everythingTable">';
                    echo '<tr><th></td>';
                        foreach ($statuses->result() as $status){
                            if ($status->enabled AND in_array($status->name, $userUsedStatuses)){
                                $groupStatusesOrder[] = $status->name;
                                echo "<th><span style='color:#$status->color'>$status->name</span></th>";
                            }
                        }
                        echo "<th>Total In</th>";
                    echo '</tr>';
                    foreach ($userGroupTimes as $groupName => $groupTimes){
                        echo '<tr>';
                            echo "<td><strong>$groupName</strong></td>";
                            foreach ($groupStatusesOrder as $statusName){
                                $ot = @$userGroupOTTimes[$groupName][$statusName];
                                $actualTime = @$groupTimes[$statusName] - $ot;
                                echo @"<td><span style='color:#{$punchColors[$statusName]}'>$actualTime".($ot ? "(+$ot OT)" : '')."</span></td>";
                            }
                            $totalTime = isset($totalIn[$groupName]) ? $totalIn[$groupName] : 0;
                            echo "<th>$totalTime</th>";
                        echo '</tr>';
                    }
                echo '</table>';
            }

            echo '<br /><hr />';

            echo '<div style="clear:both"> </div>';
        }
//dump($ids);
        if (count($ids) OR isset($noPermissionNeedsApproved)){
            if ($CI->Permissions->has_permission($groupID, 'editTime') AND count($ids)){
                echo '<br />';
                echo form_open('admin/approve_time_do');
                    form_hidden('ids', implode(',', $ids));
                    form_hidden('groups', implode(',', $groups));
                    form_hidden('reportsGroupID', $reportsGroupID);
                    echo '<span style="float:right; color:red">';
                        if (isset($noPermissionNeedsApproved))
                            echo 'This report contains punches that have not been approved, you may approve the ones that you have permission to. ';
                        else
                            echo 'This report contains punches that have not been approved. ';
                        form_submit('Approve Punches', false, false, false);
                    echo '</span>';
                echo form_close();
            }
            else {
                echo '<span style="float:right; color:red">';
                    echo 'This report contains punches that have not been approved, please contact a supervisor to get these approved. ';
                echo '</span>';
            }
        }
        else {
            echo '<span style="float:right; color:green">';
                echo 'All punches on this report have been approved. ';
            echo '</span>';
        }

        $CI->benchmark->mark('output_end');
    }

    echo "<span class='noPrint'>";
        if (isset($cantViewPunches) AND $cantViewPunches){
            echo '<h4>The report scope includes groups you do not have permission to view.  Users may or may not have punches from groups you do not have permission to view</h4>';
        }
        if ($groupScope != 'all' AND (! (($reportsGroupID == 1) AND ($groupScope == 'all' OR $groupScope == 'children')))){
            echo '<h4>This is not an all inclusive report, users may or may not have punches in other groups</h4>';
        }
    echo '</span>';

    echo '<span style="color:#8c9297" id="punchStats" class="noPrint">';
        echo "Total punches:  $totalPunches. <br />";
        echo 'Report fetched in ' . number_format($CI->benchmark->elapsed_time('report_start', 'report_end'), 4) . '<br />';
        echo 'Page generated in ' . number_format($CI->benchmark->elapsed_time('output_start', 'output_end'), 4) . '<br />';
    echo '</span>';
?>
