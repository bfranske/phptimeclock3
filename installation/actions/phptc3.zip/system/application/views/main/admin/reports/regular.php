<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>
<?php
    
?>
<?php
    if (isset($groupScope)){
        switch ($groupScope){
            case 'all':
                $groupScopeText = 'All Groups';
                break;
            case 'children':
                $groupScopeText = "$groupName";
                if (count($groupUsers) > 1)
                    $groupScopeText .= " and Sub Groups";
                break;
            case 'explicit':
                $groupScopeText = "$groupName (not showing punches from child groups)";
                break;
            default:
                break;
        }
    }
    else {
        $groupScope = $groupScopeText = $reportsGroupID = $totalPunches = '';
    }

    $CI =& get_instance();
    $CI->benchmark->mark('output_start');

    define('ROUNDING_DIGITS', $CI->Config->item('report_roundingDigits'));
    define('DURATION_FORMAT', $CI->Config->item('report_durationFormat'));
    define('SHOW_GROUP', $CI->Config->item('report_showGroup'));
    define('SHOW_TAGS', ($CI->Config->item('report_showTags') AND $CI->Config->item('useTags')));
    define('SHOW_DURATION', $CI->Config->item('report_showDuration'));

    $enabledDurations = explode(',', $CI->Config->item('report_enabledDurations'));
    $enabledTotals = explode(',', $CI->Config->item('report_enabledTotals'));

    echo "<a name='home'></a>";

    echo "<h3 class='noPrint'>Hours Detail Report - $groupScopeText</h3>";

    if (!isset($users)){
        echo '<h3 class="noPrint">No users selected or no punches found for date range (there may or may not be punches you have permission to view)</h3>';
    }
    else {
        show_notices();

        echo validation_errors();
//dump(count($users));
            $colsPerRow = ceil(count($users) / 5);
//            dump($colsPerRow);
            $row = $col = 1;

            if (count($users) > 1){
                foreach ($users as $index => $user){
                    $result = $CI->db->get_where('users', array('id' => $index));
                    $result = $result->result();
                    $usernames[$index] = $result[0]->username;
                    $fullNames[$index] = $result[0]->first_name . ' ' . $result[0]->last_name;

                    $links[$row][$col] =  "<a href='#". str_replace('/', '-', $usernames[$index])."'>$usernames[$index] </a>";

                    if ($col == $colsPerRow){
                        $col = 1;
                        $row++;
                    }
                    else {
                        $col++;
                    }
                }

                echo '<table class="everythingTable noPrint">';
                    $i = 1;
                    foreach ($links as $row){
                        $classString = ae_detect_ie() ? ($i ? "class='odd'" : "class='even'") : '';
                        echo "<tr $classString>";
                            foreach ($row as $col){
                                echo "<td valign='top'>$col</td>";
                            }
                        echo '</tr>';
                        $i = $i ? 0 : 1;
                    }
                echo '</table>';
            }

        $p = 0;
        $groups = $ids = array();
        foreach ($users as $index => $user){
            $punchTable = array();
            $statusesTime = array();
            $punches = $user;
            $userGroupTimes = array();
            $userGroupOTTimes = array();
            $totalIn = array();

            if (isset($usernames)){
                $username = $usernames[$index];
                $fullName = $fullNames[$index];
            }
            else {
                $result = $CI->db->get_where('users', array('id' => $index));
                $result = $result->result();
                $username = $result[0]->username;
                $fullName = $result[0]->first_name . ' ' . $result[0]->last_name;
            }

            echo "<a name='$username'></a>";
            $breakText = ($p AND $this->Config->item('report_paginateEmployees')) ? "class='breakBefore'" : '';
            $p++;
            echo "<span style='color:#00C; font-size:28px; font-weight:bold;' $breakText>$username ($fullName)</span> ";
            echo "<span style='color:#000; font-size:14px; font-weight:bold;'>{$startDate} To {$endDate}</span> ";
            echo '<a href="#home" class="backToTop">Back to Top</a>';

            $userUsedStatuses = array();
            foreach ($punches as $punch){
                extract($punch);
                if (! in_array($status_name, $userUsedStatuses)){
                    $userUsedStatuses[] = $status_name;
                }

                $spanStr = "<span style='color:#{$punchColors[$status_name]}'>";
                $dateText = date(DATE_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                $timeText = date(TIME_FORMAT, gmt_to_local(strtotime($date_time), $CI->Config->item('timezone')));
                if ($duration !== NULL){
                    $duration = number_format($duration / 3600, ROUNDING_DIGITS);
                }
                else {
                    $duration = number_format((now() - strtotime($date_time)) / 3600, ROUNDING_DIGITS) . ' (Now)' ;
                }
                $punchTable[$dateText][] =
                array('id' => $id,
                      'userID' => $user_id,
                      'dateText' => $dateText,
                      'timeText' => $timeText,
                      'time' => $spanStr . $timeText . '</span>',
                      'duration' => $duration,
                      'statusName' => "$spanStr $status_name </span>",
                      'statusNameText' => $status_name,
                      'status' => trim($status),
                      'punchTypeID' => $punch_type_id,
                      'groupID' => $group_id,
                      'groupName' => $group_name,
                      'notes' => $notes,
                      'tags' => $tags,
                      'approved' => $approved,
                      'approved_by' => $approved_by,
                      'auditIDs' => $audit_ids);
            }
//dump($punchTable);
            $totalTime = 0;

            $i = 0;
//            dump($punchTable);

            $userOvertime = $weekHours = $dayTime = 0;
            $overtimeStatuses = array();
            $weekMinus =  + (7 - $CI->Config->item('report_weekStartOffset'));
            $startDOW = date('w', (strtotime($startDate)));
            $dayOffset = $CI->Config->item('report_weekStartOffset');
            $weekOTStartDate = strtotime($startDate) + ($dayOffset - $startDOW)*24*3600;
            if (strtotime($startDate) - $weekMinus*24*3600 < strtotime($startDate) - $startDOW*24*3600){
                $weekOTStartDate = strtotime($startDate) - 7*24*3600 + ($dayOffset - $startDOW)*24*3600;
            }
            $currentEnd = $weekOTStartDate + 6*24*3600;
//            dump(date('m/d/y', $weekOTStartDate));
            foreach ($punchTable as $date => $punches){
                $dayOvertimeStatuses = array();
                if ($CI->Config->item('report_showOvertime') == 'week'){
//                    dump(date('m/d/y',       strtotime($date) - (date('w', strtotime($date)) * 24 * 3600)));
//                    dump(date('m/d/y', $weekOTStartDate));
//                    dump($date);
//                    dump(date('m/d/y', $weekOTStartDate));
//                    dump(date('m/d/y', $currentEnd));

                    $startDOW = date('w', (strtotime($startDate)));
                    $dayOffset = $CI->Config->item('report_weekStartOffset');
                    if ($currentEnd < strtotime($date)){
//                        dump('RESET');
//                        dump($weekHours);
                        echo '<hr>';
                        $weekMinus =  + (7 - $CI->Config->item('report_weekStartOffset'));
                        $startDOW = date('w', (strtotime($date)));
                        $dayOffset = $CI->Config->item('report_weekStartOffset');
                        $weekOTStartDate = strtotime($date) + ($dayOffset - $startDOW)*24*3600;
//                        $weekOTStartDate = strtotime($date) - (date('w', strtotime($date) + (7 - $CI->Config->item('report_weekStartOffset'))) * 24 * 3600) + $CI->Config->item('report_weekStartOffset') *3600*24;
                        $currentEnd = $weekOTStartDate + 6*24*3600;
//                        dump(date('m/d/y', $weekOTStartDate));
                        if ($weekHours > $CI->Config->item('report_OTperWeekHours')){
                            $userOvertime += $weekHours - $CI->Config->item('report_OTperWeekHours');
                        }
                        $weekHours = 0;
                    }
                }
                if (strtotime($startDate) <= strtotime($date)){
                    $i++;
                    $dayStatusesTime = array();

                    $dayOfWeek = date('l', strtotime($date));
                    $dayTime = 0;

                    $anchorString = str_replace('/', '-', "$username-$date");
                    echo "<a name='$anchorString'></a>";
                    echo "<h4 style='color:black'>$date ($dayOfWeek)</h4>";
                    echo "\n";
                    $userID = $user[0]['user_id'];

                    if ($i == 1){
                        $nextPunchTime = $punches[0]['dateText'] . ' ' . $punches[0]['timeText'];
                        $nextPunchID = $punches[0]['id'];
                    }
                    $groupWidth = $CI->Config->item('report_showGroupUpline') ? 207 : 107;
                    $groupHeader = SHOW_GROUP ? "<th width='$groupWidth'>Group</th>" : '';
                    $groupHeaderPH = SHOW_GROUP ? "<th width='$groupWidth'></th>" : '';
                    $notesWidth = $CI->Config->item('report_showGroupUpline') ? 160 : 260;
                    $tagsHeader = SHOW_TAGS ? '<th width="140">Tags</th>' : '';
                    $tagsHeaderPH = SHOW_TAGS ? '<th width="140"></th>' : '';
                    $durationHeader = SHOW_DURATION ? '<th width="100">Duration</th>' : '';
                    $durationHeaderPH = SHOW_DURATION ? '<th width="100"></th>' : '';

                    echo "<table class='punchTable'>";
                        $addFirstString = ($i == 1 AND $showEditButtons/* AND $CI->Permissions->has_permission($groupID, 'editTime')*/) ? "<th class='noPrint'></th><th></th><th></th><th class='noPrint'><input type='image' src='" . $this->config->item('base_url') . "css/images/Plus_button.gif' value='Add Punch' onclick='AddAddPunch(\"0_$userID\", $userID, \"$dateText\", \"\", 1, \"$nextPunchTime\", $nextPunchID)'  class='actionButton' /></th>" : '' . '</tr>';
                        if ($i == 1)
                            echo "<tr id='row0_$userID'><th width='100'>Start</th>$durationHeader<th width='90'>Status</th>$groupHeader <th width='$notesWidth'>Notes</th> $tagsHeader $addFirstString</tr>";
                        else
                            echo "<tr><th width='100'></th>$durationHeaderPH<th width='90'></th>$groupHeaderPH <th width='$notesWidth'></th> $tagsHeaderPH</tr>";
                        $i = 1;
                        $ie = 1;
                }
                    $dayHours = 0;
                    foreach ($punches as $punch){
                        extract($punch);
                        @$userGroupTimes[$groupName][$statusNameText] += $duration;
                        
                        if ($status){
                            @$totalIn[$groupName] += $duration;

                            $dayTime += $duration;
                            if ($this->Config->item('report_showOvertime') == 'week'){
                                $wasOnOvertime = false;
                                if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                    $wasOnOvertime = true;
                                }
                                $weekHours += $duration;
                                if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                                    if ($wasOnOvertime){
                                        @$overtimeStatuses[$statusNameText] += $duration;
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $duration;
                                    }
                                    else {
                                        @$overtimeStatuses[$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                    }
                                }
                            }
                            else if ($this->Config->item('report_showOvertime') == 'day'){
                                $wasOnOvertime = false;
                                if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                    $wasOnOvertime = true;
                                }
                                $dayHours += $duration;
                                if ($dayHours > $this->Config->item('report_OTperDayHours')){
                                    if ($wasOnOvertime){
                                        @$dayOvertimeStatuses[$statusNameText] += $duration;
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $duration;
                                    }
                                    else {
                                        @$dayOvertimeStatuses[$statusNameText] += $dayHours - $this->Config->item('report_OTperDayHours');
                                        @$userGroupOTTimes[$groupName][$statusNameText] += $weekHours - $this->Config->item('report_OTperWeekHours');
                                    }
                                }
                            }
                        }
//dump($punch);  if ($this->Config->item('report_showOvertime') == 'day'
                        if (strtotime($startDate) <= strtotime($date)){
                            if (in_array($punchTypeID, $enabledTotals)){
                                @$dayStatusesTime[$statusNameText] += $duration;
                                @$statusesTime[$statusNameText] += $duration;
                            }
                            $isEdited = isset($auditIDs) ? true : false;
                            $isEditedHighlight = $isEdited ? ' style="background:#FFFFC2;" ' : '';
                            $notes = htmlspecialchars($notes);
                            if (! isset($groupUplines[$groupID])){
                                $groupUplines[$groupID] = array_reverse($this->Group->get_upline($groupID));
                                $groupUplineNames[$groupID] = implode(' -> ', $groupUplines[$groupID]);
                            }
                            $groupLine = $CI->Config->item('report_showGroupUpline') ? $groupUplineNames[$groupID] : $groupName;
                            $groupString = SHOW_GROUP ? "<td width='$groupWidth' class='tooltip' title='".$groupUplineNames[$groupID]."'>$groupLine</td>" : '';
                            $tagsString = SHOW_TAGS ? "<td width='107'>$tags</td>" : '';
                            if (! in_array($punchTypeID, $enabledDurations))
                                $durationText = '';
                            else
                                $durationText = DURATION_FORMAT == 'decimal' ? $duration : duration_to_time($duration);
                            $durationString = SHOW_DURATION ? "<td width='107'>$durationText</td>" : '';

                            $classString = (ae_detect_ie() AND ! $isEdited) ? ($ie ? "class='odd'" : "class='even'") : '';
                            echo "
                            <tr id='row$id' $isEditedHighlight $classString><td width='100'>$time</td>$durationString<td width='90'>$statusName</td>$groupString<td width='$notesWidth'>$notes </td>$tagsString";

                            if ($CI->Config->item('getPunchImages')){
                                $folderName = date('M_Y', strtotime($dateText));
                                $imgFilename = FCPATH."/punch_images/$folderName/$id.jpg";
                                if (file_exists($imgFilename)){
                                    $imgURL = BASE_URL."/punch_images/$folderName/$id.jpg";
                                    $thumbURL = file_exists(FCPATH."/punch_images/$folderName/$id"."_thumb.jpg") ? BASE_URL."/punch_images/$folderName/$id"."_thumb.jpg" : $imgURL;
                                    echo "<td><a id='inline$id' href='#data$id' class='screenshot' rel='$thumbURL' title='$dateText $timeText'>Img</a></td>";

                                    echo "<div style='display:none'><div id='data$id' style='padding:15px'>";
                                        $folderName = date('M_Y', now());
                                        echo "<img src='$imgURL' />";
                                    echo '</div>';
                                    ?>
                                        <script type="text/javascript">
                                            $("a#inline<?php echo $id; ?>").fancybox({
                                                'hideOnContentClick': false
                                            });
                                        </script>
                                    <?php
                                }
                                else{
                                    echo '<td></td>';
                                }
                            }
                            if ($CI->Permissions->has_permission($groupID, 'editTime')){
                                if (! $approved){
                                    $ids[] = $id;
                                    $groups[] = $groupID;
                                }

                                $jsNotes = str_replace("'", "&#147;", $notes);
                                
                                if ($showEditButtons){
                                    echo
                                        "<td width='22' class='noPrint'><input type='image' src='" . $this->config->item('base_url') . "css/images/E_button.gif' value='Edit Time' onclick='AddEditTime($id, $userID, \"$dateText\", \"$timeText\", \"$jsNotes\", \"$tags\", $punchTypeID, \"$anchorString\")'  class='actionButton' /></td>" .
                                        "<td width='22' class='noPrint'><input type='image' src='" . $this->config->item('base_url') . "css/images/Minus_button.gif' value='Delete Punch' onclick='AddDeletePunch($id, $userID, $groupID, \"$anchorString\")'  class='actionButton' /></td>" .
                                        "<td width='22' class='noPrint'><input type='image' src='" . $this->config->item('base_url') . "css/images/Plus_button.gif' value='Add Punch' onclick='AddAddPunch($id, $userID, \"$dateText\", \"$anchorString\", 0, 0, 0)'  class='actionButton' /></td>";
                                    if ($isEdited){
                                        echo "<td class='noPrint'><input type='image' src='" . $this->config->item('base_url') . "css/images/inspection.png' value='Edit Time' onclick='AddAudit($id)'  class='actionButton' /></td>";
                                    }
                                }
                                else {
                                    echo "<td width='22' class='noPrint'>".anchor("admin/run_reports?selectedUsers[]=$user_id&reportsGroupID=1&groupScope=all&startDate=$dateText&endDate=$dateText", "<img src='" . $this->config->item('base_url') . "css/images/E_button.gif' alt='Show Context' class='actionButton' />")."</td>";
                                        if ($isEdited){
//                                            echo "<td width='22'><img src='" . $this->config->item('base_url') . "css/images/inspection.png' alt='Audit Trail' /></td>";
                                            echo "<td><input type='image' src='" . $this->config->item('base_url') . "css/images/inspection.png' value='Edit Time' onclick='AddAudit($id)'  class='actionButton' /></td>";
                                        }
                                }
                                echo '</tr>';
                            }
                            else {
                                if (! $approved)
                                    $noPermissionNeedsApproved = true;
                                if ($showEditButtons){
                                    echo '</tr>';
                                }
                            }
                            $ie = $ie ? 0 : 1;
                        }
                    }

                    if (strtotime($startDate) <= strtotime($date)){
                        $totalTime += $dayTime;
                    }
                    
                    if ($this->Config->item('report_showOvertime') == 'day' AND $dayTime > $this->Config->item('report_OTperDayHours')){
                        $userOvertime += $dayTime - $this->Config->item('report_OTperDayHours');
                    }

                    $dayHours = number_format($dayTime, ROUNDING_DIGITS);
                    if (strtotime($startDate) <= strtotime($date)){
                        echo "<tr><td colspan='".(3 + SHOW_GROUP + SHOW_TAGS + SHOW_DURATION)."'>";
                            echo "<b>Day Hours $dayHours | </b>";
    //                        echo "<b>Statuses for day</b> ";
                                $statusesString = '';
                                foreach ($dayStatusesTime as $status => $time){
                                    $overtimeString = isset($dayOvertimeStatuses[$status]) ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($dayOvertimeStatuses[$status], ROUNDING_DIGITS) : duration_to_time(number_format($dayOvertimeStatuses[$status], ROUNDING_DIGITS)))." OT)" : '';
                                    if (isset($dayOvertimeStatuses[$status])) $time -= $dayOvertimeStatuses[$status];
                                    $spanStr = "<span style='color:#{$punchColors[$status]}'>";
                                    $time = DURATION_FORMAT == 'decimal' ? number_format($time, ROUNDING_DIGITS) : duration_to_time(number_format($time, ROUNDING_DIGITS));
                                    $statusesString .= "$spanStr $status: $time $overtimeString</span>, ";
                                }
                                echo trimString($statusesString, 2);
                        echo "</td></tr>";
                    echo "</table>";
                    }
                
                }

                if ($this->Config->item('report_showOvertime') == 'week'){
                    if ($weekHours > $this->Config->item('report_OTperWeekHours')){
                        $userOvertime += $weekHours - $CI->Config->item('report_OTperWeekHours');
                    }
                    $weekHours = 0;
                }

            $totalHours = $totalTime;
            if ($userOvertime)
                $totalHours -= $userOvertime;
            $overtimeString = $userOvertime ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($userOvertime, ROUNDING_DIGITS) : duration_to_time(number_format($userOvertime, ROUNDING_DIGITS)))." Overtime)" : '';
            $totalTime -= $userOvertime;
            $totalHours = DURATION_FORMAT == 'decimal' ? number_format($totalTime, ROUNDING_DIGITS) : duration_to_time(number_format($totalTime, ROUNDING_DIGITS));
            echo "<h3>Total Hours $totalHours $overtimeString</h3>";

            echo '<div style="float:left">';
                echo "<b>Statuses for $fullName: </b> ";
                $statusesString = '';

                foreach ($statusesTime as $status => $time){
                    $spanStr = "<span style='color:#{$punchColors[$status]}'>";
                    $overtimeString = isset($overtimeStatuses[$status]) ? "(+ ".(DURATION_FORMAT == 'decimal' ? number_format($overtimeStatuses[$status], ROUNDING_DIGITS) : duration_to_time(number_format($overtimeStatuses[$status], ROUNDING_DIGITS)))." OT)" : '';
                    if (isset($overtimeStatuses[$status])) $time -= $overtimeStatuses[$status];
                    $time = DURATION_FORMAT == 'decimal' ? number_format($time, ROUNDING_DIGITS) : duration_to_time(number_format($time, ROUNDING_DIGITS));
                    $statusesString .= "$spanStr $status:  $time $overtimeString</span>, ";
                }
                echo trimString($statusesString, 2);
                echo '<br />';
//                dump($overtimeStatuses);
            echo '</div>';

            echo '<div style="clear:both"> </div>';
//            dump($userGroupTimes);
//            dump($userGroupOTTimes);
//            dump($userUsedStatuses);

            if ($CI->Config->item('report_showGroupBreakdown')){
                $groupStatusesOrder = array();
                echo '<table class="everythingTable">';
                    echo '<tr><th></td>';
                        foreach ($statuses->result() as $status){
                            if ($status->enabled AND in_array($status->name, $userUsedStatuses)){
                                $groupStatusesOrder[] = $status->name;
                                echo "<th><span style='color:#$status->color'>$status->name</span></th>";
                            }
                        }
                        echo "<th>Total In</th>";
                    echo '</tr>';
                    foreach ($userGroupTimes as $groupName => $groupTimes){
                        echo '<tr>';
                            echo "<td><strong>$groupName</strong></td>";
                            foreach ($groupStatusesOrder as $statusName){
                                $ot = @$userGroupOTTimes[$groupName][$statusName];
                                $actualTime = @$groupTimes[$statusName] - $ot;
                                echo @"<td><span style='color:#{$punchColors[$statusName]}'>$actualTime".($ot ? "(+$ot OT)" : '')."</span></td>";
                            }
                            $totalTime = isset($totalIn[$groupName]) ? $totalIn[$groupName] : 0;
                            echo "<th>$totalTime</th>";
                        echo '</tr>';
                    }
                echo '</table>';
            }

            echo "<span class='noPrint'>";
                echo '<br /><hr />';
            echo '</span>';
            
            echo '<div style="clear:both"> </div>';
        }
//dump($ids);
        echo "<span class='noPrint'>";
            if (count($ids) OR isset($noPermissionNeedsApproved)){
                if ($CI->Permissions->has_permission($reportsGroupID, 'editTime') AND count($ids)){
                    echo '<br />';
                    echo form_open('admin/approve_time_do');
                        form_hidden('ids', implode(',', $ids));
                        form_hidden('groups', implode(',', $groups));
                        form_hidden('reportsGroupID', $reportsGroupID);
                        echo '<span style="float:right; color:red">';
                            if (isset($noPermissionNeedsApproved))
                                echo 'This report contains punches that have not been approved, you may approve the ones that you have permission to. ';
                            else
                                echo 'This report contains punches that have not been approved. ';
                            form_submit('Approve Punches', false, false, false);
                        echo '</span>';
                    echo form_close();
                }
                else {
                    echo '<span style="float:right; color:red">';
                        echo 'This report contains punches that have not been approved, please contact a supervisor to get these approved. ';
                    echo '</span>';
                }
            }
            else {
                echo '<span style="float:right; color:green">';
                    echo 'All punches on this report have been approved. ';
                echo '</span>';
            }
        echo '</span>';

        $CI->benchmark->mark('output_end');
    }

    echo "<span class='noPrint'>";
        if (isset($cantViewPunches) AND $cantViewPunches){
            echo '<h4>The report scope includes groups you do not have permission to view.  Users may or may not have punches from groups you do not have permission to view</h4>';
        }
        if ($groupScope != 'all' AND (! (($reportsGroupID == 1) AND ($groupScope == 'all' OR $groupScope == 'children')))){
            echo '<h4>This is not an all inclusive report, users may or may not have punches in other groups</h4>';
        }
    echo '</span>';

    echo '<span style="color:#8c9297" id="punchStats">';
        echo "Total punches:  $totalPunches. <br />";
        echo 'Report fetched in ' . number_format($CI->benchmark->elapsed_time('report_start', 'report_end'), 4) . '<br />';
        echo 'Page generated in ' . number_format($CI->benchmark->elapsed_time('output_start', 'output_end'), 4) . '<br />';
    echo '</span>';
?>

<script type="text/javascript">
//<![CDATA[
    var rowOpen = false;

    var beenClickedAddEditTime = new Array();
    function AddEditTime(id, userID, date, time, notes, tags, defaultStatus, anchorString){
        if (rowOpen == false){
            rowOpen = true;
            if (typeof(beenClickedAddEditTime[id]) == 'undefined'){
                beenClickedAddEditTime[id] = 1;
                content = '<tr id="AddEditTime' + id + '" class="AddEditTime"><td colspan="6">' + '<?php echo form_open('admin/edit_time_do', array('name' => 'editTime')); ?>';
                    content += '<table><tr>';
                        content += '<td style="padding:0px;">';
                            content += '<table class="editTable">';
                                content += '<input type="hidden" name="punchID" value="' + id + '" />';
                                content += "<tr><td>Date</td><td>Time</td><td>Status</td><td>Group</td></tr>";
                                content += "<tr><td><input type='text' name='date' id='datepicker_start' value='" + date + "' tabindex='1'></td>";
                                content += "<td><input type='text' name='time' value='" + time + "' tabindex='2'></td>";
                                content += "<td><select name='status' tabindex='3'>";
                                statusNames = new Array();
                                statusIDs = new Array();
                               <?php
                                foreach ($statuses->result() as $status){
                                    echo "statusNames[$status->id] = '$status->name';";
                                    echo "statusIDs[$status->id] = $status->id;";
                                }
//                                echo "\n\n";
                                    echo "for (i in statusNames){ \n";
                                        echo "content += '<option value=\"' + statusIDs[i] + '\"';";
                                        echo "if (defaultStatus == statusIDs[i]) content += ' selected=\"selected\" ';";
                                        echo "content += '>' + statusNames[i] + '</option>'; ";
                                    echo " \n}";
//                                    echo "\n\n";
                                ?>
                                content += '</select></td>';
                                content += "<td id='groupID" + id + "'></td></tr>";
                                content += "<tr><td colspan='2'>Notes</td><td>Tags</td></tr>";
                                content += "<tr><td colspan='2'><input type='text' name='notes' style='width:307px;' value='" + notes + "' tabindex='4'></td>";
                                content += "<td colspan='2'><input type='text' name='tags' value='" + tags + "' style='width:243px;' tabindex='5'></td></tr>";

                                content += "<?php form_text('Reason For Editing', 'reasonForEditing', '', 2, false, "tabindex='6'") ?>";
                                content += "<input type='hidden' name='anchorString' value='" + anchorString + "'>";
                                content += "<tr><td><input type='submit' value='Update' tabindex='7'></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddEditTime\", " + id + ")' tabindex='8'/></td></tr>";
                            content += '</table>';
                        content += '</td>';
                    content += '</tr><tr>';
                    content += '</tr></table>';
                content += '<?php echo form_close(); ?>' + '</td></tr>';
                
                content += "<script type='text/javascript'>";
                    content += "$(function() {";
                        content += "$('#datepicker_start').datepicker();";
                    content += "});";

                    content += "var frmvalidator = new Validator('editTime');";
                    content += "frmvalidator.EnableMsgsTogether();";
                    <?php if ($this->Config->item('requireEditReason')){ ?>
                        content += "frmvalidator.addValidation('reasonForEditing','req', 'Reason for editing is required');";
                    <?php } ?>
                    content += "frmvalidator.addValidation('date','req', 'Date is required');";
                    content += "frmvalidator.addValidation('time','req', 'Time is required');";
                    
                content += "</"; content += "script>";
                $('#row' + id).after(content);
                refreshGroups(id, userID);
            }
        }
        else {
            alert('You must close the open Add, Edit, or Delete form before opening another!');
        }
    }

    var beenClickedAddDeletePunch = new Array();
    function AddDeletePunch(id, userID, groupID, anchorString){
        if (rowOpen == false){
            rowOpen = true;
            if (typeof(beenClickedAddDeletePunch[id]) == 'undefined'){
                beenClickedAddDeletePunch[id] = 1;
                content = '<tr id="AddEditTime' + id + '"><td colspan="6">' + '<?php echo form_open('admin/delete_time_do', array('name' => 'deleteTime')); ?>';
                    content += '<table><tr>';
                        content += '<td style="padding:0px;">';
                            content += '<table class="editTable">';
                                content += '<input type="hidden" name="punchID" value="' + id + '" />';
                                content += '<input type="hidden" name="groupID" value="' + groupID + '" />';
                                content += "<?php form_text('Reason For Deleting', 'reasonForDeleting', '', 2, false, " tabindex='1'") ?>";
                                content += "<input type='hidden' name='anchorString' value='" + anchorString + "'>";
                                content += "<tr><td><input type='submit' value='Delete Punch'  tabindex='2'></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddEditTime\", " + id + ")'  tabindex='3'/></td></tr>";
                            content += '</table>';
                        content += '</td>';
                    content += '</tr><tr>';
                    content += '</tr></table>';

                    <?php if ($this->Config->item('requireEditReason')){ ?>
                        content += "<script type='text/javascript'>";
                            content += "var frmvalidator = new Validator('deleteTime');";
                            content += "frmvalidator.EnableMsgsTogether();";
                            content += "frmvalidator.addValidation('reasonForDeleting','req', 'Reason for deleting is required');";
                        content += "</"; content += "script>";
                    <?php } ?>
                content += '<?php echo form_close(); ?>' + '</td></tr>';
                $('#row' + id).after(content);
                refreshGroups(id, userID);
            }
        }
        else {
            alert('You must close the open Add, Edit, or Delete form before opening another!');
        }
    }

    var beenClickedAddAddPunch = new Array();

    function AddAddPunch(id, userID, date, anchorString, isFirstPunch, nextPunchTime, nextPunchID){
        if (rowOpen == false){
            rowOpen = true;
            if (typeof(beenClickedAddAddPunch[id]) == 'undefined'){
                beenClickedAddAddPunch[id] = 1;
                content = '<tr id="AddAddPunch' + id + '"><td colspan="6">' + '<?php echo form_open('admin/add_time_do', array('name' => 'addTime')); ?>';
                    content += '<table><tr>';
                        content += '<td style="padding:0px;">';
                            content += '<table class="editTable">';
                                content += '<input type="hidden" name="previousPunchID" value="' + id + '" />';
                                content += '<input type="hidden" name="userID" value="' + userID + '" />';
                                content += "<tr><td>Date</td><td>Time</td><td>Status</td><td>Group</td></tr>";
                                content += "<tr><td><input type='text' name='date' id='datepicker_start' value='" + date + "'  tabindex='1'></td>";
                                content += "<td><input type='text' name='time' value=''  tabindex='2'></td>";
                                content += "<td><select name='status' tabindex='3'>";
                               <?php
                                foreach ($statuses->result() as $status){
                                    ?>content += "<?php form_select($status->name, $status->id); ?>";
                               <?php } ?>
                                content += '</select></td>';
                                content += "<td id='groupID" + id + "'></td></tr>";
                                content += '<tr><td colspan="2">Notes</td><td>Tags</td></tr>';
                                content += "<tr><td colspan='2'><input type='text' name='notes' style='width:307px;' tabindex='5'></td>";
                                content += "<td colspan='2'><input type='text' name='tags' style='width:243px;' tabindex='6'></td></tr>";

                                content += "<?php form_text('Reason For Adding', 'reasonForAdding', '', 2, false, " tabindex='7'") ?>";
                                content += "<input type='hidden' name='anchorString' value='" + anchorString + "'>";

                                if (isFirstPunch){
                                     content += "<input type='hidden' name='reportStartDate' value='<?php echo $startDate; ?>'>";
                                     content += "<input type='hidden' name='nextPunchTime' value='" + nextPunchTime + "'>";
                                     content += "<input type='hidden' name='nextPunchID' value='" + nextPunchID + "'>";
                                }

                                content += "<tr><td><input type='submit' value='Add Punch' tabindex='8'></td><td><input type='button' value='Cancel' onclick='deleteRow(\"AddAddPunch\", \"" + id + "\")'  tabindex='9'/></td></tr>";
                            content += '</table>';
                        content += '</td>';
                    content += '</tr><tr>';
                    content += '</tr></table>';

                    content += "<script type='text/javascript'>";
                        content += "$(function() {";
                            content += "$('#datepicker_start').datepicker();";
                        content += "});";

                        content += "var frmvalidator = new Validator('addTime');";
                        content += "frmvalidator.EnableMsgsTogether();";
                        <?php if ($this->Config->item('requireEditReason')){ ?>
                            content += "frmvalidator.addValidation('reasonForAdding','req', 'Reason for adding is required');";
                        <?php } ?>

                        content += "frmvalidator.addValidation('date','req', 'Date is required');";
                        content += "frmvalidator.addValidation('time','req', 'Time is required');";
                    content += "</"; content += "script>";
                content += '<?php echo form_close(); ?>' + '</td></tr>';
                $('#row' + id).after(content);
                refreshGroups(id, userID);
            }
        }
        else {
            alert('You must close the open Add, Edit, or Delete form before opening another!');
        }
    }

    var beenClickedAddAudit = new Array();

    function AddAudit(id){
        if (rowOpen == false){
            rowOpen = true;
            if (typeof(beenClickedAddAudit[id]) == 'undefined'){
                beenClickedAddAudit[id] = 1;
                content = '<tr id="AddAudit' + id + '"><td colspan="10">';
                    content += '<table><tr>';
                        content += '<td style="padding:0px;">';
                            content += '<table class="editTable" id="table_Audit' + id + '">';
                            
                            content += '</table>';
                        content += '</td>';
                    content += '</tr></table>';

                content += '</td></tr>';
                $('#row' + id).after(content);

                $("#table_Audit" + id).ajaxStart(function() {
                    $("#table_Audit" + id).html("<img src='<?php echo $CI->config->item('base_url') ?>css/images/ajax-loader.gif'>");
                });

                $.ajax({
                    url: "<?php echo $CI->config->item('base_url') ?>index.php/admin/ajax_audit",
                    data: "&punchID=" + id,
                    type: "POST",
                    success: function(data) {
                      $("#table_Audit" + id).html(data);
                    }
                  });
            }
        }
        else {
            alert('You must close the open Add, Edit, Delete, or Audit form before opening another!');
        }
    }

    function deleteRow(rowname, id){
        $('#' + rowname + id).remove();
        switch(rowname){
            case 'AddEditTime':
                beenClickedAddEditTime[id] = undefined;
                rowOpen = false;
                break;
            case 'AddDeleteConfirm':
                beenClickedAddDeleteConfirm[id] = undefined;
                rowOpen = false;
                break;
            case 'AddAddPunch':
                beenClickedAddAddPunch[id] = undefined;
                rowOpen = false;
                break;
            case 'AddAudit':
                beenClickedAddAudit[id] = undefined;
                rowOpen = false;
                break;
            default:
                break;
        }
    }

    function refreshGroups(id, userID)
    {
        $.ajax({
            url: "<?php echo $CI->config->item('base_url') ?>index.php/dashboard/ajax_Select_Group/",
                data: "&userID=" + userID + "&echoGroups=0",
                type: "POST",
            success: function(data) {
              $("#groupID" + id).html(data);
            }
        });
    }
//]]>
</script>