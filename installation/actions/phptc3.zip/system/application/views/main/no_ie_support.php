<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?><?php
/**
 * PHPTimeclock 3
 *
 * An open source application for timekeeping
 *
 * @package		PHPTimeclock 3
 * @author		Nexus Solutions Development Team
 * @copyright	Copyright (c) 2010, Nexus Computers.
 * @license		http://phptimeclock.com/license.php
 * @link		http://phptimeclock.com
 * @since		Version 3.0
 * @filesource          PHPTimeclock3_License.txt
 */
?>

<?php
    $CI =& get_instance();
    
    show_notices();

    echo validation_errors();
?>

<h3><?php echo $CI->lang->line('No IE support') ?></h3>
<br />
<strong><?php echo $CI->lang->line('All other major browsers supported') ?></strong>
<br />
<a href="http://www.mozilla.com/firefox">Mozilla Firefox</a> - <?php echo $CI->lang->line('Firefox desc') ?><br />
<a href="http://www.google.com/chrome">Google Chrome</a> - <?php echo $CI->lang->line('Chrome desc') ?><br />
<a href="http://www.opera.com/">Opera</a> - <?php echo $CI->lang->line('Opera desc') ?><br />
<a href="http://www.apple.com/safari/">Safari</a> - <?php echo $CI->lang->line('Safari desc') ?><br />
<br />
<?php echo $CI->lang->line('IE improvement note') ?>
