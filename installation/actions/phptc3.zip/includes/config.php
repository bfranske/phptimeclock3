<?php
static  $localPath  = 'F:/wamp/www/phptc3';
static $webRoot = 'http://localhost/phptc3';
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = 'ironfish7';
$dbName = 'phptc3';

define("DB_HOST", $dbHost);
define("DB_USERNAME", $dbUser);
define("DB_PASSWORD", $dbPass);
define("DB_NAME", $dbName);
?>
